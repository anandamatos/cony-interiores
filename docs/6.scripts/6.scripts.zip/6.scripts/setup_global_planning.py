#!/usr/bin/env python3
"""
Script 2: Planejamento Global - Criação de Épicos
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# ÉPICOS
# ============================================================

EPICS = [
    # MVP 1
    {'id': 'EPIC-M1-FND-001', 'title': 'Infraestrutura e Base Técnica', 'squad': 'Foundation', 'mvp': 'MVP 1', 
     'milestone': 'MVP 1 - Sprint 1: Base Digital',
     'body': """## 🎯 Objetivo do Épico
Ambiente de desenvolvimento padronizado e funcional, com cadastro de costureiras operacional.

## 👥 Squad Responsável
**Foundation**

## 📌 Definition of Done
- [ ] Docker configurado e funcionando em todos os SOs
- [ ] Cadastro de costureiras via API e interface
- [ ] Ambiente de desenvolvimento padronizado
- [ ] CI/CD pipeline configurado (GitHub Actions)

## 📊 Stories Relacionadas
- [ ] STORY-M1-FND-001: Configuração do Backend Django
- [ ] STORY-M1-FND-002: Configuração do Frontend React
- [ ] STORY-M1-FND-003: Autenticação e Segurança"""},
    {'id': 'EPIC-M1-CORE-001', 'title': 'Lógica de Carga e CRUD', 'squad': 'Core Business', 'mvp': 'MVP 1',
     'milestone': 'MVP 1 - Sprint 1: Base Digital',
     'body': """## 🎯 Objetivo do Épico
CRUD de serviços funcional e cálculo inicial de capacidade com índice de complexidade.

## 👥 Squad Responsável
**Core Business**

## 📌 Definition of Done
- [ ] CRUD completo de serviços (via API e interface)
- [ ] Cálculo de carga com índice de complexidade (P/M/G/Esp)
- [ ] Endpoint de consulta de carga por costureira

## 📊 Stories Relacionadas
- [ ] STORY-M1-CORE-001: Cadastro de Costureiras
- [ ] STORY-M1-CORE-002: CRUD de Serviços
- [ ] STORY-M1-CORE-003: Cálculo de Capacidade"""},
    {'id': 'EPIC-M1-UX-001', 'title': 'Interface e Jornada do Usuário', 'squad': 'UX & Experience', 'mvp': 'MVP 1',
     'milestone': 'MVP 1 - Sprint 1: Base Digital',
     'body': """## 🎯 Objetivo do Épico
Telas iniciais funcionais, Design System e navegação fluida.

## 👥 Squad Responsável
**UX & Experience**

## 📌 Definition of Done
- [ ] Design System implementado (Tailwind CSS)
- [ ] Página de listagem de costureiras
- [ ] Navegação funcional entre páginas
- [ ] Responsividade (mobile-first)

## 📊 Stories Relacionadas
- [ ] STORY-M1-UX-001: Layout Base e Design System
- [ ] STORY-M1-UX-002: Formulários e Integração API
- [ ] STORY-M1-UX-003: Visualização de Carga"""},
    
    # MVP 2
    {'id': 'EPIC-M2-CORE-001', 'title': 'Controle Financeiro', 'squad': 'Core Business', 'mvp': 'MVP 2',
     'milestone': 'MVP 2 - Sprint 4: Previsão Financeira',
     'body': """## 🎯 Objetivo do Épico
Implementar controle financeiro e planejamento de pagamentos para costureiras.

## 👥 Squad Responsável
**Core Business**

## 📌 Definition of Done
- [ ] Modelo de dados financeiro implementado
- [ ] Soma automática de valores pendentes
- [ ] Planejamento de pagamentos semanais/mensais
- [ ] Interface de resumo financeiro

## 📊 Stories Relacionadas
- [ ] STORY-M2-CORE-001: Modelo Financeiro
- [ ] STORY-M2-CORE-002: Cálculo de Pagamentos"""},
    {'id': 'EPIC-M2-UX-001', 'title': 'Interface Financeira', 'squad': 'UX & Experience', 'mvp': 'MVP 2',
     'milestone': 'MVP 2 - Sprint 4: Previsão Financeira',
     'body': """## 🎯 Objetivo do Épico
Interface para visualização e gestão de pagamentos.

## 👥 Squad Responsável
**UX & Experience**

## 📌 Definition of Done
- [ ] Dashboard financeiro implementado
- [ ] Visualização de valores pendentes
- [ ] Resumo semanal/mensal por costureira

## 📊 Stories Relacionadas
- [ ] STORY-M2-UX-001: Dashboard Financeiro"""},
    
    # MVP 3
    {'id': 'EPIC-M3-UX-001', 'title': 'Gestão Visual e Dashboards', 'squad': 'UX & Experience', 'mvp': 'MVP 3',
     'milestone': 'MVP 3 - Sprint 5: Gestão Visual',
     'body': """## 🎯 Objetivo do Épico
Dashboards de produtividade e métricas de ROI.

## 👥 Squad Responsável
**UX & Experience**

## 📌 Definition of Done
- [ ] Dashboard com KPIs de produção
- [ ] Comparativo de produtividade entre costureiras
- [ ] Métricas de ROI e eficiência
- [ ] Gráficos interativos e filtros

## 📊 Stories Relacionadas
- [ ] STORY-M3-UX-001: Dashboard de Produção
- [ ] STORY-M3-UX-002: Métricas e ROI"""},
    
    # MVP 4
    {'id': 'EPIC-M4-CORE-001', 'title': 'Relatórios Avançados', 'squad': 'Core Business', 'mvp': 'MVP 4',
     'milestone': 'MVP 4 - Sprint 6: Relatórios Avançados',
     'body': """## 🎯 Objetivo do Épico
Gerar relatórios gerenciais detalhados e exportáveis.

## 👥 Squad Responsável
**Core Business**

## 📌 Definition of Done
- [ ] Relatórios mensais de produção
- [ ] Relatórios de serviços em atraso
- [ ] Exportação em PDF/CSV
- [ ] Filtros avançados

## 📊 Stories Relacionadas
- [ ] STORY-M4-CORE-001: Relatórios de Produção
- [ ] STORY-M4-CORE-002: Exportação de Dados"""},
    
    # MVP 5
    {'id': 'EPIC-M5-ALL-001', 'title': 'Otimização e Ajustes Finais', 'squad': 'All Squads', 'mvp': 'MVP 5',
     'milestone': 'MVP 5 - Sprint 7: Otimização',
     'body': """## 🎯 Objetivo do Épico
Refinar a experiência do usuário e otimizar performance.

## 👥 Squad Responsável
**Todos os Squads**

## 📌 Definition of Done
- [ ] Melhorias de usabilidade
- [ ] Otimização de performance
- [ ] Acessibilidade (WCAG 2.1 AA)
- [ ] Correção de bugs
- [ ] Documentação atualizada

## 📊 Stories Relacionadas
- [ ] STORY-M5-ALL-001: Otimização e Refinamentos"""},
    
    # Final
    {'id': 'EPIC-FIN-ALL-001', 'title': 'Deploy e Handover', 'squad': 'All Squads', 'mvp': 'Final',
     'milestone': 'Final - Sprint 8: Deploy e Handover',
     'body': """## 🎯 Objetivo do Épico
Entregar o sistema finalizado e documentado.

## 👥 Squad Responsável
**Todos os Squads**

## 📌 Definition of Done
- [ ] Deploy em produção
- [ ] Documentação técnica completa
- [ ] Manual do usuário
- [ ] Treinamento realizado
- [ ] Plano de suporte pós-entrega

## 📊 Stories Relacionadas
- [ ] STORY-FIN-ALL-001: Deploy e Documentação
- [ ] STORY-FIN-ALL-002: Treinamento e Handover"""},
]

# ============================================================
# FUNÇÕES
# ============================================================

def get_milestone_number(title):
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for ms in r.json():
            if ms['title'] == title:
                return ms['number']
    return None

def issue_exists(title):
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if issue['title'] == title:
                return True
    return False

def create_issue(title, body, labels, milestone_number):
    url = f"{BASE_URL}/issues"
    data = {'title': title, 'body': body, 'labels': labels, 'milestone': milestone_number}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def add_comment(issue_number, body):
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    data = {'body': body}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       SCRIPT 2: PLANEJAMENTO GLOBAL
       Criação de Épicos para todos os MVPs
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    created = 0
    errors = 0
    
    for epic in EPICS:
        print(f"\n📌 Criando Épico: {epic['id']}")
        
        milestone_number = get_milestone_number(epic['milestone'])
        if not milestone_number:
            print(f"   ⚠️ Milestone '{epic['milestone']}' não encontrado!")
            errors += 1
            continue
        
        labels = ['epic']
        mvp_map = {'MVP 1': 'mvp1', 'MVP 2': 'mvp2', 'MVP 3': 'mvp3', 'MVP 4': 'mvp4', 'MVP 5': 'mvp5', 'Final': 'final'}
        if epic['mvp'] in mvp_map:
            labels.append(mvp_map[epic['mvp']])
        
        squad_map = {'Foundation': 'foundation', 'Core Business': 'core-business', 'UX & Experience': 'ux-experience'}
        if epic['squad'] in squad_map:
            labels.append(squad_map[epic['squad']])
        
        title = f"[{epic['id']}] [Epic] {epic['title']}"
        
        if issue_exists(title):
            print(f"   ℹ️ Épico já existe: {title}")
            continue
        
        result = create_issue(title, epic['body'], labels, milestone_number)
        
        if result.status_code == 201:
            issue_number = result.json()['number']
            print(f"   ✅ Épico criado: #{issue_number}")
            created += 1
            
            comment = f"""
## 🏷️ Metadados do Épico
**ID:** {epic['id']}
**Squad:** {epic['squad']}
**MVP:** {epic['mvp']}
**Tipo:** Épico
**Data de Criação:** {time.strftime('%d/%m/%Y')}
"""
            add_comment(issue_number, comment)
            time.sleep(0.5)
        else:
            print(f"   ❌ Erro ao criar épico: {result.status_code}")
            errors += 1
    
    print(f"""
    ==============================================
    ✅ PLANEJAMENTO GLOBAL CONCLUÍDO!
    ==============================================
    📊 Resumo:
       Épicos criados: {created}
       Erros: {errors}
    🔗 Acesse: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)

if __name__ == "__main__":
    main()