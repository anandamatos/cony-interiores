#!/usr/bin/env python3
"""
Script: Atualizar Épicos com Discovery e Measurement Agrupados por Story
Converte a estrutura antiga para a nova com tarefas agrupadas por Story
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# DEFINIÇÃO DOS ÉPICOS COM DISCOVERY E MEASUREMENT AGRUPADOS POR STORY
# ============================================================

EPICS_DATA = {
    'EPIC-M1-FND-001': {
        'title': 'Infraestrutura e Base Técnica',
        'squad': 'Foundation',
        'mvp': 'MVP 1',
        'responsible': '@lobaque29',
        'objective': 'Ambiente de desenvolvimento padronizado e funcional, com cadastro de costureiras operacional.',
        'definition_of_done': [
            'Docker configurado e funcionando em todos os SOs',
            'Cadastro de costureiras via API e interface',
            'Ambiente de desenvolvimento padronizado',
            'CI/CD pipeline configurado (GitHub Actions)',
            'Documentação de setup atualizada'
        ],
        'discovery_by_story': {
            'STORY-M1-FND-001: Configuração do Backend Django': [
                'DISCOVERY-M1-FND-001: Validar versões do Python, Django e PostgreSQL',
                'DISCOVERY-M1-FND-002: Definir arquitetura de containers',
                'DISCOVERY-M1-FND-003: Mapear necessidades de segurança e variáveis de ambiente',
                'DISCOVERY-M1-FND-004: Validar configuração de CORS para os ambientes',
                'DISCOVERY-M1-FND-005: Definir estratégia de logging'
            ],
            'STORY-M1-FND-002: Configuração do Frontend React': [
                'DISCOVERY-M1-FND-006: Validar versão do React e Vite',
                'DISCOVERY-M1-FND-007: Definir estrutura de componentes',
                'DISCOVERY-M1-FND-008: Mapear necessidades de performance (lazy loading)',
                'DISCOVERY-M1-FND-009: Validar configuração de API (Axios)',
                'DISCOVERY-M1-FND-010: Definir padrões de código (ESLint)'
            ],
            'STORY-M1-FND-003: Autenticação e Segurança': [
                'DISCOVERY-M1-FND-011: Validar estratégia de autenticação (JWT)',
                'DISCOVERY-M1-FND-012: Definir permissões por perfil',
                'DISCOVERY-M1-FND-013: Mapear endpoints que precisam de proteção',
                'DISCOVERY-M1-FND-014: Validar política de refresh token',
                'DISCOVERY-M1-FND-015: Definir estratégia de logout'
            ]
        },
        'measurement_by_story': {
            'STORY-M1-FND-001: Configuração do Backend Django': [
                'MEASUREMENT-M1-FND-001: Definir KPIs de infraestrutura',
                'MEASUREMENT-M1-FND-002: Estabelecer baseline de performance',
                'MEASUREMENT-M1-FND-003: Criar métricas de tempo de setup',
                'MEASUREMENT-M1-FND-004: Definir cobertura mínima de testes'
            ],
            'STORY-M1-FND-002: Configuração do Frontend React': [
                'MEASUREMENT-M1-FND-005: Definir KPIs de performance frontend',
                'MEASUREMENT-M1-FND-006: Estabelecer baseline de carregamento',
                'MEASUREMENT-M1-FND-007: Criar métricas de bundle size',
                'MEASUREMENT-M1-FND-008: Definir padrões de acessibilidade'
            ],
            'STORY-M1-FND-003: Autenticação e Segurança': [
                'MEASUREMENT-M1-FND-009: Definir KPIs de segurança',
                'MEASUREMENT-M1-FND-010: Estabelecer tempo de resposta com JWT',
                'MEASUREMENT-M1-FND-011: Criar métricas de tentativas de acesso',
                'MEASUREMENT-M1-FND-012: Definir cobertura de testes de segurança'
            ]
        },
        'stories': [
            'STORY-M1-FND-001: Configuração do Backend Django',
            'STORY-M1-FND-002: Configuração do Frontend React',
            'STORY-M1-FND-003: Autenticação e Segurança'
        ]
    },
    'EPIC-M1-CORE-001': {
        'title': 'Lógica de Carga e CRUD',
        'squad': 'Core Business',
        'mvp': 'MVP 1',
        'responsible': '@karinakaduda19-cyber',
        'objective': 'CRUD de serviços funcional e cálculo inicial de capacidade com índice de complexidade.',
        'definition_of_done': [
            'CRUD completo de serviços (via API e interface)',
            'Cálculo de carga com índice de complexidade (P/M/G/Esp)',
            'Endpoint de consulta de carga por costureira',
            'Testes unitários e de integração',
            'Documentação da API de capacidade'
        ],
        'discovery_by_story': {
            'STORY-M1-CORE-001: Cadastro de Costureiras': [
                'DISCOVERY-M1-CORE-001: Validar campos obrigatórios da Costureira',
                'DISCOVERY-M1-CORE-002: Definir regras de unicidade',
                'DISCOVERY-M1-CORE-003: Mapear relacionamentos com outros modelos',
                'DISCOVERY-M1-CORE-004: Validar formato de dados (contato, especialidade)',
                'DISCOVERY-M1-CORE-005: Definir padrão de API REST'
            ],
            'STORY-M1-CORE-002: CRUD de Serviços': [
                'DISCOVERY-M1-CORE-006: Validar campos do modelo Servico',
                'DISCOVERY-M1-CORE-007: Definir status possíveis (enviado, produção, pronto, entregue, pago)',
                'DISCOVERY-M1-CORE-008: Mapear regras de complexidade',
                'DISCOVERY-M1-CORE-009: Validar cálculos de valor',
                'DISCOVERY-M1-CORE-010: Definir filtros por status e costureira'
            ],
            'STORY-M1-CORE-003: Cálculo de Capacidade': [
                'DISCOVERY-M1-CORE-011: Validar fórmula de cálculo de carga',
                'DISCOVERY-M1-CORE-012: Definir pesos para índices de complexidade (P/M/G/Esp)',
                'DISCOVERY-M1-CORE-013: Mapear regras de distribuição',
                'DISCOVERY-M1-CORE-014: Validar lógica de sugestão de alocação',
                'DISCOVERY-M1-CORE-015: Definir formato do endpoint de carga'
            ]
        },
        'measurement_by_story': {
            'STORY-M1-CORE-001: Cadastro de Costureiras': [
                'MEASUREMENT-M1-CORE-001: Definir KPIs de cadastro',
                'MEASUREMENT-M1-CORE-002: Estabelecer tempo de resposta CRUD',
                'MEASUREMENT-M1-CORE-003: Criar métricas de validação',
                'MEASUREMENT-M1-CORE-004: Definir cobertura de testes unitários'
            ],
            'STORY-M1-CORE-002: CRUD de Serviços': [
                'MEASUREMENT-M1-CORE-005: Definir KPIs de fluxo operacional',
                'MEASUREMENT-M1-CORE-006: Estabelecer tempo de resposta dos endpoints',
                'MEASUREMENT-M1-CORE-007: Criar métricas de acurácia dos filtros',
                'MEASUREMENT-M1-CORE-008: Definir cobertura de testes'
            ],
            'STORY-M1-CORE-003: Cálculo de Capacidade': [
                'MEASUREMENT-M1-CORE-009: Definir KPIs de capacidade',
                'MEASUREMENT-M1-CORE-010: Estabelecer precisão do cálculo',
                'MEASUREMENT-M1-CORE-011: Criar métricas de acurácia da alocação',
                'MEASUREMENT-M1-CORE-012: Definir testes de integração'
            ]
        },
        'stories': [
            'STORY-M1-CORE-001: Cadastro de Costureiras',
            'STORY-M1-CORE-002: CRUD de Serviços',
            'STORY-M1-CORE-003: Cálculo de Capacidade'
        ]
    },
    'EPIC-M1-UX-001': {
        'title': 'Interface e Jornada do Usuário',
        'squad': 'UX & Experience',
        'mvp': 'MVP 1',
        'responsible': '@anandamatos',
        'objective': 'Telas iniciais funcionais, Design System e navegação fluida.',
        'definition_of_done': [
            'Design System implementado (Tailwind CSS)',
            'Página de listagem de costureiras',
            'Navegação funcional entre páginas',
            'Responsividade (mobile-first)',
            'Testes de usabilidade realizados'
        ],
        'discovery_by_story': {
            'STORY-M1-UX-001: Layout Base e Design System': [
                'DISCOVERY-M1-UX-001: Validar cores e tema da Cony Interiores',
                'DISCOVERY-M1-UX-002: Definir estrutura de navegação',
                'DISCOVERY-M1-UX-003: Mapear componentes necessários',
                'DISCOVERY-M1-UX-004: Prototipar layout principal',
                'DISCOVERY-M1-UX-005: Validar requisitos de responsividade'
            ],
            'STORY-M1-UX-002: Formulários e Integração API': [
                'DISCOVERY-M1-UX-006: Validar fluxo de cadastro de costureiras',
                'DISCOVERY-M1-UX-007: Definir feedbacks visuais (toasts/alertas)',
                'DISCOVERY-M1-UX-008: Mapear validações do formulário',
                'DISCOVERY-M1-UX-009: Prototipar página de listagem',
                'DISCOVERY-M1-UX-010: Validar integração com API'
            ],
            'STORY-M1-UX-003: Visualização de Carga': [
                'DISCOVERY-M1-UX-011: Validar tipos de gráficos necessários',
                'DISCOVERY-M1-UX-012: Definir estrutura de cards de carga',
                'DISCOVERY-M1-UX-013: Mapear filtros por período e tipo',
                'DISCOVERY-M1-UX-014: Prototipar página de visualização',
                'DISCOVERY-M1-UX-015: Validar integração com API de capacidade'
            ]
        },
        'measurement_by_story': {
            'STORY-M1-UX-001: Layout Base e Design System': [
                'MEASUREMENT-M1-UX-001: Definir KPIs de usabilidade',
                'MEASUREMENT-M1-UX-002: Estabelecer padrões de design',
                'MEASUREMENT-M1-UX-003: Criar métricas de navegação',
                'MEASUREMENT-M1-UX-004: Definir testes de UX'
            ],
            'STORY-M1-UX-002: Formulários e Integração API': [
                'MEASUREMENT-M1-UX-005: Definir KPIs de eficiência do formulário',
                'MEASUREMENT-M1-UX-006: Estabelecer taxa de erro em cadastros',
                'MEASUREMENT-M1-UX-007: Criar métricas de tempo de preenchimento',
                'MEASUREMENT-M1-UX-008: Definir testes de integração'
            ],
            'STORY-M1-UX-003: Visualização de Carga': [
                'MEASUREMENT-M1-UX-009: Definir KPIs de visualização de dados',
                'MEASUREMENT-M1-UX-010: Estabelecer tempo de renderização dos gráficos',
                'MEASUREMENT-M1-UX-011: Criar métricas de usabilidade',
                'MEASUREMENT-M1-UX-012: Definir testes de performance'
            ]
        },
        'stories': [
            'STORY-M1-UX-001: Layout Base e Design System',
            'STORY-M1-UX-002: Formulários e Integração API',
            'STORY-M1-UX-003: Visualização de Carga'
        ]
    }
}

# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def get_all_issues():
    """Busca TODAS as issues (abertas E fechadas)"""
    url = f"{BASE_URL}/issues?state=all&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def update_issue(issue_number, new_body):
    """Atualiza o corpo de uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'body': new_body}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r

def build_epic_body(epic_id, data):
    """Constrói o corpo do épico com Discovery e Measurement agrupados por Story"""
    
    body = f"""## 🎯 Objetivo do Épico
{data['objective']}

## 👥 Squad Responsável
**{data['squad']}** (com suporte de outros squads conforme necessário)

## 📌 Definition of Done
"""
    for item in data['definition_of_done']:
        body += f"- [ ] {item}\n"
    
    body += "\n---\n\n## 🔍 Tarefas de Discovery (Liderança)\n"
    
    # Adiciona Discovery agrupado por Story
    for story, tasks in data['discovery_by_story'].items():
        body += f"\n### {story}\n"
        for task in tasks:
            body += f"- [ ] **{task}**\n"
    
    body += "\n---\n\n## 📊 Tarefas de Mensuração (Liderança)\n"
    
    # Adiciona Measurement agrupado por Story
    for story, tasks in data['measurement_by_story'].items():
        body += f"\n### {story}\n"
        for task in tasks:
            body += f"- [ ] **{task}**\n"
    
    body += "\n---\n\n## 📋 Stories Relacionadas\n"
    for story in data['stories']:
        body += f"- [ ] {story}\n"
    
    body += f"""
---
## 🏷️ Metadados
**ID:** {epic_id}
**Squad:** {data['squad']}
**MVP:** {data['mvp']}
**Tipo:** Épico
**Track:** Discovery
**Responsável:** {data['responsible']}
"""
    return body

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       SCRIPT: ATUALIZAR ÉPICOS COM DISCOVERY E MEASUREMENT
       Discovery e Measurement agrupados por Story
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # Busca TODAS as issues (abertas E fechadas)
    issues = get_all_issues()
    print(f"🔍 Encontradas {len(issues)} issues no total\n")
    
    updated = 0
    not_found = []
    already_updated = []
    
    for epic_id, data in EPICS_DATA.items():
        print(f"📌 Processando: {epic_id}")
        
        # Procura a issue do épico
        found = False
        for issue in issues:
            if epic_id in issue['title'] and 'Epic' in issue['title']:
                found = True
                issue_number = issue['number']
                current_body = issue.get('body', '')
                issue_state = issue.get('state', 'open')
                
                print(f"   Issue #{issue_number} encontrada (estado: {issue_state})")
                
                # Verifica se já tem o novo formato (com tarefas agrupadas por Story)
                if '## 🔍 Tarefas de Discovery (Liderança)' in current_body and '### STORY' in current_body:
                    print(f"   ℹ️ Épico já está no novo formato (Nº {issue_number})")
                    already_updated.append(epic_id)
                    break
                
                # Constrói o novo corpo
                new_body = build_epic_body(epic_id, data)
                
                # Atualiza a issue
                result = update_issue(issue_number, new_body)
                if result.status_code == 200:
                    print(f"   ✅ Épico atualizado: #{issue_number}")
                    updated += 1
                else:
                    print(f"   ❌ Erro ao atualizar: {result.status_code}")
                    print(f"   {result.text[:200]}")
                break
        
        if not found:
            print(f"   ⚠️ Épico não encontrado: {epic_id}")
            not_found.append(epic_id)
        
        time.sleep(0.5)
    
    print(f"""
    ==============================================
    ✅ ATUALIZAÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Épicos atualizados: {updated}
       Épicos já no novo formato: {len(already_updated)}
       Épicos não encontrados: {len(not_found)}
    
    🔗 Acesse:
       https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)
    
    if not_found:
        print("\n📋 Épicos não encontrados:")
        for epic_id in not_found:
            print(f"   - {epic_id}")

if __name__ == "__main__":
    main()