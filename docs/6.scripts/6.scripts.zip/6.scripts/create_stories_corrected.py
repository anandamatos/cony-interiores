#!/usr/bin/env python3
"""
Script para criar Stories com assignees corrigidos
"""
import os
import requests
import json
import time

# ============================================================
# CONFIGURAÇÕES
# ============================================================

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    print("   Execute: export GITHUB_TOKEN=seu_token")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# DEFINIÇÃO DAS STORIES COM ASSIGNEES CORRETOS
# ============================================================

STORIES = [
    # === SQUAD FOUNDATION ===
    {
        'id': 'STORY-M1-FND-001',
        'title': 'Configuração do Backend Django',
        'epic_id': 'EPIC-M1-FND-001',
        'epic_title': '[EPIC-M1-FND-001] [Epic] Infraestrutura e Base Técnica',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'Marcus1423',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'foundation'],
        'body': """## 📖 User Story
Como desenvolvedor backend, quero ter o Django configurado com DRF e PostgreSQL para poder iniciar o desenvolvimento da API.

## ✅ Critérios de Aceite
- [ ] Projeto Django inicializado
- [ ] Django REST Framework configurado
- [ ] PostgreSQL conectado via Docker
- [ ] CORS configurado
- [ ] Logging estruturado implementado

## 📋 Tarefas
- [ ] TASK-M1-FND-001: Inicializar projeto Django
- [ ] TASK-M1-FND-002: Configurar DRF
- [ ] TASK-M1-FND-003: Configurar PostgreSQL no docker-compose
- [ ] TASK-M1-FND-004: Configurar CORS
- [ ] TASK-M1-FND-005: Implementar logging estruturado

## 🏷️ Metadados
**ID:** STORY-M1-FND-001
**Squad:** Foundation
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-FND-001
**Responsável:** @Marcus1423"""
    },
    {
        'id': 'STORY-M1-FND-002',
        'title': 'Configuração do Frontend React',
        'epic_id': 'EPIC-M1-FND-001',
        'epic_title': '[EPIC-M1-FND-001] [Epic] Infraestrutura e Base Técnica',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'mariagabrielle428-ship-it',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'foundation'],
        'body': """## 📖 User Story
Como desenvolvedor frontend, quero ter o React configurado com Vite, Router e Axios para iniciar o desenvolvimento da interface.

## ✅ Critérios de Aceite
- [ ] Projeto React com Vite inicializado
- [ ] React Router configurado
- [ ] Axios configurado para comunicação com API
- [ ] ESLint e Prettier configurados
- [ ] Husky configurado para pre-commit hooks

## 📋 Tarefas
- [ ] TASK-M1-FND-006: Inicializar projeto React com Vite
- [ ] TASK-M1-FND-007: Configurar React Router
- [ ] TASK-M1-FND-008: Configurar Axios
- [ ] TASK-M1-FND-009: Configurar ESLint e Prettier
- [ ] TASK-M1-FND-010: Configurar Husky

## 🏷️ Metadados
**ID:** STORY-M1-FND-002
**Squad:** Foundation
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-FND-001
**Responsável:** @mariagabrielle428-ship-it"""
    },
    {
        'id': 'STORY-M1-FND-003',
        'title': 'Autenticação e Segurança',
        'epic_id': 'EPIC-M1-FND-001',
        'epic_title': '[EPIC-M1-FND-001] [Epic] Infraestrutura e Base Técnica',
        'milestone': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'assignee': 'Marcus1423',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'foundation'],
        'body': """## 📖 User Story
Como desenvolvedor backend, quero implementar autenticação JWT e segurança para proteger os endpoints da API.

## ✅ Critérios de Aceite
- [ ] Autenticação JWT implementada
- [ ] Middleware de segurança configurado
- [ ] Sistema de permissões implementado
- [ ] Refresh token funcional
- [ ] Testes de segurança

## 📋 Tarefas
- [ ] TASK-M1-FND-011: Implementar autenticação JWT
- [ ] TASK-M1-FND-012: Configurar middleware de segurança
- [ ] TASK-M1-FND-013: Implementar permissões
- [ ] TASK-M1-FND-014: Implementar refresh token
- [ ] TASK-M1-FND-015: Escrever testes de segurança

## 🏷️ Metadados
**ID:** STORY-M1-FND-003
**Squad:** Foundation
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-FND-001
**Responsável:** @Marcus1423"""
    },
    
    # === SQUAD CORE BUSINESS ===
    {
        'id': 'STORY-M1-CORE-001',
        'title': 'Cadastro de Costureiras',
        'epic_id': 'EPIC-M1-CORE-001',
        'epic_title': '[EPIC-M1-CORE-001] [Epic] Lógica de Carga e CRUD',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'Matheus-G-R',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'core-business'],
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero cadastrar minhas costureiras para controlar sua produção e capacidade.

## ✅ Critérios de Aceite
- [ ] Modelo Costureira criado (nome, contato, observações, especialidade)
- [ ] Serializers implementados
- [ ] Endpoints CRUD completos (GET, POST, PUT, DELETE)
- [ ] Validações de campos obrigatórios e unicidade
- [ ] Testes unitários

## 📋 Tarefas
- [ ] TASK-M1-CORE-001: Criar model Costureira
- [ ] TASK-M1-CORE-002: Implementar serializers
- [ ] TASK-M1-CORE-003: Implementar endpoints CRUD
- [ ] TASK-M1-CORE-004: Adicionar validações
- [ ] TASK-M1-CORE-005: Escrever testes unitários

## 🏷️ Metadados
**ID:** STORY-M1-CORE-001
**Squad:** Core Business
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-CORE-001
**Responsável:** @Matheus-G-R"""
    },
    {
        'id': 'STORY-M1-CORE-002',
        'title': 'CRUD de Serviços',
        'epic_id': 'EPIC-M1-CORE-001',
        'epic_title': '[EPIC-M1-CORE-001] [Epic] Lógica de Carga e CRUD',
        'milestone': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'assignee': 'Matheus-G-R',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'core-business'],
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero registrar os serviços enviados para as costureiras para controlar o fluxo de produção.

## ✅ Critérios de Aceite
- [ ] Modelo Servico criado (cliente, produto, quantidade, data_envio, prazo, status, valor, complexidade)
- [ ] Serializers implementados com validações
- [ ] Endpoints CRUD completos
- [ ] Filtros por status e costureira
- [ ] Testes unitários

## 📋 Tarefas
- [ ] TASK-M1-CORE-006: Criar model Servico
- [ ] TASK-M1-CORE-007: Implementar serializers
- [ ] TASK-M1-CORE-008: Implementar endpoints CRUD
- [ ] TASK-M1-CORE-009: Adicionar filtros
- [ ] TASK-M1-CORE-010: Escrever testes unitários

## 🏷️ Metadados
**ID:** STORY-M1-CORE-002
**Squad:** Core Business
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-CORE-001
**Responsável:** @Matheus-G-R"""
    },
    {
        'id': 'STORY-M1-CORE-003',
        'title': 'Cálculo de Capacidade',
        'epic_id': 'EPIC-M1-CORE-001',
        'epic_title': '[EPIC-M1-CORE-001] [Epic] Lógica de Carga e CRUD',
        'milestone': 'MVP 1 - Sprint 3: Inteligência de Capacidade',
        'assignee': 'Matheus-G-R',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'core-business'],
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero visualizar a carga de trabalho de cada costureira para distribuir melhor os serviços.

## ✅ Critérios de Aceite
- [ ] Função de cálculo de carga implementada
- [ ] Índice de complexidade (P/M/G/Esp) integrado
- [ ] Endpoint de consulta de carga atual
- [ ] Lógica de sugestão de alocação
- [ ] Testes unitários e de integração

## 📋 Tarefas
- [ ] TASK-M1-CORE-011: Implementar função de cálculo de carga
- [ ] TASK-M1-CORE-012: Integrar índice de complexidade
- [ ] TASK-M1-CORE-013: Criar endpoint de consulta de carga
- [ ] TASK-M1-CORE-014: Implementar lógica de sugestão de alocação
- [ ] TASK-M1-CORE-015: Escrever testes

## 🏷️ Metadados
**ID:** STORY-M1-CORE-003
**Squad:** Core Business
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-CORE-001
**Responsável:** @Matheus-G-R"""
    },
    
    # === SQUAD UX & EXPERIENCE ===
    {
        'id': 'STORY-M1-UX-001',
        'title': 'Layout Base e Design System',
        'epic_id': 'EPIC-M1-UX-001',
        'epic_title': '[EPIC-M1-UX-001] [Epic] Interface e Jornada do Usuário',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'gabrielaugusto872',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'ux-experience'],
        'body': """## 📖 User Story
Como usuária da Cony Interiores, quero uma interface visualmente agradável e consistente para navegar pelo sistema com facilidade.

## ✅ Critérios de Aceite
- [ ] Tailwind CSS configurado com tema da Cony Interiores
- [ ] Componentes base criados (Button, Input, Card, Table)
- [ ] Layout principal implementado (Header, Sidebar, Footer)
- [ ] Página Home com visão geral
- [ ] Responsividade (mobile-first)

## 📋 Tarefas
- [ ] TASK-M1-UX-001: Configurar Tailwind CSS
- [ ] TASK-M1-UX-002: Criar componentes base
- [ ] TASK-M1-UX-003: Implementar layout principal
- [ ] TASK-M1-UX-004: Criar página Home
- [ ] TASK-M1-UX-005: Garantir responsividade

## 🏷️ Metadados
**ID:** STORY-M1-UX-001
**Squad:** UX & Experience
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-UX-001
**Responsável:** @gabrielaugusto872"""
    },
    {
        'id': 'STORY-M1-UX-002',
        'title': 'Formulários e Integração API',
        'epic_id': 'EPIC-M1-UX-001',
        'epic_title': '[EPIC-M1-UX-001] [Epic] Interface e Jornada do Usuário',
        'milestone': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'assignee': 'Bianca2703',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'ux-experience'],
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero cadastrar e editar costureiras através de formulários intuitivos integrados com a API.

## ✅ Critérios de Aceite
- [ ] Página de listagem de costureiras
- [ ] Formulário de cadastro/edição de costureiras
- [ ] Integração com API (Axios)
- [ ] Validações e feedback visual (toasts/alertas)
- [ ] Roteamento entre páginas

## 📋 Tarefas
- [ ] TASK-M1-UX-006: Criar página de listagem de costureiras
- [ ] TASK-M1-UX-007: Implementar formulário de cadastro/edição
- [ ] TASK-M1-UX-008: Integrar com API
- [ ] TASK-M1-UX-009: Adicionar validações e feedback
- [ ] TASK-M1-UX-010: Implementar roteamento

## 🏷️ Metadados
**ID:** STORY-M1-UX-002
**Squad:** UX & Experience
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-UX-001
**Responsável:** @Bianca2703"""
    },
    {
        'id': 'STORY-M1-UX-003',
        'title': 'Visualização de Carga',
        'epic_id': 'EPIC-M1-UX-001',
        'epic_title': '[EPIC-M1-UX-001] [Epic] Interface e Jornada do Usuário',
        'milestone': 'MVP 1 - Sprint 3: Inteligência de Capacidade',
        'assignee': 'isabarrs',  # <-- CORRIGIDO
        'labels': ['story', 'mvp1', 'ux-experience'],
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero visualizar a carga de trabalho de cada costureira em gráficos para tomar decisões de alocação.

## ✅ Critérios de Aceite
- [ ] Página de visualização de capacidade
- [ ] Cards com carga atual (quantidade + complexidade)
- [ ] Gráfico comparativo entre costureiras (Chart.js)
- [ ] Filtros por período e tipo de serviço
- [ ] Integração com API de cálculo de capacidade

## 📋 Tarefas
- [ ] TASK-M1-UX-011: Criar página de visualização de capacidade
- [ ] TASK-M1-UX-012: Implementar cards de carga
- [ ] TASK-M1-UX-013: Criar gráfico comparativo
- [ ] TASK-M1-UX-014: Implementar filtros
- [ ] TASK-M1-UX-015: Integrar com API

## 🏷️ Metadados
**ID:** STORY-M1-UX-003
**Squad:** UX & Experience
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-UX-001
**Responsável:** @isabarrs"""
    },
]

# ============================================================
# FUNÇÕES DA API
# ============================================================

def get_milestone_number(title):
    """Busca o número do milestone pelo título"""
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for ms in r.json():
            if ms['title'] == title:
                return ms['number']
    return None

def get_epic_number_by_title(epic_title):
    """Busca o número da issue do épico pelo título"""
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if epic_title in issue['title']:
                return issue['number']
    return None

def issue_exists(title):
    """Verifica se uma issue com o título já existe"""
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if issue['title'] == title:
                return True
    return False

def create_issue(title, body, labels, milestone_number, assignee=None):
    """Cria uma issue no repositório"""
    url = f"{BASE_URL}/issues"
    data = {
        'title': title,
        'body': body,
        'labels': labels,
        'milestone': milestone_number
    }
    if assignee:
        data['assignees'] = [assignee]
    
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def add_comment(issue_number, body):
    """Adiciona um comentário à issue"""
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    data = {'body': body}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       CRIAÇÃO DE STORIES (COM ASSIGNEES CORRETOS)
       Cony Interiores - MVP 1
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # Cache
    milestone_cache = {}
    epic_cache = {}
    
    created = 0
    skipped = 0
    errors = 0
    
    for story in STORIES:
        print(f"\n📖 Processando: {story['id']}")
        print(f"   Responsável: @{story['assignee']}")
        
        # Busca milestone
        if story['milestone'] not in milestone_cache:
            milestone_cache[story['milestone']] = get_milestone_number(story['milestone'])
        
        milestone_number = milestone_cache[story['milestone']]
        if not milestone_number:
            print(f"   ⚠️ Milestone '{story['milestone']}' não encontrado!")
            errors += 1
            continue
        
        # Busca épico
        if story['epic_title'] not in epic_cache:
            epic_cache[story['epic_title']] = get_epic_number_by_title(story['epic_title'])
        
        epic_number = epic_cache[story['epic_title']]
        if not epic_number:
            print(f"   ⚠️ Épico '{story['epic_title']}' não encontrado!")
            errors += 1
            continue
        
        # Título com ID
        full_title = f"[{story['id']}] Story: {story['title']}"
        
        # Verifica se já existe
        if issue_exists(full_title):
            print(f"   ℹ️ Story já existe: {full_title}")
            skipped += 1
            continue
        
        # Cria a story
        result = create_issue(
            title=full_title,
            body=story['body'],
            labels=story['labels'],
            milestone_number=milestone_number,
            assignee=story.get('assignee')
        )
        
        if result.status_code == 201:
            issue_number = result.json()['number']
            print(f"   ✅ Story criada: #{issue_number} - {full_title}")
            created += 1
            
            # Comentário vinculando ao épico
            comment_body = f"🔗 Esta Story faz parte do Épico #{epic_number} - {story['epic_title']}"
            add_comment(issue_number, comment_body)
            
            time.sleep(1)
            
        elif result.status_code == 422:
            print(f"   ⚠️ Erro de validação: {result.text[:150]}")
            errors += 1
        else:
            print(f"   ❌ Erro ao criar story: {result.status_code}")
            print(f"   {result.text[:200]}")
            errors += 1
        
        time.sleep(0.5)
    
    print(f"""
    ==============================================
    ✅ CRIAÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Stories criadas: {created}
       Stories ignoradas (já existentes): {skipped}
       Erros: {errors}
    
    🔗 Acesse as issues:
    https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)

if __name__ == "__main__":
    main()
