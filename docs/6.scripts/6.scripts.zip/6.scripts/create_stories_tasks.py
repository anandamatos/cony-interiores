#!/usr/bin/env python3
"""
Script para criar Stories e Tasks com IDs padronizados
"""
import os
import requests
import json
import time

# ============================================================
# CONFIGURAÇÕES
# ============================================================

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    print("   Execute: export GITHUB_TOKEN=seu_token")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# DEFINIÇÃO DAS STORIES E TASKS
# ============================================================

STORIES_DATA = {
    # ===== SQUAD FOUNDATION =====
    'STORY-M1-FND-001': {
        'title': 'Story: Configuração do Backend Django',
        'epic': '[Epic] Infraestrutura e Base Técnica',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'marcusvinicius',
        'body': """## 📖 User Story
Como desenvolvedor backend, quero ter o Django configurado com DRF e PostgreSQL para poder iniciar o desenvolvimento da API.

## ✅ Critérios de Aceite
- [ ] Projeto Django inicializado
- [ ] Django REST Framework configurado
- [ ] PostgreSQL conectado via Docker
- [ ] CORS configurado
- [ ] Logging estruturado implementado

## 📋 Tarefas
- TASK-M1-FND-001: Inicializar projeto Django
- TASK-M1-FND-002: Configurar DRF
- TASK-M1-FND-003: Configurar PostgreSQL no docker-compose
- TASK-M1-FND-004: Configurar CORS
- TASK-M1-FND-005: Implementar logging estruturado

## 🏷️ Metadados
**ID:** STORY-M1-FND-001
**Squad:** Foundation
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    'STORY-M1-FND-002': {
        'title': 'Story: Configuração do Frontend React',
        'epic': '[Epic] Infraestrutura e Base Técnica',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'mariagabrielle',
        'body': """## 📖 User Story
Como desenvolvedor frontend, quero ter o React configurado com Vite, Router e Axios para iniciar o desenvolvimento da interface.

## ✅ Critérios de Aceite
- [ ] Projeto React com Vite inicializado
- [ ] React Router configurado
- [ ] Axios configurado para comunicação com API
- [ ] ESLint e Prettier configurados
- [ ] Husky configurado para pre-commit hooks

## 📋 Tarefas
- TASK-M1-FND-006: Inicializar projeto React com Vite
- TASK-M1-FND-007: Configurar React Router
- TASK-M1-FND-008: Configurar Axios
- TASK-M1-FND-009: Configurar ESLint e Prettier
- TASK-M1-FND-010: Configurar Husky

## 🏷️ Metadados
**ID:** STORY-M1-FND-002
**Squad:** Foundation
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    'STORY-M1-FND-003': {
        'title': 'Story: Autenticação e Segurança',
        'epic': '[Epic] Infraestrutura e Base Técnica',
        'milestone': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'assignee': 'marcusvinicius',
        'body': """## 📖 User Story
Como desenvolvedor backend, quero implementar autenticação JWT e segurança para proteger os endpoints da API.

## ✅ Critérios de Aceite
- [ ] Autenticação JWT implementada
- [ ] Middleware de segurança configurado
- [ ] Sistema de permissões implementado
- [ ] Refresh token funcional
- [ ] Testes de segurança

## 📋 Tarefas
- TASK-M1-FND-011: Implementar autenticação JWT
- TASK-M1-FND-012: Configurar middleware de segurança
- TASK-M1-FND-013: Implementar permissões
- TASK-M1-FND-014: Implementar refresh token
- TASK-M1-FND-015: Escrever testes de segurança

## 🏷️ Metadados
**ID:** STORY-M1-FND-003
**Squad:** Foundation
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    
    # ===== SQUAD CORE BUSINESS =====
    'STORY-M1-CORE-001': {
        'title': 'Story: Cadastro de Costureiras',
        'epic': '[Epic] Lógica de Carga e CRUD',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'matheusgoncalves',
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero cadastrar minhas costureiras para controlar sua produção e capacidade.

## ✅ Critérios de Aceite
- [ ] Modelo Costureira criado (nome, contato, observações, especialidade)
- [ ] Serializers implementados
- [ ] Endpoints CRUD completos (GET, POST, PUT, DELETE)
- [ ] Validações de campos obrigatórios e unicidade
- [ ] Testes unitários

## 📋 Tarefas
- TASK-M1-CORE-001: Criar model Costureira
- TASK-M1-CORE-002: Implementar serializers
- TASK-M1-CORE-003: Implementar endpoints CRUD
- TASK-M1-CORE-004: Adicionar validações
- TASK-M1-CORE-005: Escrever testes unitários

## 🏷️ Metadados
**ID:** STORY-M1-CORE-001
**Squad:** Core Business
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    'STORY-M1-CORE-002': {
        'title': 'Story: CRUD de Serviços',
        'epic': '[Epic] Lógica de Carga e CRUD',
        'milestone': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'assignee': 'matheusgoncalves',
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero registrar os serviços enviados para as costureiras para controlar o fluxo de produção.

## ✅ Critérios de Aceite
- [ ] Modelo Servico criado (cliente, produto, quantidade, data_envio, prazo, status, valor, complexidade)
- [ ] Serializers implementados com validações
- [ ] Endpoints CRUD completos
- [ ] Filtros por status e costureira
- [ ] Testes unitários

## 📋 Tarefas
- TASK-M1-CORE-006: Criar model Servico
- TASK-M1-CORE-007: Implementar serializers
- TASK-M1-CORE-008: Implementar endpoints CRUD
- TASK-M1-CORE-009: Adicionar filtros
- TASK-M1-CORE-010: Escrever testes unitários

## 🏷️ Metadados
**ID:** STORY-M1-CORE-002
**Squad:** Core Business
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    'STORY-M1-CORE-003': {
        'title': 'Story: Cálculo de Capacidade',
        'epic': '[Epic] Lógica de Carga e CRUD',
        'milestone': 'MVP 1 - Sprint 3: Inteligência de Capacidade',
        'assignee': 'matheusgoncalves',
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero visualizar a carga de trabalho de cada costureira para distribuir melhor os serviços.

## ✅ Critérios de Aceite
- [ ] Função de cálculo de carga implementada
- [ ] Índice de complexidade (P/M/G/Esp) integrado
- [ ] Endpoint de consulta de carga atual
- [ ] Lógica de sugestão de alocação
- [ ] Testes unitários e de integração

## 📋 Tarefas
- TASK-M1-CORE-011: Implementar função de cálculo de carga
- TASK-M1-CORE-012: Integrar índice de complexidade
- TASK-M1-CORE-013: Criar endpoint de consulta de carga
- TASK-M1-CORE-014: Implementar lógica de sugestão de alocação
- TASK-M1-CORE-015: Escrever testes

## 🏷️ Metadados
**ID:** STORY-M1-CORE-003
**Squad:** Core Business
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    
    # ===== SQUAD UX & EXPERIENCE =====
    'STORY-M1-UX-001': {
        'title': 'Story: Layout Base e Design System',
        'epic': '[Epic] Interface e Jornada do Usuário',
        'milestone': 'MVP 1 - Sprint 1: Base Digital',
        'assignee': 'gabrielaugusto',
        'body': """## 📖 User Story
Como usuária da Cony Interiores, quero uma interface visualmente agradável e consistente para navegar pelo sistema com facilidade.

## ✅ Critérios de Aceite
- [ ] Tailwind CSS configurado com tema da Cony Interiores
- [ ] Componentes base criados (Button, Input, Card, Table)
- [ ] Layout principal implementado (Header, Sidebar, Footer)
- [ ] Página Home com visão geral
- [ ] Responsividade (mobile-first)

## 📋 Tarefas
- TASK-M1-UX-001: Configurar Tailwind CSS
- TASK-M1-UX-002: Criar componentes base
- TASK-M1-UX-003: Implementar layout principal
- TASK-M1-UX-004: Criar página Home
- TASK-M1-UX-005: Garantir responsividade

## 🏷️ Metadados
**ID:** STORY-M1-UX-001
**Squad:** UX & Experience
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    'STORY-M1-UX-002': {
        'title': 'Story: Formulários e Integração API',
        'epic': '[Epic] Interface e Jornada do Usuário',
        'milestone': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'assignee': 'bianca',
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero cadastrar e editar costureiras através de formulários intuitivos integrados com a API.

## ✅ Critérios de Aceite
- [ ] Página de listagem de costureiras
- [ ] Formulário de cadastro/edição de costureiras
- [ ] Integração com API (Axios)
- [ ] Validações e feedback visual (toasts/alertas)
- [ ] Roteamento entre páginas

## 📋 Tarefas
- TASK-M1-UX-006: Criar página de listagem de costureiras
- TASK-M1-UX-007: Implementar formulário de cadastro/edição
- TASK-M1-UX-008: Integrar com API
- TASK-M1-UX-009: Adicionar validações e feedback
- TASK-M1-UX-010: Implementar roteamento

## 🏷️ Metadados
**ID:** STORY-M1-UX-002
**Squad:** UX & Experience
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
    'STORY-M1-UX-003': {
        'title': 'Story: Visualização de Carga',
        'epic': '[Epic] Interface e Jornada do Usuário',
        'milestone': 'MVP 1 - Sprint 3: Inteligência de Capacidade',
        'assignee': 'isabellabarros',
        'body': """## 📖 User Story
Como gestora da Cony Interiores, quero visualizar a carga de trabalho de cada costureira em gráficos para tomar decisões de alocação.

## ✅ Critérios de Aceite
- [ ] Página de visualização de capacidade
- [ ] Cards com carga atual (quantidade + complexidade)
- [ ] Gráfico comparativo entre costureiras (Chart.js)
- [ ] Filtros por período e tipo de serviço
- [ ] Integração com API de cálculo de capacidade

## 📋 Tarefas
- TASK-M1-UX-011: Criar página de visualização de capacidade
- TASK-M1-UX-012: Implementar cards de carga
- TASK-M1-UX-013: Criar gráfico comparativo
- TASK-M1-UX-014: Implementar filtros
- TASK-M1-UX-015: Integrar com API

## 🏷️ Metadados
**ID:** STORY-M1-UX-003
**Squad:** UX & Experience
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points"""
    },
}

# ============================================================
# FUNÇÕES DA API
# ============================================================

def get_milestone_number(title):
    """Busca o número do milestone pelo título"""
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for ms in r.json():
            if ms['title'] == title:
                return ms['number']
    return None

def get_epic_number(title):
    """Busca o número da issue do épico pelo título"""
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if issue['title'] == title or f'[EPIC' in issue['title'] and title in issue['title']:
                return issue['number']
    return None

def create_issue(title, body, labels, milestone_number, assignee=None):
    """Cria uma issue no repositório"""
    url = f"{BASE_URL}/issues"
    data = {
        'title': title,
        'body': body,
        'labels': labels,
        'milestone': milestone_number
    }
    if assignee:
        data['assignees'] = [assignee]
    
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def create_comment(issue_number, body):
    """Adiciona um comentário à issue"""
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    data = {'body': body}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       CRIAÇÃO DE STORIES E TASKS
       Cony Interiores - MVP 1
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}")
    print(f"📋 Token: {GITHUB_TOKEN[:10]}...\n")
    
    # Cache para milestones e épicos
    milestone_cache = {}
    epic_cache = {}
    
    created = 0
    skipped = 0
    
    for story_id, story_data in STORIES_DATA.items():
        print(f"\n📖 Processando: {story_id}")
        
        # Busca milestone
        milestone_title = story_data['milestone']
        if milestone_title not in milestone_cache:
            milestone_cache[milestone_title] = get_milestone_number(milestone_title)
        
        milestone_number = milestone_cache[milestone_title]
        if not milestone_number:
            print(f"   ⚠️ Milestone '{milestone_title}' não encontrado!")
            continue
        
        # Busca épico
        epic_title = story_data['epic']
        if epic_title not in epic_cache:
            epic_cache[epic_title] = get_epic_number(epic_title)
        
        epic_number = epic_cache[epic_title]
        if not epic_number:
            print(f"   ⚠️ Épico '{epic_title}' não encontrado!")
            continue
        
        # Título da story com ID
        full_title = f"[{story_id}] {story_data['title']}"
        
        # Labels
        labels = ['story', 'mvp1']
        if 'Foundation' in story_data['body']:
            labels.append('foundation')
        elif 'Core Business' in story_data['body']:
            labels.append('core-business')
        elif 'UX & Experience' in story_data['body']:
            labels.append('ux-experience')
        
        # Cria a story
        result = create_issue(
            title=full_title,
            body=story_data['body'],
            labels=labels,
            milestone_number=milestone_number,
            assignee=story_data.get('assignee')
        )
        
        if result.status_code == 201:
            issue_number = result.json()['number']
            print(f"   ✅ Story criada: #{issue_number} - {full_title}")
            created += 1
            
            # Comentário vinculando ao épico
            comment_body = f"🔗 Esta Story faz parte do Épico #{epic_number} - {epic_title}"
            create_comment(issue_number, comment_body)
            
            # Pequena pausa para evitar rate limit
            time.sleep(1)
            
        elif result.status_code == 422:
            print(f"   ℹ️ Story já existe ou erro de validação")
            skipped += 1
        else:
            print(f"   ❌ Erro ao criar story: {result.status_code}")
            print(f"   {result.text[:200]}")
    
    print(f"""
    ==============================================
    ✅ CRIAÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Stories criadas: {created}
       Stories ignoradas (já existentes): {skipped}
    
    🔗 Acesse as issues:
    https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)

if __name__ == "__main__":
    main()
