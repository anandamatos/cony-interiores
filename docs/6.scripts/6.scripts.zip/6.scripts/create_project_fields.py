#!/usr/bin/env python3
"""
Script para criar campos personalizados no GitHub Project
Corrige a criação de campos após o projeto estar criado
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS_GRAPHQL = {
    'Authorization': f'Bearer {GITHUB_TOKEN}',
    'Content-Type': 'application/json',
}

def execute_graphql(query):
    """Executa uma query GraphQL"""
    r = requests.post('https://api.github.com/graphql', headers=HEADERS_GRAPHQL, json={'query': query})
    return r

def get_project_id():
    """Busca o ID do projeto pelo nome"""
    query = """
    {
      user(login: "%s") {
        projectsV2(first: 10) {
          nodes {
            id
            title
            number
          }
        }
      }
    }
    """ % REPO_OWNER
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        projects = data.get('data', {}).get('user', {}).get('projectsV2', {}).get('nodes', [])
        for project in projects:
            if 'Cony Interiores' in project.get('title', ''):
                return project['id'], project['number']
    return None, None

def create_project_field(project_id, name, data_type):
    """Cria um campo personalizado no projeto"""
    mutation = """
    mutation {
      createProjectV2Field(input: {
        projectId: "%s"
        name: "%s"
        dataType: %s
      }) {
        projectV2Field {
          id
          name
          dataType
        }
      }
    }
    """ % (project_id, name, data_type)
    
    r = execute_graphql(mutation)
    if r.status_code == 200:
        data = r.json()
        if 'errors' in data:
            print(f"   ❌ Erro ao criar campo '{name}': {data['errors']}")
            return None
        field = data.get('data', {}).get('createProjectV2Field', {}).get('projectV2Field', {})
        return field.get('id')
    else:
        print(f"   ❌ Erro HTTP ao criar campo '{name}': {r.status_code}")
        return None

def create_single_select_options(project_id, field_id, options):
    """Adiciona opções a um campo do tipo SINGLE_SELECT"""
    # Nota: A API para adicionar opções individualmente é limitada.
    # Uma abordagem alternativa é usar a mutação updateProjectV2Field para definir as opções.
    # No entanto, a API para isso não está totalmente documentada.
    # A maneira mais confiável é criar o campo com as opções via mutation createProjectV2Field,
    # mas a sintaxe correta é complexa e muitas vezes falha.
    # Portanto, recomendamos criar os campos via script e adicionar as opções manualmente na interface web.
    print(f"   ℹ️ Campo '{field_id}' criado. Configure as opções manualmente no GitHub: {options}")

def main():
    print("""
    🚀 ==============================================
       SCRIPT: CRIAÇÃO DE CAMPOS PERSONALIZADOS
       Para o GitHub Project
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # Busca o projeto
    project_id, project_number = get_project_id()
    if not project_id:
        print(f"❌ Projeto não encontrado!")
        return
    
    print(f"📊 Projeto encontrado: ID {project_id}, Nº {project_number}\n")
    print("🏷️ CRIANDO CAMPOS PERSONALIZADOS...")
    
    # Lista de campos a serem criados
    fields = [
        {'name': 'MVP', 'dataType': 'SINGLE_SELECT', 'options': ['MVP 1', 'MVP 2', 'MVP 3', 'MVP 4', 'MVP 5', 'Final']},
        {'name': 'Squad', 'dataType': 'SINGLE_SELECT', 'options': ['Foundation', 'Core Business', 'UX & Experience']},
        {'name': 'Tipo', 'dataType': 'SINGLE_SELECT', 'options': ['Epic', 'Story', 'Task', 'Bug']},
        {'name': 'Prioridade', 'dataType': 'SINGLE_SELECT', 'options': ['P0', 'P1', 'P2']},
        {'name': 'Status', 'dataType': 'SINGLE_SELECT', 'options': ['Backlog', 'Planned', 'In Progress', 'Review', 'Done']},
        {'name': 'Story Points', 'dataType': 'NUMBER', 'options': None},
    ]
    
    for field in fields:
        print(f"\n📌 Criando campo: {field['name']}")
        field_id = create_project_field(project_id, field['name'], field['dataType'])
        
        if field_id:
            print(f"   ✅ Campo '{field['name']}' criado (ID: {field_id})")
            if field['options']:
                print(f"   ⚠️ Adicione as opções manualmente: {', '.join(field['options'])}")
        else:
            # Verifica se o campo já existe (erro 422)
            print(f"   ℹ️ Campo '{field['name']}' pode já existir")
        
        time.sleep(0.5)
    
    print(f"""
    ==============================================
    ✅ CRIAÇÃO DE CAMPOS CONCLUÍDA!
    ==============================================
    
    📋 Próximos passos:
    1. Acesse as configurações do projeto:
       https://github.com/users/{REPO_OWNER}/projects/{project_number}/settings/fields
    
    2. Para campos SINGLE_SELECT, adicione as opções manualmente:
       - MVP: MVP 1, MVP 2, MVP 3, MVP 4, MVP 5, Final
       - Squad: Foundation, Core Business, UX & Experience
       - Tipo: Epic, Story, Task, Bug
       - Prioridade: P0, P1, P2
       - Status: Backlog, Planned, In Progress, Review, Done
    
    3. Execute o Script 3 novamente para preencher os campos:
       python setup_mvp1_planning.py
    """)

if __name__ == "__main__":
    main()
