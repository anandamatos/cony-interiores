#!/usr/bin/env python3
"""
Script para atualizar stories existentes com IDs padronizados
"""
import os
import requests
import json
import re
import time

# ============================================================
# CONFIGURAÇÕES
# ============================================================

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    print("   Execute: export GITHUB_TOKEN=seu_token")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# MAPEAMENTO DOS IDs PARA STORIES EXISTENTES
# ============================================================

STORY_ID_MAP = {
    # Foundation
    'Story: Configuração do Backend Django': 'STORY-M1-FND-001',
    'Story: Configuração do Frontend React': 'STORY-M1-FND-002',
    'Story: Autenticação e Segurança': 'STORY-M1-FND-003',
    
    # Core Business
    'Story: Cadastro de Costureiras': 'STORY-M1-CORE-001',
    'Story: CRUD de Serviços': 'STORY-M1-CORE-002',
    'Story: Cálculo de Capacidade': 'STORY-M1-CORE-003',
    
    # UX & Experience
    'Story: Layout Base e Design System': 'STORY-M1-UX-001',
    'Story: Formulários e Integração API': 'STORY-M1-UX-002',
    'Story: Visualização de Carga': 'STORY-M1-UX-003',
}

# ============================================================
# FUNÇÃO PARA ATUALIZAR ISSUE
# ============================================================

def update_issue(issue_number, new_title, new_body, labels):
    """Atualiza uma issue existente"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {
        'title': new_title,
        'body': new_body,
        'labels': labels
    }
    r = requests.patch(url, headers=HEADERS, json=data)
    return r

# ============================================================
# FUNÇÃO PARA ADICIONAR COMENTÁRIO COM LISTA DE TAREFAS
# ============================================================

def add_task_list_comment(issue_number, story_id):
    """Adiciona a lista de tarefas como comentário"""
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    
    # Mapeamento de tarefas por story
    task_map = {
        'STORY-M1-FND-001': ['TASK-M1-FND-001', 'TASK-M1-FND-002', 'TASK-M1-FND-003', 'TASK-M1-FND-004', 'TASK-M1-FND-005'],
        'STORY-M1-FND-002': ['TASK-M1-FND-006', 'TASK-M1-FND-007', 'TASK-M1-FND-008', 'TASK-M1-FND-009', 'TASK-M1-FND-010'],
        'STORY-M1-FND-003': ['TASK-M1-FND-011', 'TASK-M1-FND-012', 'TASK-M1-FND-013', 'TASK-M1-FND-014', 'TASK-M1-FND-015'],
        'STORY-M1-CORE-001': ['TASK-M1-CORE-001', 'TASK-M1-CORE-002', 'TASK-M1-CORE-003', 'TASK-M1-CORE-004', 'TASK-M1-CORE-005'],
        'STORY-M1-CORE-002': ['TASK-M1-CORE-006', 'TASK-M1-CORE-007', 'TASK-M1-CORE-008', 'TASK-M1-CORE-009', 'TASK-M1-CORE-010'],
        'STORY-M1-CORE-003': ['TASK-M1-CORE-011', 'TASK-M1-CORE-012', 'TASK-M1-CORE-013', 'TASK-M1-CORE-014', 'TASK-M1-CORE-015'],
        'STORY-M1-UX-001': ['TASK-M1-UX-001', 'TASK-M1-UX-002', 'TASK-M1-UX-003', 'TASK-M1-UX-004', 'TASK-M1-UX-005'],
        'STORY-M1-UX-002': ['TASK-M1-UX-006', 'TASK-M1-UX-007', 'TASK-M1-UX-008', 'TASK-M1-UX-009', 'TASK-M1-UX-010'],
        'STORY-M1-UX-003': ['TASK-M1-UX-011', 'TASK-M1-UX-012', 'TASK-M1-UX-013', 'TASK-M1-UX-014', 'TASK-M1-UX-015'],
    }
    
    tasks = task_map.get(story_id, [])
    
    # Cria a lista de tarefas formatada
    task_list = "## 📋 Tarefas Vinculadas\n\n"
    task_list += "| ID | Título | Status |\n"
    task_list += "|----|--------|--------|\n"
    for task_id in tasks:
        task_list += f"| [{task_id}](https://github.com/{REPO_OWNER}/{REPO_NAME}/issues?q=is%3Aissue+{task_id}) | Tarefa a ser criada | ⬜ Pendente |\n"
    
    data = {'body': task_list}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       ATUALIZAÇÃO DE STORIES COM IDs
       Cony Interiores - MVP 1
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # Busca todas as issues abertas
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    
    if r.status_code != 200:
        print(f"❌ Erro ao buscar issues: {r.status_code}")
        return
    
    issues = r.json()
    print(f"📊 Encontradas {len(issues)} issues abertas\n")
    
    updated = 0
    for issue in issues:
        title = issue['title']
        number = issue['number']
        body = issue.get('body', '')
        current_labels = [label['name'] for label in issue.get('labels', [])]
        
        # Verifica se é uma story (pelo título ou labels)
        is_story = 'story' in current_labels or 'Story:' in title
        
        if is_story:
            # Encontra o ID correspondente
            story_id = None
            for original_title, sid in STORY_ID_MAP.items():
                if original_title in title:
                    story_id = sid
                    break
            
            if story_id:
                # Remove IDs existentes do título
                clean_title = re.sub(r'\[.*?\]\s*', '', title)
                new_title = f"[{story_id}] {clean_title.strip()}"
                
                # Adiciona metadados no corpo
                id_section = f"""
---
## 🏷️ Metadados
**ID:** {story_id}
**Squad:** {story_id.split('-')[2]}
**MVP:** {story_id.split('-')[1]}
**Tipo:** Story
---"""
                
                if '**ID:**' not in body:
                    new_body = body + id_section
                else:
                    new_body = body
                
                # Atualiza labels
                labels = ['story']
                if 'FND' in story_id:
                    labels.append('foundation')
                elif 'CORE' in story_id:
                    labels.append('core-business')
                elif 'UX' in story_id:
                    labels.append('ux-experience')
                
                # Atualiza a issue
                result = update_issue(number, new_title, new_body, labels)
                if result.status_code == 200:
                    print(f"✅ [{story_id}] Issue #{number} atualizada: {new_title}")
                    
                    # Adiciona lista de tarefas como comentário
                    time.sleep(1)
                    comment_result = add_task_list_comment(number, story_id)
                    if comment_result.status_code == 201:
                        print(f"   📋 Lista de tarefas adicionada à #{number}")
                    else:
                        print(f"   ⚠️ Erro ao adicionar lista de tarefas: {comment_result.status_code}")
                    
                    updated += 1
                else:
                    print(f"⚠️ Erro ao atualizar #{number}: {result.status_code}")
            else:
                print(f"ℹ️ Issue #{number} - '{title[:30]}...' não mapeada como story")
        else:
            print(f"ℹ️ Issue #{number} - '{title[:30]}...' ignorada (não é story)")
        
        time.sleep(0.5)
    
    print(f"\n✅ Atualização concluída! {updated} stories atualizadas.")

if __name__ == "__main__":
    main()
