#!/usr/bin/env python3
"""
Script para atualizar épicos com IDs padronizados
"""
import os
import requests
import json

# ============================================================
# CONFIGURAÇÕES
# ============================================================

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    print("   Execute: export GITHUB_TOKEN=seu_token")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# MAPEAMENTO DOS IDs
# ============================================================

EPIC_IDS = {
    '[Epic] Infraestrutura e Base Técnica': {
        'id': 'EPIC-M1-FND-001',
        'squad': 'Foundation',
        'mvp': 'MVP 1'
    },
    '[Epic] Lógica de Carga e CRUD': {
        'id': 'EPIC-M1-CORE-001',
        'squad': 'Core Business',
        'mvp': 'MVP 1'
    },
    '[Epic] Interface e Jornada do Usuário': {
        'id': 'EPIC-M1-UX-001',
        'squad': 'UX & Experience',
        'mvp': 'MVP 1'
    }
}

# ============================================================
# FUNÇÃO PARA ATUALIZAR ISSUE
# ============================================================

def update_issue(issue_number, new_title, new_body):
    """Atualiza uma issue existente"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'title': new_title, 'body': new_body}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       ATUALIZAÇÃO DE ÉPICOS COM IDs
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}")
    print(f"📋 Token: {GITHUB_TOKEN[:10]}...\n")
    
    # Busca todas as issues abertas
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    
    if r.status_code != 200:
        print(f"❌ Erro ao buscar issues: {r.status_code}")
        return
    
    issues = r.json()
    print(f"📊 Encontradas {len(issues)} issues abertas\n")
    
    updated = 0
    for issue in issues:
        title = issue['title']
        number = issue['number']
        body = issue.get('body', '')
        
        if title in EPIC_IDS:
            epic_data = EPIC_IDS[title]
            epic_id = epic_data['id']
            
            # Novo título com ID
            new_title = f"[{epic_id}] {title}"
            
            # Adiciona o ID e metadados no corpo da issue
            id_section = f"""
---
## 🏷️ Metadados
**ID:** {epic_id}
**Squad:** {epic_data['squad']}
**MVP:** {epic_data['mvp']}
**Tipo:** Épico
---"""
            
            # Verifica se já tem a seção de metadados
            if '**ID:**' not in body:
                new_body = body + id_section
            else:
                new_body = body
            
            result = update_issue(number, new_title, new_body)
            if result.status_code == 200:
                print(f"✅ [{epic_id}] Issue #{number} atualizada: {new_title}")
                updated += 1
            else:
                print(f"⚠️ Erro ao atualizar #{number}: {result.status_code}")
        else:
            print(f"ℹ️ Issue #{number} - '{title[:30]}...' não é um épico mapeado")
    
    print(f"\n✅ Atualização concluída! {updated} épicos atualizados.")

if __name__ == "__main__":
    main()
