#!/usr/bin/env python3
"""
Script: Corrigir Stories Faltantes do MVP 1
Verifica e cria stories que não foram geradas
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# DEFINIÇÃO DAS STORIES FALTANTES DO MVP 1
# ============================================================

# Mapeamento de membros
MEMBERS = {
    'STORY-M1-UX-003': {'assignee': 'isabarrs', 'squad': 'UX & Experience'},
}

LEADERS = {
    'UX & Experience': 'anandamatos'
}

# Story faltante
MISSING_STORIES = [
    {
        'id': 'STORY-M1-UX-003',
        'title': 'Visualização de Carga',
        'epic_id': 'EPIC-M1-UX-001',
        'sprint': 'MVP 1 - Sprint 3: Inteligência de Capacidade',
        'story_points': 5,
        'priority': 'P1',
        'tasks': [
            'TASK-M1-UX-011: Criar página de visualização de capacidade',
            'TASK-M1-UX-012: Implementar cards de carga',
            'TASK-M1-UX-013: Criar gráfico comparativo',
            'TASK-M1-UX-014: Implementar filtros',
            'TASK-M1-UX-015: Integrar com API'
        ],
        'discovery_tasks': [
            'Validar tipos de gráficos necessários',
            'Definir estrutura de cards de carga',
            'Mapear filtros por período e tipo',
            'Prototipar página de visualização',
            'Validar integração com API de capacidade'
        ],
        'measurement_tasks': [
            'Definir KPIs de visualização de dados',
            'Estabelecer tempo de renderização dos gráficos',
            'Criar métricas de usabilidade',
            'Definir testes de performance'
        ]
    }
]

# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def get_all_open_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def get_milestone_number(title):
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for ms in r.json():
            if ms['title'] == title:
                return ms['number']
    return None

def get_epic_number(epic_id):
    issues = get_all_open_issues()
    for issue in issues:
        if epic_id in issue['title']:
            return issue['number']
    return None

def issue_exists(title):
    issues = get_all_open_issues()
    for issue in issues:
        if issue['title'] == title:
            return True
    return False

def create_issue(title, body, labels, milestone_number, assignee=None):
    url = f"{BASE_URL}/issues"
    data = {'title': title, 'body': body, 'labels': labels, 'milestone': milestone_number}
    if assignee:
        data['assignees'] = [assignee]
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def add_comment(issue_number, body):
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    data = {'body': body}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def build_story_body(story):
    squad = MEMBERS.get(story['id'], {}).get('squad', 'N/A')
    assignee = MEMBERS.get(story['id'], {}).get('assignee', 'N/A')
    
    body = f"""## 📖 User Story
Como gestora da Cony Interiores, quero visualizar a carga de trabalho de cada costureira em gráficos para tomar decisões de alocação.

## ✅ Critérios de Aceite
- [ ] Página de visualização de capacidade
- [ ] Cards com carga atual (quantidade + complexidade)
- [ ] Gráfico comparativo entre costureiras (Chart.js)
- [ ] Filtros por período e tipo de serviço
- [ ] Integração com API de cálculo de capacidade

## 📋 Tarefas (Checklist)
"""
    for task in story['tasks']:
        body += f"- [ ] {task}\n"
    
    body += f"""
## 🔍 Tarefas de Discovery
"""
    for task in story['discovery_tasks']:
        body += f"- [ ] {task}\n"
    
    body += f"""
## 📊 Tarefas de Mensuração
"""
    for task in story['measurement_tasks']:
        body += f"- [ ] {task}\n"
    
    body += f"""
---
## 🏷️ Metadados
**ID:** {story['id']}
**Squad:** {squad}
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** {story['story_points']} Story Points
**Prioridade:** {story['priority']}
**Épico:** {story['epic_id']}
**Sprint:** {story['sprint']}
**Responsável:** @{assignee}
"""
    return body

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       SCRIPT: CORRIGIR STORIES FALTANTES DO MVP 1
       Verifica e cria stories que não foram geradas
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # 1. Verificar quais stories do MVP 1 existem
    print("🔍 VERIFICANDO STORIES EXISTENTES DO MVP 1...")
    issues = get_all_open_issues()
    
    existing_stories = []
    for issue in issues:
        if 'STORY-M1-' in issue['title']:
            existing_stories.append(issue['title'])
    
    print(f"\n   Stories existentes: {len(existing_stories)}")
    for story in existing_stories:
        print(f"      - {story[:60]}...")
    
    # 2. Verificar quais estão faltando
    print("\n📋 VERIFICANDO STORIES FALTANTES...")
    
    all_story_ids = ['STORY-M1-FND-001', 'STORY-M1-FND-002', 'STORY-M1-FND-003',
                     'STORY-M1-CORE-001', 'STORY-M1-CORE-002', 'STORY-M1-CORE-003',
                     'STORY-M1-UX-001', 'STORY-M1-UX-002', 'STORY-M1-UX-003']
    
    missing = []
    for story_id in all_story_ids:
        found = False
        for title in existing_stories:
            if story_id in title:
                found = True
                break
        if not found:
            missing.append(story_id)
    
    if missing:
        print(f"\n   Stories faltantes: {len(missing)}")
        for story_id in missing:
            print(f"      - {story_id}")
    else:
        print("\n   ✅ Todas as 9 stories do MVP 1 estão criadas!")
        return
    
    # 3. Criar as stories faltantes
    print("\n📖 CRIANDO STORIES FALTANTES...")
    created = 0
    
    for story in MISSING_STORIES:
        story_id = story['id']
        print(f"\n   Processando: {story_id}")
        
        # Busca o épico
        epic_number = get_epic_number(story['epic_id'])
        if not epic_number:
            print(f"      ⚠️ Épico '{story['epic_id']}' não encontrado!")
            continue
        
        # Busca o milestone
        milestone_number = get_milestone_number(story['sprint'])
        if not milestone_number:
            print(f"      ⚠️ Milestone '{story['sprint']}' não encontrado!")
            continue
        
        assignee = MEMBERS.get(story['id'], {}).get('assignee')
        squad = MEMBERS.get(story['id'], {}).get('squad', '').lower().replace(' ', '-')
        labels = ['story', 'mvp1', squad] if squad else ['story', 'mvp1']
        title = f"[{story['id']}] Story: {story['title']}"
        body = build_story_body(story)
        
        # Verifica se já existe (dupla verificação)
        if issue_exists(title):
            print(f"      ℹ️ Story já existe: {title}")
            continue
        
        # Cria a story
        result = create_issue(title, body, labels, milestone_number, assignee)
        
        if result.status_code == 201:
            issue_number = result.json()['number']
            print(f"      ✅ Story criada: #{issue_number}")
            created += 1
            
            comment = f"🔗 Esta Story faz parte do Épico #{epic_number} - {story['epic_id']}"
            add_comment(issue_number, comment)
            
            # Atribui o líder
            leader = LEADERS.get(MEMBERS.get(story['id'], {}).get('squad', ''))
            if leader and assignee:
                url = f"{BASE_URL}/issues/{issue_number}"
                data = {'assignees': [leader, assignee]}
                requests.patch(url, headers=HEADERS, json=data)
                print(f"      ✅ Líder @{leader} e @{assignee} atribuídos")
            
            time.sleep(0.5)
        else:
            print(f"      ❌ Erro ao criar story: {result.status_code}")
    
    print(f"""
    ==============================================
    ✅ CORREÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Stories criadas: {created}
    
    🔗 Acesse:
       Issues: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)

if __name__ == "__main__":
    main()