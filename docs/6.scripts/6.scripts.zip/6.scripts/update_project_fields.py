#!/usr/bin/env python3
"""
Script para preencher os campos personalizados das issues no projeto
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS_GRAPHQL = {
    'Authorization': f'Bearer {GITHUB_TOKEN}',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# FUNÇÕES GRAPHQL
# ============================================================

def execute_graphql(query):
    r = requests.post('https://api.github.com/graphql', headers=HEADERS_GRAPHQL, json={'query': query})
    return r

def get_project_id():
    query = """
    {
      user(login: "%s") {
        projectsV2(first: 10) {
          nodes {
            id
            title
            number
          }
        }
      }
    }
    """ % REPO_OWNER
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        projects = data.get('data', {}).get('user', {}).get('projectsV2', {}).get('nodes', [])
        for project in projects:
            if 'Cony Interiores' in project.get('title', ''):
                return project['id'], project['number']
    return None, None

def get_field_ids(project_id):
    """Busca todos os campos do projeto e retorna um dicionário com nome -> id e opções"""
    query = """
    {
      node(id: "%s") {
        ... on ProjectV2 {
          fields(first: 20) {
            nodes {
              ... on ProjectV2Field {
                id
                name
                dataType
              }
              ... on ProjectV2SingleSelectField {
                id
                name
                dataType
                options {
                  id
                  name
                }
              }
            }
          }
        }
      }
    }
    """ % project_id
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        fields = data.get('data', {}).get('node', {}).get('fields', {}).get('nodes', [])
        
        field_map = {}
        for field in fields:
            field_data = {
                'id': field['id'],
                'dataType': field.get('dataType', ''),
            }
            if 'options' in field:
                field_data['options'] = {opt['name']: opt['id'] for opt in field['options']}
            field_map[field['name']] = field_data
        return field_map
    return {}

def get_project_items(project_id):
    """Busca todos os itens do projeto"""
    query = """
    {
      node(id: "%s") {
        ... on ProjectV2 {
          items(first: 50) {
            nodes {
              id
              content {
                ... on Issue {
                  id
                  number
                  title
                }
              }
            }
          }
        }
      }
    }
    """ % project_id
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        items = data.get('data', {}).get('node', {}).get('items', {}).get('nodes', [])
        return items
    return []

def update_project_item_field(project_id, item_id, field_id, value):
    mutation = """
    mutation {
      updateProjectV2ItemFieldValue(input: {
        projectId: "%s"
        itemId: "%s"
        fieldId: "%s"
        value: %s
      }) {
        projectV2Item {
          id
        }
      }
    }
    """ % (project_id, item_id, field_id, json.dumps(value))
    
    r = execute_graphql(mutation)
    if r.status_code == 200:
        data = r.json()
        if 'errors' not in data:
            return True
    return False

# ============================================================
# MAPEAMENTO DE SQUADS E PRIORIDADES
# ============================================================

# Mapeia o squad baseado no ID da story
STORY_SQUAD_MAP = {
    'STORY-M1-FND-001': 'Foundation',
    'STORY-M1-FND-002': 'Foundation',
    'STORY-M1-FND-003': 'Foundation',
    'STORY-M1-CORE-001': 'Core Business',
    'STORY-M1-CORE-002': 'Core Business',
    'STORY-M1-CORE-003': 'Core Business',
    'STORY-M1-UX-001': 'UX & Experience',
    'STORY-M1-UX-002': 'UX & Experience',
    'STORY-M1-UX-003': 'UX & Experience',
}

STORY_PRIORITY_MAP = {
    'STORY-M1-FND-001': 'P0',
    'STORY-M1-FND-002': 'P0',
    'STORY-M1-FND-003': 'P1',
    'STORY-M1-CORE-001': 'P0',
    'STORY-M1-CORE-002': 'P0',
    'STORY-M1-CORE-003': 'P1',
    'STORY-M1-UX-001': 'P0',
    'STORY-M1-UX-002': 'P1',
    'STORY-M1-UX-003': 'P1',
}

STORY_TYPE_MAP = {
    'STORY-M1-FND-001': 'Story',
    'STORY-M1-FND-002': 'Story',
    'STORY-M1-FND-003': 'Story',
    'STORY-M1-CORE-001': 'Story',
    'STORY-M1-CORE-002': 'Story',
    'STORY-M1-CORE-003': 'Story',
    'STORY-M1-UX-001': 'Story',
    'STORY-M1-UX-002': 'Story',
    'STORY-M1-UX-003': 'Story',
}

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       ATUALIZAÇÃO DE CAMPOS DO PROJETO
       Preenche campos personalizados das issues
    ==============================================
    """)
    
    # 1. Busca o projeto
    project_id, project_number = get_project_id()
    if not project_id:
        print("❌ Projeto não encontrado!")
        return
    
    print(f"📊 Projeto: Nº {project_number} (ID: {project_id})")
    
    # 2. Busca os campos
    field_map = get_field_ids(project_id)
    print("\n📋 Campos encontrados:")
    for name, data in field_map.items():
        if 'options' in data:
            print(f"   - {name} (opções: {list(data['options'].keys())})")
        else:
            print(f"   - {name} (tipo: {data['dataType']})")
    
    # 3. Verifica se temos os campos necessários
    required_fields = ['MVP', 'Squad', 'Tipo', 'Prioridade', 'Story Points']
    missing_fields = [f for f in required_fields if f not in field_map]
    if missing_fields:
        print(f"\n⚠️ Campos faltando: {missing_fields}")
        print("   Configure-os manualmente em:")
        print(f"   https://github.com/users/{REPO_OWNER}/projects/{project_number}/settings/fields")
        return
    
    print("\n✅ Todos os campos necessários estão configurados!")
    
    # 4. Busca os itens do projeto
    items = get_project_items(project_id)
    print(f"\n📊 Encontrados {len(items)} itens no projeto")
    
    updated = 0
    for item in items:
        content = item.get('content', {})
        if not content:
            continue
        
        issue_title = content.get('title', '')
        issue_number = content.get('number')
        item_id = item.get('id')
        
        # Identifica o tipo e mapeia os valores
        if '[EPIC' in issue_title:
            # É um épico
            tipo = 'Epic'
            mvp = 'MVP 1'
            squad = 'Foundation'  # valor padrão, pode ser ajustado
            prioridade = 'P0'
            story_points = None
            
        elif 'STORY' in issue_title:
            # É uma story
            story_id = None
            for sid in STORY_SQUAD_MAP.keys():
                if sid in issue_title:
                    story_id = sid
                    break
            
            if story_id:
                tipo = 'Story'
                mvp = 'MVP 1'
                squad = STORY_SQUAD_MAP.get(story_id, 'Foundation')
                prioridade = STORY_PRIORITY_MAP.get(story_id, 'P1')
                story_points = 5
            else:
                continue
                
        elif 'TASK' in issue_title:
            # É uma task
            tipo = 'Task'
            mvp = 'MVP 1'
            squad = 'Foundation'  # será sobrescrito pelo squad da task
            prioridade = 'P1'
            story_points = None
            
            # Identifica o squad pela task ID
            if 'FND' in issue_title:
                squad = 'Foundation'
            elif 'CORE' in issue_title:
                squad = 'Core Business'
            elif 'UX' in issue_title:
                squad = 'UX & Experience'
        else:
            continue
        
        print(f"\n📌 Issue #{issue_number}: {issue_title[:50]}...")
        print(f"   Tipo: {tipo}, Squad: {squad}, Prioridade: {prioridade}")
        
        # Busca os IDs das opções
        mvp_opt_id = field_map['MVP'].get('options', {}).get(mvp)
        squad_opt_id = field_map['Squad'].get('options', {}).get(squad)
        tipo_opt_id = field_map['Tipo'].get('options', {}).get(tipo)
        priority_opt_id = field_map['Prioridade'].get('options', {}).get(prioridade)
        
        # Atualiza os campos
        fields_to_set = []
        
        if mvp_opt_id:
            fields_to_set.append((field_map['MVP']['id'], {'singleSelectOptionId': mvp_opt_id}))
        if squad_opt_id:
            fields_to_set.append((field_map['Squad']['id'], {'singleSelectOptionId': squad_opt_id}))
        if tipo_opt_id:
            fields_to_set.append((field_map['Tipo']['id'], {'singleSelectOptionId': tipo_opt_id}))
        if priority_opt_id:
            fields_to_set.append((field_map['Prioridade']['id'], {'singleSelectOptionId': priority_opt_id}))
        if story_points is not None:
            fields_to_set.append((field_map['Story Points']['id'], {'number': story_points}))
        
        for field_id, value in fields_to_set:
            success = update_project_item_field(project_id, item_id, field_id, value)
            if success:
                print(f"   ✅ Campo atualizado")
            else:
                print(f"   ⚠️ Erro ao atualizar campo")
        
        updated += 1
        time.sleep(0.5)
    
    print(f"""
    ==============================================
    ✅ ATUALIZAÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Itens atualizados: {updated}
    
    🔗 Acesse:
       Projeto: https://github.com/users/{REPO_OWNER}/projects/{project_number}
    """)

if __name__ == "__main__":
    main()
