#!/usr/bin/env python3
"""
Script: Atualizar Todos os Épicos com o Novo Modelo
Adiciona a estrutura padronizada com Discovery e Measurement
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# DEFINIÇÃO DOS ÉPICOS COM O NOVO MODELO
# ============================================================

EPICS_NEW_BODY = {
    # ===== MVP 1 =====
    'EPIC-M1-FND-001': {
        'title': 'Infraestrutura e Base Técnica',
        'squad': 'Foundation',
        'mvp': 'MVP 1',
        'responsible': '@lobaque29',
        'objective': 'Ambiente de desenvolvimento padronizado e funcional, com cadastro de costureiras operacional.',
        'definition_of_done': [
            'Docker configurado e funcionando em todos os SOs',
            'Cadastro de costureiras via API e interface',
            'Ambiente de desenvolvimento padronizado',
            'CI/CD pipeline configurado (GitHub Actions)',
            'Documentação de setup atualizada'
        ],
        'discovery_tasks': [
            'DISCOVERY-M1-FND-001: Validar versões do Python, Django e PostgreSQL',
            'DISCOVERY-M1-FND-002: Definir arquitetura de containers',
            'DISCOVERY-M1-FND-003: Mapear necessidades de segurança e variáveis de ambiente',
            'DISCOVERY-M1-FND-004: Validar configuração de CORS para os ambientes',
            'DISCOVERY-M1-FND-005: Definir estratégia de logging'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M1-FND-001: Definir KPIs de infraestrutura',
            'MEASUREMENT-M1-FND-002: Estabelecer baseline de performance',
            'MEASUREMENT-M1-FND-003: Criar métricas de tempo de setup',
            'MEASUREMENT-M1-FND-004: Definir cobertura mínima de testes'
        ],
        'stories': [
            'STORY-M1-FND-001: Configuração do Backend Django',
            'STORY-M1-FND-002: Configuração do Frontend React',
            'STORY-M1-FND-003: Autenticação e Segurança'
        ]
    },
    'EPIC-M1-CORE-001': {
        'title': 'Lógica de Carga e CRUD',
        'squad': 'Core Business',
        'mvp': 'MVP 1',
        'responsible': '@karinakaduda19-cyber',
        'objective': 'CRUD de serviços funcional e cálculo inicial de capacidade com índice de complexidade.',
        'definition_of_done': [
            'CRUD completo de serviços (via API e interface)',
            'Cálculo de carga com índice de complexidade (P/M/G/Esp)',
            'Endpoint de consulta de carga por costureira',
            'Testes unitários e de integração',
            'Documentação da API de capacidade'
        ],
        'discovery_tasks': [
            'DISCOVERY-M1-CORE-001: Validar campos obrigatórios da Costureira',
            'DISCOVERY-M1-CORE-002: Definir regras de unicidade',
            'DISCOVERY-M1-CORE-003: Mapear relacionamentos com outros modelos',
            'DISCOVERY-M1-CORE-004: Validar formato de dados (contato, especialidade)',
            'DISCOVERY-M1-CORE-005: Definir padrão de API REST'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M1-CORE-001: Definir KPIs de cadastro',
            'MEASUREMENT-M1-CORE-002: Estabelecer tempo de resposta CRUD',
            'MEASUREMENT-M1-CORE-003: Criar métricas de validação',
            'MEASUREMENT-M1-CORE-004: Definir cobertura de testes unitários'
        ],
        'stories': [
            'STORY-M1-CORE-001: Cadastro de Costureiras',
            'STORY-M1-CORE-002: CRUD de Serviços',
            'STORY-M1-CORE-003: Cálculo de Capacidade'
        ]
    },
    'EPIC-M1-UX-001': {
        'title': 'Interface e Jornada do Usuário',
        'squad': 'UX & Experience',
        'mvp': 'MVP 1',
        'responsible': '@anandamatos',
        'objective': 'Telas iniciais funcionais, Design System e navegação fluida.',
        'definition_of_done': [
            'Design System implementado (Tailwind CSS)',
            'Página de listagem de costureiras',
            'Navegação funcional entre páginas',
            'Responsividade (mobile-first)',
            'Testes de usabilidade realizados'
        ],
        'discovery_tasks': [
            'DISCOVERY-M1-UX-001: Validar cores e tema da Cony Interiores',
            'DISCOVERY-M1-UX-002: Definir estrutura de navegação',
            'DISCOVERY-M1-UX-003: Mapear componentes necessários',
            'DISCOVERY-M1-UX-004: Prototipar layout principal',
            'DISCOVERY-M1-UX-005: Validar requisitos de responsividade'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M1-UX-001: Definir KPIs de usabilidade',
            'MEASUREMENT-M1-UX-002: Estabelecer padrões de design',
            'MEASUREMENT-M1-UX-003: Criar métricas de navegação',
            'MEASUREMENT-M1-UX-004: Definir testes de UX'
        ],
        'stories': [
            'STORY-M1-UX-001: Layout Base e Design System',
            'STORY-M1-UX-002: Formulários e Integração API',
            'STORY-M1-UX-003: Visualização de Carga'
        ]
    },
    
    # ===== MVP 2 =====
    'EPIC-M2-CORE-001': {
        'title': 'Controle Financeiro',
        'squad': 'Core Business',
        'mvp': 'MVP 2',
        'responsible': '@karinakaduda19-cyber',
        'objective': 'Implementar controle financeiro e planejamento de pagamentos para costureiras.',
        'definition_of_done': [
            'Modelo de dados financeiro implementado',
            'Soma automática de valores pendentes por costureira',
            'Planejamento de pagamentos semanais/mensais',
            'Interface de resumo financeiro',
            'Integração com status de serviços'
        ],
        'discovery_tasks': [
            'DISCOVERY-M2-CORE-001: Validar estrutura de dados financeiros necessários',
            'DISCOVERY-M2-CORE-002: Definir status de pagamento (pendente, pago, atrasado)',
            'DISCOVERY-M2-CORE-003: Mapear integração com modelo de Serviços',
            'DISCOVERY-M2-CORE-004: Validar regras de cálculo de valores pendentes',
            'DISCOVERY-M2-CORE-005: Definir formato de dados para planejamento financeiro'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M2-CORE-001: Definir KPIs de controle financeiro',
            'MEASUREMENT-M2-CORE-002: Estabelecer tempo de processamento de pagamentos',
            'MEASUREMENT-M2-CORE-003: Criar métricas de acurácia dos cálculos',
            'MEASUREMENT-M2-CORE-004: Definir cobertura de testes financeiros',
            'MEASUREMENT-M2-CORE-005: Estabelecer tempo de geração de relatórios financeiros'
        ],
        'stories': [
            'STORY-M2-CORE-001: Modelo Financeiro',
            'STORY-M2-CORE-002: Cálculo de Pagamentos'
        ]
    },
    'EPIC-M2-UX-001': {
        'title': 'Interface Financeira',
        'squad': 'UX & Experience',
        'mvp': 'MVP 2',
        'responsible': '@anandamatos',
        'objective': 'Interface para visualização e gestão de pagamentos.',
        'definition_of_done': [
            'Dashboard financeiro implementado',
            'Visualização de valores pendentes',
            'Resumo semanal/mensal por costureira',
            'Gráficos de evolução de pagamentos',
            'Filtros por período e costureira'
        ],
        'discovery_tasks': [
            'DISCOVERY-M2-UX-001: Validar requisitos de visualização financeira',
            'DISCOVERY-M2-UX-002: Definir hierarquia de informações no dashboard',
            'DISCOVERY-M2-UX-003: Prototipar cards de resumo financeiro',
            'DISCOVERY-M2-UX-004: Mapear tipos de gráficos necessários',
            'DISCOVERY-M2-UX-005: Validar fluxo de navegação financeira'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M2-UX-001: Definir KPIs de usabilidade do dashboard financeiro',
            'MEASUREMENT-M2-UX-002: Estabelecer tempo de carregamento do dashboard',
            'MEASUREMENT-M2-UX-003: Criar métricas de interpretação dos dados',
            'MEASUREMENT-M2-UX-004: Definir testes de UX financeiro',
            'MEASUREMENT-M2-UX-005: Estabelecer taxa de erro na visualização de dados'
        ],
        'stories': [
            'STORY-M2-UX-001: Dashboard Financeiro'
        ]
    },
    'EPIC-M2-FND-001': {
        'title': 'Infraestrutura Financeira',
        'squad': 'Foundation',
        'mvp': 'MVP 2',
        'responsible': '@lobaque29',
        'objective': 'Garantir infraestrutura para suporte ao sistema financeiro.',
        'definition_of_done': [
            'Otimização de queries financeiras implementada',
            'Cache para dashboards configurado',
            'Monitoramento de performance ativo',
            'Segurança de dados financeiros reforçada',
            'Documentação de API financeira atualizada'
        ],
        'discovery_tasks': [
            'DISCOVERY-M2-FND-001: Identificar queries mais lentas do sistema financeiro',
            'DISCOVERY-M2-FND-002: Validar requisitos de cache para dashboards',
            'DISCOVERY-M2-FND-003: Mapear dados sensíveis que precisam de proteção adicional',
            'DISCOVERY-M2-FND-004: Definir métricas de performance a serem monitoradas',
            'DISCOVERY-M2-FND-005: Validar necessidade de rate limiting para endpoints financeiros'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M2-FND-001: Definir KPIs de performance de queries financeiras',
            'MEASUREMENT-M2-FND-002: Estabelecer tempo de resposta com cache vs sem cache',
            'MEASUREMENT-M2-FND-003: Criar métricas de segurança de dados financeiros',
            'MEASUREMENT-M2-FND-004: Definir cobertura de monitoramento',
            'MEASUREMENT-M2-FND-005: Estabelecer tempo de geração de documentação'
        ],
        'stories': [
            'STORY-M2-FND-001: Otimização e Segurança Financeira',
            'STORY-M2-FND-002: Monitoramento e Documentação'
        ]
    },
    
    # ===== MVP 3 =====
    'EPIC-M3-UX-001': {
        'title': 'Gestão Visual e Dashboards',
        'squad': 'UX & Experience',
        'mvp': 'MVP 3',
        'responsible': '@anandamatos',
        'objective': 'Dashboards de produtividade e métricas de ROI.',
        'definition_of_done': [
            'Dashboard com KPIs de produção',
            'Comparativo de produtividade entre costureiras',
            'Métricas de ROI e eficiência',
            'Gráficos interativos e filtros',
            'Exportação de dados do dashboard'
        ],
        'discovery_tasks': [
            'DISCOVERY-M3-UX-001: Validar KPIs de produção mais relevantes',
            'DISCOVERY-M3-UX-002: Definir visualizações de comparação',
            'DISCOVERY-M3-UX-003: Prototipar dashboards com usuários',
            'DISCOVERY-M3-UX-004: Mapear fontes de dados para métricas',
            'DISCOVERY-M3-UX-005: Validar requisitos de exportação'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M3-UX-001: Definir KPIs de usabilidade do dashboard',
            'MEASUREMENT-M3-UX-002: Estabelecer tempo de carregamento',
            'MEASUREMENT-M3-UX-003: Criar métricas de interpretação visual',
            'MEASUREMENT-M3-UX-004: Definir testes de UX',
            'MEASUREMENT-M3-UX-005: Estabelecer taxa de uso do dashboard'
        ],
        'stories': [
            'STORY-M3-UX-001: Dashboard de Produção',
            'STORY-M3-UX-002: Métricas e ROI'
        ]
    },
    'EPIC-M3-CORE-001': {
        'title': 'Métricas de Negócio',
        'squad': 'Core Business',
        'mvp': 'MVP 3',
        'responsible': '@karinakaduda19-cyber',
        'objective': 'Implementar métricas de negócio e indicadores de performance.',
        'definition_of_done': [
            'Cálculo de ROI por costureira',
            'Métricas de eficiência produtiva',
            'Indicadores de qualidade',
            'Comparativos históricos',
            'Documentação das métricas'
        ],
        'discovery_tasks': [
            'DISCOVERY-M3-CORE-001: Validar fórmula de ROI para costureiras',
            'DISCOVERY-M3-CORE-002: Definir métricas de eficiência',
            'DISCOVERY-M3-CORE-003: Mapear dados históricos disponíveis',
            'DISCOVERY-M3-CORE-004: Validar formato de exportação',
            'DISCOVERY-M3-CORE-005: Definir periodicidade de atualização'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M3-CORE-001: Definir KPIs de ROI',
            'MEASUREMENT-M3-CORE-002: Estabelecer baseline de eficiência',
            'MEASUREMENT-M3-CORE-003: Criar métricas de evolução',
            'MEASUREMENT-M3-CORE-004: Definir periodicidade de atualização',
            'MEASUREMENT-M3-CORE-005: Estabelecer critérios de sucesso'
        ],
        'stories': [
            'STORY-M3-CORE-001: Métricas de Performance'
        ]
    },
    'EPIC-M3-FND-001': {
        'title': 'Infraestrutura de Dashboards',
        'squad': 'Foundation',
        'mvp': 'MVP 3',
        'responsible': '@lobaque29',
        'objective': 'Garantir infraestrutura para dashboards e visualizações.',
        'definition_of_done': [
            'Otimização de assets e minificação',
            'Configuração de CDN para assets estáticos',
            'Implementação de logging estruturado',
            'Rate limiting para APIs de dashboard',
            'Testes de carga de dashboards'
        ],
        'discovery_tasks': [
            'DISCOVERY-M3-FND-001: Identificar assets mais pesados',
            'DISCOVERY-M3-FND-002: Validar estratégia de CDN',
            'DISCOVERY-M3-FND-003: Mapear pontos de gargalo no carregamento',
            'DISCOVERY-M3-FND-004: Definir política de cache',
            'DISCOVERY-M3-FND-005: Validar requisitos de rate limiting'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M3-FND-001: Definir KPIs de performance de assets',
            'MEASUREMENT-M3-FND-002: Estabelecer tempo de carregamento ideal',
            'MEASUREMENT-M3-FND-003: Criar métricas de bundle size',
            'MEASUREMENT-M3-FND-004: Definir cobertura de cache',
            'MEASUREMENT-M3-FND-005: Estabelecer taxa de sucesso de CDN'
        ],
        'stories': [
            'STORY-M3-FND-001: Otimização de Assets',
            'STORY-M3-FND-002: Monitoramento de Dashboards'
        ]
    },
    
    # ===== MVP 4 =====
    'EPIC-M4-CORE-001': {
        'title': 'Relatórios Avançados',
        'squad': 'Core Business',
        'mvp': 'MVP 4',
        'responsible': '@karinakaduda19-cyber',
        'objective': 'Gerar relatórios gerenciais detalhados e exportáveis.',
        'definition_of_done': [
            'Relatórios mensais de produção',
            'Relatórios de serviços em atraso',
            'Exportação em PDF/CSV',
            'Filtros avançados',
            'Agendamento de relatórios'
        ],
        'discovery_tasks': [
            'DISCOVERY-M4-CORE-001: Validar formato dos relatórios com usuários',
            'DISCOVERY-M4-CORE-002: Definir métricas a serem incluídas',
            'DISCOVERY-M4-CORE-003: Mapear fontes de dados para relatórios',
            'DISCOVERY-M4-CORE-004: Validar periodicidade de geração',
            'DISCOVERY-M4-CORE-005: Definir requisitos de exportação'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M4-CORE-001: Definir KPIs de qualidade de relatórios',
            'MEASUREMENT-M4-CORE-002: Estabelecer tempo de geração',
            'MEASUREMENT-M4-CORE-003: Criar métricas de cobertura de dados',
            'MEASUREMENT-M4-CORE-004: Definir testes de integridade',
            'MEASUREMENT-M4-CORE-005: Estabelecer taxa de uso de relatórios'
        ],
        'stories': [
            'STORY-M4-CORE-001: Relatórios de Produção',
            'STORY-M4-CORE-002: Exportação de Dados'
        ]
    },
    'EPIC-M4-UX-001': {
        'title': 'Visualização de Relatórios',
        'squad': 'UX & Experience',
        'mvp': 'MVP 4',
        'responsible': '@anandamatos',
        'objective': 'Interface para visualização e interação com relatórios.',
        'definition_of_done': [
            'Páginas de visualização de relatórios',
            'Filtros interativos',
            'Exportação visual de dados',
            'Responsividade dos relatórios',
            'Pré-visualização de relatórios'
        ],
        'discovery_tasks': [
            'DISCOVERY-M4-UX-001: Validar fluxo de visualização de relatórios',
            'DISCOVERY-M4-UX-002: Definir hierarquia de filtros',
            'DISCOVERY-M4-UX-003: Prototipar pré-visualização',
            'DISCOVERY-M4-UX-004: Mapear ações de exportação',
            'DISCOVERY-M4-UX-005: Validar responsividade dos relatórios'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M4-UX-001: Definir KPIs de usabilidade',
            'MEASUREMENT-M4-UX-002: Estabelecer tempo de carregamento',
            'MEASUREMENT-M4-UX-003: Criar métricas de uso de relatórios',
            'MEASUREMENT-M4-UX-004: Definir testes de UX',
            'MEASUREMENT-M4-UX-005: Estabelecer taxa de sucesso de exportação'
        ],
        'stories': [
            'STORY-M4-UX-001: Visualização de Relatórios'
        ]
    },
    'EPIC-M4-FND-001': {
        'title': 'Infraestrutura de Relatórios',
        'squad': 'Foundation',
        'mvp': 'MVP 4',
        'responsible': '@lobaque29',
        'objective': 'Garantir infraestrutura para geração e exportação de relatórios.',
        'definition_of_done': [
            'Otimização de exportação em lote',
            'Implementação de jobs assíncronos',
            'Compressão de dados para exportação',
            'Backup de relatórios gerados',
            'Monitoramento de jobs de relatórios'
        ],
        'discovery_tasks': [
            'DISCOVERY-M4-FND-001: Identificar gargalos de exportação',
            'DISCOVERY-M4-FND-002: Validar arquitetura de jobs assíncronos',
            'DISCOVERY-M4-FND-003: Mapear dados para compressão',
            'DISCOVERY-M4-FND-004: Definir política de backup',
            'DISCOVERY-M4-FND-005: Validar requisitos de monitoramento'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M4-FND-001: Definir KPIs de performance de exportação',
            'MEASUREMENT-M4-FND-002: Estabelecer tempo de geração de arquivos',
            'MEASUREMENT-M4-FND-003: Criar métricas de compressão',
            'MEASUREMENT-M4-FND-004: Definir cobertura de backup',
            'MEASUREMENT-M4-FND-005: Estabelecer taxa de sucesso de jobs'
        ],
        'stories': [
            'STORY-M4-FND-001: Otimização de Exportação',
            'STORY-M4-FND-002: Jobs e Backup'
        ]
    },
    
    # ===== MVP 5 =====
    'EPIC-M5-ALL-001': {
        'title': 'Otimização e Ajustes Finais',
        'squad': 'All Squads',
        'mvp': 'MVP 5',
        'responsible': '@lobaque29',
        'objective': 'Refinar a experiência do usuário e otimizar performance.',
        'definition_of_done': [
            'Melhorias de usabilidade',
            'Otimização de performance',
            'Acessibilidade (WCAG 2.1 AA)',
            'Correção de bugs',
            'Documentação atualizada',
            'Testes de carga realizados'
        ],
        'discovery_tasks': [
            'DISCOVERY-M5-ALL-001: Identificar pontos de melhoria de performance',
            'DISCOVERY-M5-ALL-002: Validar requisitos de acessibilidade',
            'DISCOVERY-M5-ALL-003: Mapear gargalos de CI/CD',
            'DISCOVERY-M5-ALL-004: Definir cenários de teste de carga',
            'DISCOVERY-M5-ALL-005: Priorizar bugs e melhorias'
        ],
        'measurement_tasks': [
            'MEASUREMENT-M5-ALL-001: Definir KPIs de performance',
            'MEASUREMENT-M5-ALL-002: Estabelecer baseline de melhoria',
            'MEASUREMENT-M5-ALL-003: Criar métricas de acessibilidade',
            'MEASUREMENT-M5-ALL-004: Definir critérios de aceite de otimização',
            'MEASUREMENT-M5-ALL-005: Estabelecer taxa de redução de bugs'
        ],
        'stories': [
            'STORY-M5-ALL-001: Otimização Geral',
            'STORY-M5-CORE-001: Ajustes de Negócio',
            'STORY-M5-UX-001: Refinamentos de UX'
        ]
    },
    
    # ===== FINAL =====
    'EPIC-FIN-ALL-001': {
        'title': 'Deploy e Handover',
        'squad': 'All Squads',
        'mvp': 'Final',
        'responsible': '@lobaque29',
        'objective': 'Entregar o sistema finalizado e documentado.',
        'definition_of_done': [
            'Deploy em produção',
            'Documentação técnica completa',
            'Manual do usuário',
            'Treinamento realizado',
            'Plano de suporte pós-entrega',
            'Handover técnico concluído'
        ],
        'discovery_tasks': [
            'DISCOVERY-FIN-ALL-001: Validar requisitos de deploy',
            'DISCOVERY-FIN-ALL-002: Definir estrutura da documentação',
            'DISCOVERY-FIN-ALL-003: Mapear ambiente de produção',
            'DISCOVERY-FIN-ALL-004: Planejar testes de aceitação',
            'DISCOVERY-FIN-ALL-005: Definir plano de handover'
        ],
        'measurement_tasks': [
            'MEASUREMENT-FIN-ALL-001: Definir KPIs de qualidade de deploy',
            'MEASUREMENT-FIN-ALL-002: Estabelecer tempo de deploy',
            'MEASUREMENT-FIN-ALL-003: Criar métricas de cobertura de documentação',
            'MEASUREMENT-FIN-ALL-004: Definir critérios de aceitação de handover',
            'MEASUREMENT-FIN-ALL-005: Estabelecer satisfação do treinamento'
        ],
        'stories': [
            'STORY-FIN-ALL-001: Deploy e Documentação',
            'STORY-FIN-ALL-002: Treinamento e Handover'
        ]
    }
}

# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def get_all_open_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def update_issue(issue_number, new_body):
    """Atualiza o corpo de uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'body': new_body}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r

def build_epic_body(epic_id, data):
    """Constrói o corpo do épico com o novo modelo"""
    body = f"""## 🎯 Objetivo do Épico
{data['objective']}

## 👥 Squad Responsável
**{data['squad']}** (com suporte de outros squads conforme necessário)

## 📌 Definition of Done
"""
    for item in data['definition_of_done']:
        body += f"- [ ] {item}\n"
    
    body += f"""
## 🔍 Tarefas de Discovery (Liderança)
"""
    for task in data['discovery_tasks']:
        body += f"- [ ] **{task}**\n"
    
    body += f"""
## 📊 Tarefas de Mensuração (Liderança)
"""
    for task in data['measurement_tasks']:
        body += f"- [ ] **{task}**\n"
    
    body += f"""
## 📋 Stories Relacionadas
"""
    for story in data['stories']:
        body += f"- [ ] {story}\n"
    
    body += f"""
---
## 🏷️ Metadados
**ID:** {epic_id}
**Squad:** {data['squad']}
**MVP:** {data['mvp']}
**Tipo:** Épico
**Track:** Discovery
**Responsável:** {data['responsible']}
"""
    return body

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       SCRIPT: ATUALIZAR TODOS OS ÉPICOS
       Aplica o novo modelo com Discovery e Measurement
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # Busca todas as issues abertas
    issues = get_all_open_issues()
    print(f"🔍 Encontradas {len(issues)} issues abertas\n")
    
    updated = 0
    not_found = []
    
    for epic_id, data in EPICS_NEW_BODY.items():
        print(f"📌 Processando: {epic_id}")
        
        # Procura a issue do épico
        found = False
        for issue in issues:
            if epic_id in issue['title'] and 'Epic' in issue['title']:
                found = True
                issue_number = issue['number']
                current_body = issue.get('body', '')
                
                # Verifica se já tem o novo formato
                if '## 🔍 Tarefas de Discovery (Liderança)' in current_body:
                    print(f"   ℹ️ Épico já atualizado (Nº {issue_number})")
                    break
                
                # Constrói o novo corpo
                new_body = build_epic_body(epic_id, data)
                
                # Atualiza a issue
                result = update_issue(issue_number, new_body)
                if result.status_code == 200:
                    print(f"   ✅ Épico atualizado: #{issue_number}")
                    updated += 1
                else:
                    print(f"   ❌ Erro ao atualizar: {result.status_code}")
                break
        
        if not found:
            print(f"   ⚠️ Épico não encontrado: {epic_id}")
            not_found.append(epic_id)
        
        time.sleep(0.5)
    
    print(f"""
    ==============================================
    ✅ ATUALIZAÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Épicos atualizados: {updated}
       Épicos não encontrados: {len(not_found)}
    
    🔗 Acesse:
       https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)
    
    if not_found:
        print("\n📋 Épicos não encontrados:")
        for epic_id in not_found:
            print(f"   - {epic_id}")

if __name__ == "__main__":
    main()