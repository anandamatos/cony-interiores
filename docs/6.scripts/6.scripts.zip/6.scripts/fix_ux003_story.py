#!/usr/bin/env python3
"""
Script: Corrigir STORY-M1-UX-003
Encontra a issue existente e renomeia para o padrão correto
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

def get_all_open_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def update_issue(issue_number, new_title, new_body, labels):
    """Atualiza uma issue existente"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {
        'title': new_title,
        'body': new_body,
        'labels': labels
    }
    r = requests.patch(url, headers=HEADERS, json=data)
    return r

def main():
    print("""
    🔧 ==============================================
       SCRIPT: CORRIGIR STORY UX-003
       Renomeia a issue existente para o padrão correto
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # Busca todas as issues abertas
    issues = get_all_open_issues()
    
    # Procura por issues relacionadas à UX-003
    found_issues = []
    for issue in issues:
        title = issue['title']
        if 'UX-003' in title or 'Visualização de Carga' in title or 'visualização de carga' in title.lower():
            found_issues.append({
                'number': issue['number'],
                'title': title,
                'body': issue.get('body', ''),
                'labels': [label['name'] for label in issue.get('labels', [])]
            })
    
    if not found_issues:
        print("❌ Nenhuma issue relacionada à STORY-M1-UX-003 encontrada!")
        print("   Verifique manualmente em: https://github.com/anandamatos/cony-interiores/issues")
        return
    
    print(f"🔍 Encontradas {len(found_issues)} issues relacionadas:")
    for issue in found_issues:
        print(f"   #{issue['number']}: {issue['title'][:60]}...")
    
    # Pega a primeira (e provavelmente única) issue
    issue = found_issues[0]
    issue_number = issue['number']
    
    print(f"\n📌 Issue selecionada: #{issue_number}")
    print(f"   Título atual: {issue['title']}")
    
    # Novo título padronizado
    new_title = "[STORY-M1-UX-003] Story: Visualização de Carga"
    
    # Corpo da issue (mantém o existente, mas adiciona metadados se necessário)
    new_body = issue['body']
    
    # Verifica se já tem os metadados
    if '**ID:** STORY-M1-UX-003' not in new_body:
        new_body += """

---
## 🏷️ Metadados
**ID:** STORY-M1-UX-003
**Squad:** UX & Experience
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** 5 Story Points
**Épico:** EPIC-M1-UX-001
**Sprint:** MVP 1 - Sprint 3: Inteligência de Capacidade
**Responsável:** @isabarrs
"""
    
    # Labels
    labels = ['story', 'mvp1', 'ux-experience']
    
    print(f"\n🚀 Atualizando issue #{issue_number}...")
    print(f"   Novo título: {new_title}")
    
    result = update_issue(issue_number, new_title, new_body, labels)
    
    if result.status_code == 200:
        print(f"   ✅ Issue #{issue_number} atualizada com sucesso!")
    else:
        print(f"   ❌ Erro ao atualizar issue: {result.status_code}")
        print(f"   {result.text[:200]}")
    
    print(f"""
    ==============================================
    ✅ CORREÇÃO CONCLUÍDA!
    ==============================================
    
    🔗 Acesse a issue corrigida:
    https://github.com/{REPO_OWNER}/{REPO_NAME}/issues/{issue_number}
    """)

if __name__ == "__main__":
    main()