#!/usr/bin/env python3
"""
Script: Limpeza de Issues Duplicadas
Remove todas as issues que não seguem o padrão de nomenclatura ou são duplicatas
Mantém apenas as issues com os IDs padronizados (EPIC-M1-FND-001, STORY-M1-FND-001, TASK-M1-FND-001, etc.)
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# FUNÇÕES
# ============================================================

def get_all_issues():
    """Busca todas as issues abertas e fechadas"""
    url = f"{BASE_URL}/issues?state=all&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        # Verifica se há mais páginas
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def should_delete_issue(issue):
    """Verifica se a issue deve ser deletada (não tem ID padronizado ou é duplicata)"""
    title = issue['title']
    number = issue['number']
    
    # Padrões válidos (IDs padronizados)
    valid_patterns = [
        r'^\[EPIC-M\d+-[A-Z]+-\d{3}\]',  # EPIC-M1-FND-001
        r'^\[STORY-M\d+-[A-Z]+-\d{3}\]', # STORY-M1-FND-001
        r'^TASK-M\d+-[A-Z]+-\d{3}:',     # TASK-M1-FND-001
        r'^\[TASK-M\d+-[A-Z]+-\d{3}\]',   # [TASK-M1-FND-001]
    ]
    
    for pattern in valid_patterns:
        if re.match(pattern, title):
            return False  # Mantém a issue (tem ID válido)
    
    # Se não tem ID padronizado, pode ser deletada
    return True

def close_issue(issue_number):
    """Fecha uma issue (não deleta, apenas fecha para manter histórico)"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'state': 'closed'}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r.status_code == 200

def delete_issue_comment(issue_number):
    """Remove todos os comentários da issue (opcional)"""
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        comments = r.json()
        for comment in comments:
            comment_url = f"{BASE_URL}/issues/comments/{comment['id']}"
            requests.delete(comment_url, headers=HEADERS)
            time.sleep(0.1)
    return True

def get_valid_issues():
    """Retorna uma lista com os números das issues válidas (com IDs padronizados)"""
    all_issues = get_all_issues()
    valid_issues = []
    
    for issue in all_issues:
        if not should_delete_issue(issue):
            valid_issues.append({
                'number': issue['number'],
                'title': issue['title'],
                'state': issue['state']
            })
    
    return valid_issues

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🧹 ==============================================
       LIMPEZA DE ISSUES DUPLICADAS
       Remove issues sem IDs padronizados
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}")
    print("\n⚠️ ATENÇÃO: Isso irá FECHAR todas as issues que NÃO têm IDs padronizados!")
    print("   Issues com IDs como EPIC-M1-FND-001, STORY-M1-FND-001, TASK-M1-FND-001 serão mantidas.")
    print("   Digite 'SIM' para confirmar: ", end="")
    
    confirm = input().strip().upper()
    if confirm != 'SIM':
        print("❌ Operação cancelada.")
        return
    
    print("\n🔍 Buscando issues...")
    all_issues = get_all_issues()
    print(f"   Encontradas {len(all_issues)} issues no total")
    
    # Separa as issues
    to_keep = []
    to_close = []
    
    for issue in all_issues:
        if should_delete_issue(issue):
            to_close.append(issue)
        else:
            to_keep.append(issue)
    
    print(f"   📌 Issues válidas (com IDs): {len(to_keep)}")
    print(f"   🗑️ Issues a serem fechadas (sem IDs): {len(to_close)}")
    
    if not to_close:
        print("\n✅ Nenhuma issue duplicada encontrada! Tudo limpo.")
        return
    
    print("\n📋 Issues que serão FECHADAS:")
    for issue in to_close[:10]:  # Mostra até 10
        print(f"   #{issue['number']}: {issue['title'][:60]}...")
    if len(to_close) > 10:
        print(f"   ... e mais {len(to_close) - 10} issues")
    
    print("\n📋 Issues que serão MANTIDAS:")
    for issue in to_keep[:10]:
        print(f"   #{issue['number']}: {issue['title'][:60]}...")
    if len(to_keep) > 10:
        print(f"   ... e mais {len(to_keep) - 10} issues")
    
    print("\n🚀 Iniciando limpeza...\n")
    
    closed = 0
    for issue in to_close:
        issue_number = issue['number']
        title = issue['title'][:50]
        print(f"   Fechando issue #{issue_number}: {title}...")
        
        if close_issue(issue_number):
            print(f"   ✅ Issue #{issue_number} fechada")
            closed += 1
        else:
            print(f"   ❌ Erro ao fechar issue #{issue_number}")
        
        time.sleep(0.3)
    
    print(f"\n✅ Limpeza concluída! {closed} issues fechadas.")
    print("\n📋 Para remover permanentemente, você pode usar a interface do GitHub.")
    print("   As issues fechadas podem ser restauradas se necessário.")
    
    print(f"""
    ==============================================
    ✅ LIMPEZA CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Issues fechadas: {closed}
       Issues mantidas: {len(to_keep)}
    
    🔗 Acesse:
       Issues abertas: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues?q=is%3Aopen
       Issues fechadas: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues?q=is%3Aclosed
    """)

if __name__ == "__main__":
    main()