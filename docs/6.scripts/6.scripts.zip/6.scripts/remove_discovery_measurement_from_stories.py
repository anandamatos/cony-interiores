#!/usr/bin/env python3
"""
Script: Remover Discovery e Measurement das Stories do MVP 1
Remove as seções de Discovery e Measurement, mantendo apenas Delivery
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# LISTA DAS STORIES DO MVP 1
# ============================================================

STORY_IDS = [
    'STORY-M1-FND-001',
    'STORY-M1-FND-002',
    'STORY-M1-FND-003',
    'STORY-M1-CORE-001',
    'STORY-M1-CORE-002',
    'STORY-M1-CORE-003',
    'STORY-M1-UX-001',
    'STORY-M1-UX-002',
    'STORY-M1-UX-003',
]

# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def get_all_open_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def update_issue(issue_number, new_body):
    """Atualiza o corpo de uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'body': new_body}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r

def remove_discovery_measurement(body):
    """Remove as seções de Discovery e Measurement do corpo da issue"""
    
    # Padrões para identificar as seções a remover
    # Remove a seção de Discovery (desde o cabeçalho até o próximo cabeçalho ou final)
    patterns = [
        # Remove seção de Discovery
        r'## 🔍 Tarefas de Discovery\s*\n(?:- \[ \].*\n)*',
        # Remove seção de Mensuração
        r'## 📊 Tarefas de Mensuração\s*\n(?:- \[ \].*\n)*',
    ]
    
    for pattern in patterns:
        body = re.sub(pattern, '', body, flags=re.MULTILINE)
    
    # Remove linhas vazias extras que podem ter ficado
    body = re.sub(r'\n\s*\n\s*\n', '\n\n', body)
    body = re.sub(r'\n\s*\n$', '\n', body)
    
    return body

def main():
    print("""
    🚀 ==============================================
       SCRIPT: REMOVER DISCOVERY E MEASUREMENT
       Das Stories do MVP 1
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # Busca todas as issues abertas
    issues = get_all_open_issues()
    print(f"🔍 Encontradas {len(issues)} issues abertas\n")
    
    updated = 0
    not_found = []
    already_clean = []
    
    for story_id in STORY_IDS:
        print(f"📌 Processando: {story_id}")
        
        # Procura a issue da story
        found = False
        for issue in issues:
            if story_id in issue['title'] and 'Story' in issue['title']:
                found = True
                issue_number = issue['number']
                body = issue.get('body', '')
                
                # Verifica se tem Discovery ou Measurement
                has_discovery = '## 🔍 Tarefas de Discovery' in body
                has_measurement = '## 📊 Tarefas de Mensuração' in body
                
                if not has_discovery and not has_measurement:
                    print(f"   ℹ️ Story já está limpa (Nº {issue_number})")
                    already_clean.append(story_id)
                    break
                
                # Remove as seções
                new_body = remove_discovery_measurement(body)
                
                # Verifica se houve mudança
                if new_body == body:
                    print(f"   ℹ️ Nenhuma mudança necessária (Nº {issue_number})")
                    already_clean.append(story_id)
                    break
                
                # Atualiza a issue
                result = update_issue(issue_number, new_body)
                if result.status_code == 200:
                    print(f"   ✅ Discovery/Measurement removidos: #{issue_number}")
                    updated += 1
                else:
                    print(f"   ❌ Erro ao atualizar: {result.status_code}")
                break
        
        if not found:
            print(f"   ⚠️ Story não encontrada: {story_id}")
            not_found.append(story_id)
        
        time.sleep(0.5)
    
    print(f"""
    ==============================================
    ✅ REMOÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Stories atualizadas (remoção): {updated}
       Stories já limpas: {len(already_clean)}
       Stories não encontradas: {len(not_found)}
    
    🔗 Acesse:
       https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)
    
    if not_found:
        print("\n📋 Stories não encontradas:")
        for story_id in not_found:
            print(f"   - {story_id}")

if __name__ == "__main__":
    main()