#!/usr/bin/env python3
"""
Script simplificado para criar a estrutura do GitHub Project
"""
import os
import requests
import json

# ============================================================
# LÊ AS VARIÁVEIS DE AMBIENTE
# ============================================================

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    print("   Execute: export GITHUB_TOKEN=seu_token")
    print("   Ou: GITHUB_TOKEN=seu_token python script.py")
    exit(1)

print(f"""
🚀 CONY INTERIORES - Setup do GitHub Project
============================================
📋 Configuração:
   Repositório: {REPO_OWNER}/{REPO_NAME}
   Token: {GITHUB_TOKEN[:10]}... ({len(GITHUB_TOKEN)} caracteres)
""")

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# 1. CRIAR LABELS
# ============================================================

print("📌 CRIANDO LABELS...")

labels = [
    {'name': 'epic', 'color': '6f42c1', 'description': 'Épico'},
    {'name': 'story', 'color': '2cbe4e', 'description': 'Story'},
    {'name': 'task', 'color': '0366d6', 'description': 'Task'},
    {'name': 'bug', 'color': 'd73a4a', 'description': 'Bug'},
    {'name': 'mvp1', 'color': 'ff6b6b', 'description': 'MVP 1'},
    {'name': 'mvp2', 'color': 'ffa94d', 'description': 'MVP 2'},
    {'name': 'mvp3', 'color': 'ffd43b', 'description': 'MVP 3'},
    {'name': 'mvp4', 'color': '69db7c', 'description': 'MVP 4'},
    {'name': 'mvp5', 'color': '4dabf7', 'description': 'MVP 5'},
    {'name': 'final', 'color': '9775fa', 'description': 'Final'},
]

for label in labels:
    url = f"{BASE_URL}/labels"
    try:
        r = requests.post(url, headers=HEADERS, json=label)
        if r.status_code == 201:
            print(f"   ✅ Label '{label['name']}' criada")
        elif r.status_code == 422:
            print(f"   ℹ️ Label '{label['name']}' já existe")
        else:
            print(f"   ⚠️ Label '{label['name']}' erro: {r.status_code}")
    except Exception as e:
        print(f"   ❌ Erro: {e}")

# ============================================================
# 2. CRIAR MILESTONES
# ============================================================

print("\n📅 CRIANDO MILESTONES...")

milestones = [
    {'title': 'MVP 1 - Sprint 1: Base Digital', 'due_on': '2026-06-21T23:59:59Z', 'description': 'Docker, Setup, Cadastro'},
    {'title': 'MVP 1 - Sprint 2: Fluxo Operacional', 'due_on': '2026-06-28T23:59:59Z', 'description': 'CRUD de Serviços'},
    {'title': 'MVP 1 - Sprint 3: Inteligência de Capacidade', 'due_on': '2026-07-05T23:59:59Z', 'description': 'Cálculo de Carga'},
    {'title': 'MVP 2 - Sprint 4: Previsão Financeira', 'due_on': '2026-07-12T23:59:59Z', 'description': 'Controle Financeiro'},
    {'title': 'MVP 3 - Sprint 5: Gestão Visual', 'due_on': '2026-07-19T23:59:59Z', 'description': 'Dashboards'},
    {'title': 'MVP 4 - Sprint 6: Relatórios Avançados', 'due_on': '2026-07-26T23:59:59Z', 'description': 'Relatórios'},
    {'title': 'MVP 5 - Sprint 7: Otimização', 'due_on': '2026-08-02T23:59:59Z', 'description': 'Otimizações'},
    {'title': 'Final - Sprint 8: Deploy e Handover', 'due_on': '2026-08-09T23:59:59Z', 'description': 'Deploy e Documentação'},
]

for ms in milestones:
    url = f"{BASE_URL}/milestones"
    try:
        r = requests.post(url, headers=HEADERS, json=ms)
        if r.status_code == 201:
            print(f"   ✅ Milestone '{ms['title']}' criada")
        elif r.status_code == 422:
            print(f"   ℹ️ Milestone '{ms['title']}' já existe")
        else:
            print(f"   ⚠️ Milestone '{ms['title']}' erro: {r.status_code}")
    except Exception as e:
        print(f"   ❌ Erro: {e}")

# ============================================================
# 3. CRIAR ÉPICOS (MVP 1)
# ============================================================

print("\n🏗️ CRIANDO ÉPICOS...")

epics = [
    {
        'title': '[Epic] Infraestrutura e Base Técnica',
        'body': """## 🎯 Objetivo do Épico
Ambiente de desenvolvimento padronizado e funcional, com cadastro de costureiras operacional.

## 👥 Squad Responsável
**Foundation**

## 📌 Definition of Done
- [ ] Docker configurado e funcionando em todos os SOs
- [ ] Cadastro de costureiras via API e interface
- [ ] Ambiente de desenvolvimento padronizado""",
        'labels': ['epic', 'mvp1']
    },
    {
        'title': '[Epic] Lógica de Carga e CRUD',
        'body': """## 🎯 Objetivo do Épico
CRUD de serviços funcional e cálculo inicial de capacidade com índice de complexidade.

## 👥 Squad Responsável
**Core Business**

## 📌 Definition of Done
- [ ] CRUD completo de serviços (via API e interface)
- [ ] Cálculo de carga com índice de complexidade (P/M/G/Esp)""",
        'labels': ['epic', 'mvp1']
    },
    {
        'title': '[Epic] Interface e Jornada do Usuário',
        'body': """## 🎯 Objetivo do Épico
Telas iniciais funcionais, Design System e navegação fluida.

## 👥 Squad Responsável
**UX & Experience**

## 📌 Definition of Done
- [ ] Design System implementado (Tailwind CSS)
- [ ] Página de listagem de costureiras
- [ ] Navegação funcional entre páginas""",
        'labels': ['epic', 'mvp1']
    }
]

# Busca o número do milestone "MVP 1 - Sprint 1: Base Digital"
url = f"{BASE_URL}/milestones"
try:
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        milestones_list = r.json()
        milestone_number = None
        for ms in milestones_list:
            if ms['title'] == 'MVP 1 - Sprint 1: Base Digital':
                milestone_number = ms['number']
                break
        
        if milestone_number:
            for epic in epics:
                data = {
                    'title': epic['title'],
                    'body': epic['body'],
                    'labels': epic['labels'],
                    'milestone': milestone_number
                }
                url = f"{BASE_URL}/issues"
                r = requests.post(url, headers=HEADERS, json=data)
                if r.status_code == 201:
                    print(f"   ✅ Épico '{epic['title']}' criado (Nº {r.json()['number']})")
                elif r.status_code == 422:
                    print(f"   ℹ️ Épico '{epic['title']}' já existe")
                else:
                    print(f"   ⚠️ Épico '{epic['title']}' erro: {r.status_code}")
        else:
            print("   ❌ Milestone 'MVP 1 - Sprint 1: Base Digital' não encontrada")
    else:
        print(f"   ❌ Erro ao buscar milestones: {r.status_code}")
except Exception as e:
    print(f"   ❌ Erro: {e}")

# ============================================================
# 4. RESUMO FINAL
# ============================================================

print("""
✨ ==============================================
SETUP CONCLUÍDO COM SUCESSO!
==============================================

🔗 Acesse seu repositório:
https://github.com/{}/{}

📋 Acesse as Issues:
https://github.com/{}/{}/issues
""".format(REPO_OWNER, REPO_NAME, REPO_OWNER, REPO_NAME))
