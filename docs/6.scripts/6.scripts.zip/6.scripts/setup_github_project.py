#!/usr/bin/env python3
"""
Script 1: Setup Geral do Projeto Cony Interiores
Cria: Labels, Milestones, Projeto e Campos Personalizados
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

HEADERS_GRAPHQL = {
    'Authorization': f'Bearer {GITHUB_TOKEN}',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# 1. LABELS
# ============================================================

LABELS = [
    {'name': 'epic', 'color': '6f42c1', 'description': 'Épico - Conjunto de Stories'},
    {'name': 'story', 'color': '2cbe4e', 'description': 'Story - História de usuário'},
    {'name': 'bug', 'color': 'd73a4a', 'description': 'Bug - Correção necessária'},
    {'name': 'mvp1', 'color': 'ff6b6b', 'description': 'MVP 1 - Base Digital'},
    {'name': 'mvp2', 'color': 'ffa94d', 'description': 'MVP 2 - Financeiro'},
    {'name': 'mvp3', 'color': 'ffd43b', 'description': 'MVP 3 - Dashboards'},
    {'name': 'mvp4', 'color': '69db7c', 'description': 'MVP 4 - Relatórios'},
    {'name': 'mvp5', 'color': '4dabf7', 'description': 'MVP 5 - Otimização'},
    {'name': 'final', 'color': '9775fa', 'description': 'Final - Deploy e Handover'},
    {'name': 'foundation', 'color': 'e3f2fd', 'description': 'Squad Foundation - Infraestrutura'},
    {'name': 'core-business', 'color': 'fff3e0', 'description': 'Squad Core Business - Regras de Negócio'},
    {'name': 'ux-experience', 'color': 'e8f5e9', 'description': 'Squad UX & Experience - Interface'},
    {'name': 'discovery', 'color': 'f3e5f5', 'description': 'Discovery - Validação de Requisitos'},
    {'name': 'measurement', 'color': 'fce4ec', 'description': 'Measurement - KPIs e Métricas'},
    {'name': 'delivery', 'color': 'e0f7fa', 'description': 'Delivery - Desenvolvimento e Entrega'},
]

def create_label(name, color, description=''):
    url = f"{BASE_URL}/labels"
    data = {'name': name, 'color': color, 'description': description}
    r = requests.post(url, headers=HEADERS, json=data)
    if r.status_code == 201:
        return True
    elif r.status_code == 422:
        print(f"   ℹ️ Label '{name}' já existe")
        return True
    return False

def create_labels():
    print("📌 1. CRIANDO LABELS...")
    for label in LABELS:
        if create_label(label['name'], label['color'], label.get('description', '')):
            print(f"   ✅ Label '{label['name']}' criada/verificada")
        else:
            print(f"   ❌ Erro ao criar label '{label['name']}'")
        time.sleep(0.2)

# ============================================================
# 2. MILESTONES
# ============================================================

MILESTONES = [
    {'title': 'MVP 1 - Sprint 1: Base Digital', 'due_on': '2026-06-21T23:59:59Z', 'description': 'Docker, Setup, Cadastro de Costureiras'},
    {'title': 'MVP 1 - Sprint 2: Fluxo Operacional', 'due_on': '2026-06-28T23:59:59Z', 'description': 'CRUD de Serviços e Status'},
    {'title': 'MVP 1 - Sprint 3: Inteligência de Capacidade', 'due_on': '2026-07-05T23:59:59Z', 'description': 'Cálculo de Carga e Complexidade'},
    {'title': 'MVP 2 - Sprint 4: Previsão Financeira', 'due_on': '2026-07-12T23:59:59Z', 'description': 'Controle Financeiro e Pagamentos'},
    {'title': 'MVP 3 - Sprint 5: Gestão Visual', 'due_on': '2026-07-19T23:59:59Z', 'description': 'Dashboards e Métricas de Produtividade'},
    {'title': 'MVP 4 - Sprint 6: Relatórios Avançados', 'due_on': '2026-07-26T23:59:59Z', 'description': 'Relatórios Gerenciais e Exportação'},
    {'title': 'MVP 5 - Sprint 7: Otimização', 'due_on': '2026-08-02T23:59:59Z', 'description': 'Ajustes Finais e Otimizações'},
    {'title': 'Final - Sprint 8: Deploy e Handover', 'due_on': '2026-08-09T23:59:59Z', 'description': 'Deploy, Documentação e Treinamento'},
]

def create_milestone(title, due_on, description=''):
    url = f"{BASE_URL}/milestones"
    data = {'title': title, 'state': 'open', 'description': description, 'due_on': due_on}
    r = requests.post(url, headers=HEADERS, json=data)
    if r.status_code == 201:
        return True
    elif r.status_code == 422:
        print(f"   ℹ️ Milestone '{title}' já existe")
        return True
    return False

def create_milestones():
    print("\n📅 2. CRIANDO MILESTONES...")
    for ms in MILESTONES:
        if create_milestone(ms['title'], ms['due_on'], ms['description']):
            print(f"   ✅ Milestone '{ms['title']}' criado/verificado")
        else:
            print(f"   ❌ Erro ao criar milestone '{ms['title']}'")
        time.sleep(0.2)

# ============================================================
# 3. PROJETO E CAMPOS PERSONALIZADOS (GraphQL)
# ============================================================

def execute_graphql(query):
    r = requests.post('https://api.github.com/graphql', headers=HEADERS_GRAPHQL, json={'query': query})
    return r

def get_user_id():
    query = """
    {
      user(login: "%s") {
        id
      }
    }
    """ % REPO_OWNER
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        return data.get('data', {}).get('user', {}).get('id')
    return None

def get_project():
    query = """
    {
      user(login: "%s") {
        projectsV2(first: 10) {
          nodes {
            id
            title
            number
          }
        }
      }
    }
    """ % REPO_OWNER
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        projects = data.get('data', {}).get('user', {}).get('projectsV2', {}).get('nodes', [])
        for project in projects:
            if 'Cony Interiores' in project.get('title', ''):
                return project['id'], project['number']
    return None, None

def create_project():
    print("\n📊 3. CRIANDO PROJETO...")
    user_id = get_user_id()
    if not user_id:
        print("   ❌ Não foi possível encontrar o ID do usuário")
        return None, None
    
    mutation = """
    mutation {
      createProjectV2(input: {
        ownerId: "%s"
        title: "Cony Interiores - Sistema de Controle de Produção"
      }) {
        projectV2 {
          id
          title
          number
        }
      }
    }
    """ % user_id
    r = execute_graphql(mutation)
    if r.status_code == 200:
        data = r.json()
        if 'errors' in data:
            print(f"   ❌ Erro ao criar projeto: {data['errors']}")
            return None, None
        new_project = data.get('data', {}).get('createProjectV2', {}).get('projectV2', {})
        if new_project:
            print(f"   ✅ Projeto criado: {new_project['title']} (ID: {new_project['id']}, Nº: {new_project['number']})")
            return new_project['id'], new_project['number']
    return None, None

def main():
    print("""
    🚀 ==============================================
       SCRIPT 1: SETUP GERAL
       Labels, Milestones, Projeto e Campos
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    create_labels()
    create_milestones()
    
    project_id, project_number = get_project()
    if not project_id:
        project_id, project_number = create_project()
    else:
        print(f"\n📊 Projeto já existe: {project_id} (Nº: {project_number})")
    
    if project_id:
        print("\n🏷️ 4. CAMPOS PERSONALIZADOS")
        print("   ℹ️ Configure os campos manualmente em:")
        print(f"   https://github.com/users/{REPO_OWNER}/projects/{project_number if project_number else '4'}/settings/fields")
        print("   Campos necessários: MVP, Squad, Tipo, Prioridade, Story Points")
    
    print("\n" + "="*50)
    print("✅ SETUP GERAL CONCLUÍDO!")
    print("="*50)
    print(f"""
    🔗 Acesse:
       Repositório: https://github.com/{REPO_OWNER}/{REPO_NAME}
       Issues: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
       Milestones: https://github.com/{REPO_OWNER}/{REPO_NAME}/milestones
       Labels: https://github.com/{REPO_OWNER}/{REPO_NAME}/labels
       Projeto: https://github.com/users/{REPO_OWNER}/projects/{project_number if project_number else '4'}
    """)

if __name__ == "__main__":
    main()