#!/usr/bin/env python3
"""
Script: Limpeza Total das Issues via Python
Fecha TODAS as issues abertas do repositório
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

def get_all_open_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        # Verifica se há mais páginas
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def close_issue(issue_number):
    """Fecha uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'state': 'closed'}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r.status_code == 200

def main():
    print("""
    🧹 ==============================================
       LIMPEZA TOTAL DAS ISSUES (PYTHON)
       Fecha TODAS as issues abertas
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}")
    print("\n⚠️ ATENÇÃO: Isso irá FECHAR TODAS as issues abertas!")
    print("   Digite 'SIM' para confirmar: ", end="")
    
    confirm = input().strip().upper()
    if confirm != 'SIM':
        print("❌ Operação cancelada.")
        return
    
    print("\n🔍 Buscando issues abertas...")
    issues = get_all_open_issues()
    print(f"   Encontradas {len(issues)} issues abertas")
    
    if not issues:
        print("✅ Nenhuma issue aberta encontrada. Repositório limpo!")
        return
    
    print("\n📋 Issues que serão fechadas:")
    for issue in issues[:10]:
        print(f"   #{issue['number']}: {issue['title'][:50]}...")
    if len(issues) > 10:
        print(f"   ... e mais {len(issues) - 10} issues")
    
    print("\n🚀 Iniciando fechamento...\n")
    
    closed = 0
    for issue in issues:
        issue_number = issue['number']
        title = issue['title'][:50]
        print(f"   Fechando issue #{issue_number}: {title}...")
        
        if close_issue(issue_number):
            print(f"   ✅ Issue #{issue_number} fechada")
            closed += 1
        else:
            print(f"   ❌ Erro ao fechar issue #{issue_number}")
        
        time.sleep(0.3)
    
    print(f"""
    ==============================================
    ✅ LIMPEZA CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Issues fechadas: {closed}
    
    🔗 Acesse:
       https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)
    
    print("\n📌 Agora execute os scripts na ordem correta:")
    print("   1. python setup_github_project.py")
    print("   2. python setup_global_planning.py")
    print("   3. python setup_mvp1_planning.py")

if __name__ == "__main__":
    main()