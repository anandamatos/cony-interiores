#!/usr/bin/env python3
"""
Script 0: Limpeza Total do Repositório e Projeto
Remove todas as issues, milestones, labels e limpa o projeto
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

HEADERS_GRAPHQL = {
    'Authorization': f'Bearer {GITHUB_TOKEN}',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# FUNÇÕES DE LIMPEZA
# ============================================================

def execute_graphql(query):
    """Executa uma query GraphQL"""
    r = requests.post('https://api.github.com/graphql', headers=HEADERS_GRAPHQL, json={'query': query})
    return r

def delete_issue(issue_number):
    """Fecha uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'state': 'closed'}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r.status_code == 200

def delete_milestone(ms_number):
    """Deleta um milestone"""
    url = f"{BASE_URL}/milestones/{ms_number}"
    r = requests.delete(url, headers=HEADERS)
    return r.status_code == 204

def delete_label(label_name):
    """Deleta uma label"""
    url = f"{BASE_URL}/labels/{label_name}"
    r = requests.delete(url, headers=HEADERS)
    return r.status_code == 204

def delete_project():
    """Deleta o projeto via GraphQL"""
    # Busca o projeto
    query = """
    {
      user(login: "%s") {
        projectsV2(first: 10) {
          nodes {
            id
            title
            number
          }
        }
      }
    }
    """ % REPO_OWNER
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        projects = data.get('data', {}).get('user', {}).get('projectsV2', {}).get('nodes', [])
        for project in projects:
            if 'Cony Interiores' in project.get('title', ''):
                project_id = project['id']
                mutation = """
                mutation {
                  deleteProjectV2(input: {projectId: "%s"}) {
                    clientMutationId
                  }
                }
                """ % project_id
                
                r_del = execute_graphql(mutation)
                if r_del.status_code == 200:
                    print(f"   ✅ Projeto '{project['title']}' deletado")
                    return True
                else:
                    print(f"   ❌ Erro ao deletar projeto: {r_del.text}")
                    return False
    return False

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🧹 ==============================================
       SCRIPT 0: LIMPEZA TOTAL
       Remove issues, milestones, labels e projeto
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}")
    print("\n⚠️ ATENÇÃO: Isso irá REMOVER TODAS as issues, milestones, labels e o projeto!")
    print("   Digite 'SIM' para confirmar: ", end="")
    
    confirm = input().strip().upper()
    if confirm != 'SIM':
        print("❌ Operação cancelada.")
        return
    
    print("\n🚀 Iniciando limpeza...\n")
    
    # 1. Fechar todas as issues
    print("📌 1. REMOVENDO ISSUES...")
    url = f"{BASE_URL}/issues?state=all"
    r = requests.get(url, headers=HEADERS)
    
    if r.status_code == 200:
        issues = r.json()
        print(f"   Encontradas {len(issues)} issues")
        
        for issue in issues:
            issue_number = issue['number']
            title = issue['title'][:50]
            print(f"   Fechando issue #{issue_number}: {title}...")
            delete_issue(issue_number)
            time.sleep(0.2)
    else:
        print(f"   ❌ Erro ao buscar issues: {r.status_code}")
    
    # 2. Remover milestones
    print("\n📅 2. REMOVENDO MILESTONES...")
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    
    if r.status_code == 200:
        milestones = r.json()
        print(f"   Encontrados {len(milestones)} milestones")
        
        for ms in milestones:
            ms_number = ms['number']
            title = ms['title'][:50]
            print(f"   Removendo milestone '{title}'...")
            delete_milestone(ms_number)
            time.sleep(0.2)
    else:
        print(f"   ❌ Erro ao buscar milestones: {r.status_code}")
    
    # 3. Remover labels (mantendo as padrão)
    print("\n🏷️ 3. REMOVENDO LABELS...")
    url = f"{BASE_URL}/labels"
    r = requests.get(url, headers=HEADERS)
    
    DEFAULT_LABELS = ['bug', 'documentation', 'duplicate', 'enhancement', 
                      'good first issue', 'help wanted', 'invalid', 'question', 'wontfix']
    
    if r.status_code == 200:
        labels = r.json()
        print(f"   Encontradas {len(labels)} labels")
        
        for label in labels:
            label_name = label['name']
            if label_name not in DEFAULT_LABELS:
                print(f"   Removendo label '{label_name}'...")
                delete_label(label_name)
                time.sleep(0.2)
            else:
                print(f"   ℹ️ Mantendo label padrão '{label_name}'")
    else:
        print(f"   ❌ Erro ao buscar labels: {r.status_code}")
    
    # 4. Deletar projeto
    print("\n📊 4. REMOVENDO PROJETO...")
    delete_project()
    
    print("\n" + "="*50)
    print("✅ LIMPEZA CONCLUÍDA!")
    print("="*50)
    print("""
    📋 Agora execute os scripts na seguinte ordem:
    
    1. python setup_github_project.py  # Script 1: Labels, Milestones, Projeto e Campos
    2. python setup_global_planning.py  # Script 2: Épicos
    3. python setup_mvp1_planning.py    # Script 3: Stories e Tasks com campos do projeto
    
    🔗 Acesse: https://github.com/anandamatos/cony-interiores/issues
    """)

if __name__ == "__main__":
    main()