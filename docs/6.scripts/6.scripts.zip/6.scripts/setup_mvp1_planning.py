#!/usr/bin/env python3
"""
Script 3: Planejamento MVP 1 - Criação de Stories com Tasks como Checklist
As Tasks são mantidas como lista de verificação DENTRO das Stories
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# MAPEAMENTO DE MEMBROS
# ============================================================

MEMBERS = {
    'STORY-M1-FND-001': {'assignee': 'Marcus1423', 'squad': 'Foundation'},
    'STORY-M1-FND-002': {'assignee': 'mariagabrielle428-ship-it', 'squad': 'Foundation'},
    'STORY-M1-FND-003': {'assignee': 'Marcus1423', 'squad': 'Foundation'},
    'STORY-M1-CORE-001': {'assignee': 'Matheus-G-R', 'squad': 'Core Business'},
    'STORY-M1-CORE-002': {'assignee': 'Matheus-G-R', 'squad': 'Core Business'},
    'STORY-M1-CORE-003': {'assignee': 'Matheus-G-R', 'squad': 'Core Business'},
    'STORY-M1-UX-001': {'assignee': 'gabrielaugusto872', 'squad': 'UX & Experience'},
    'STORY-M1-UX-002': {'assignee': 'Bianca2703', 'squad': 'UX & Experience'},
    'STORY-M1-UX-003': {'assignee': 'isabarrs', 'squad': 'UX & Experience'},
}

LEADERS = {
    'Foundation': 'lobaque29',
    'Core Business': 'karinakaduda19-cyber',
    'UX & Experience': 'anandamatos'
}

# ============================================================
# STORIES COM TASKS EMBUTIDAS (checklist)
# ============================================================

STORIES = [
    # Sprint 1
    {
        'id': 'STORY-M1-FND-001',
        'title': 'Configuração do Backend Django',
        'epic_id': 'EPIC-M1-FND-001',
        'sprint': 'MVP 1 - Sprint 1: Base Digital',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M1-FND-001: Inicializar projeto Django',
            'TASK-M1-FND-002: Configurar DRF',
            'TASK-M1-FND-003: Configurar PostgreSQL no docker-compose',
            'TASK-M1-FND-004: Configurar CORS',
            'TASK-M1-FND-005: Implementar logging estruturado'
        ],
        'discovery_tasks': [
            'Validar versões do Python, Django e PostgreSQL',
            'Definir arquitetura de containers',
            'Mapear necessidades de segurança e variáveis de ambiente',
            'Validar configuração de CORS para os ambientes',
            'Definir estratégia de logging'
        ],
        'measurement_tasks': [
            'Definir KPIs de infraestrutura',
            'Estabelecer baseline de performance',
            'Criar métricas de tempo de setup',
            'Definir cobertura mínima de testes'
        ]
    },
    {
        'id': 'STORY-M1-FND-002',
        'title': 'Configuração do Frontend React',
        'epic_id': 'EPIC-M1-FND-001',
        'sprint': 'MVP 1 - Sprint 1: Base Digital',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M1-FND-006: Inicializar projeto React com Vite',
            'TASK-M1-FND-007: Configurar React Router',
            'TASK-M1-FND-008: Configurar Axios',
            'TASK-M1-FND-009: Configurar ESLint e Prettier',
            'TASK-M1-FND-010: Configurar Husky'
        ],
        'discovery_tasks': [
            'Validar versão do React e Vite',
            'Definir estrutura de componentes',
            'Mapear necessidades de performance (lazy loading)',
            'Validar configuração de API (Axios)',
            'Definir padrões de código (ESLint)'
        ],
        'measurement_tasks': [
            'Definir KPIs de performance frontend',
            'Estabelecer baseline de carregamento',
            'Criar métricas de bundle size',
            'Definir padrões de acessibilidade'
        ]
    },
    {
        'id': 'STORY-M1-CORE-001',
        'title': 'Cadastro de Costureiras',
        'epic_id': 'EPIC-M1-CORE-001',
        'sprint': 'MVP 1 - Sprint 1: Base Digital',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M1-CORE-001: Criar model Costureira',
            'TASK-M1-CORE-002: Implementar serializers',
            'TASK-M1-CORE-003: Implementar endpoints CRUD',
            'TASK-M1-CORE-004: Adicionar validações',
            'TASK-M1-CORE-005: Escrever testes unitários'
        ],
        'discovery_tasks': [
            'Validar campos obrigatórios da Costureira',
            'Definir regras de unicidade',
            'Mapear relacionamentos com outros modelos',
            'Validar formato de dados (contato, especialidade)',
            'Definir padrão de API REST'
        ],
        'measurement_tasks': [
            'Definir KPIs de cadastro',
            'Estabelecer tempo de resposta CRUD',
            'Criar métricas de validação',
            'Definir cobertura de testes unitários'
        ]
    },
    {
        'id': 'STORY-M1-UX-001',
        'title': 'Layout Base e Design System',
        'epic_id': 'EPIC-M1-UX-001',
        'sprint': 'MVP 1 - Sprint 1: Base Digital',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M1-UX-001: Configurar Tailwind CSS',
            'TASK-M1-UX-002: Criar componentes base',
            'TASK-M1-UX-003: Implementar layout principal',
            'TASK-M1-UX-004: Criar página Home',
            'TASK-M1-UX-005: Garantir responsividade'
        ],
        'discovery_tasks': [
            'Validar cores e tema da Cony Interiores',
            'Definir estrutura de navegação',
            'Mapear componentes necessários',
            'Prototipar layout principal',
            'Validar requisitos de responsividade'
        ],
        'measurement_tasks': [
            'Definir KPIs de usabilidade',
            'Estabelecer padrões de design',
            'Criar métricas de navegação',
            'Definir testes de UX'
        ]
    },
    # Sprint 2
    {
        'id': 'STORY-M1-FND-003',
        'title': 'Autenticação e Segurança',
        'epic_id': 'EPIC-M1-FND-001',
        'sprint': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'story_points': 5,
        'priority': 'P1',
        'tasks': [
            'TASK-M1-FND-011: Implementar autenticação JWT',
            'TASK-M1-FND-012: Configurar middleware de segurança',
            'TASK-M1-FND-013: Implementar permissões',
            'TASK-M1-FND-014: Implementar refresh token',
            'TASK-M1-FND-015: Escrever testes de segurança'
        ],
        'discovery_tasks': [
            'Validar estratégia de autenticação (JWT)',
            'Definir permissões por perfil',
            'Mapear endpoints que precisam de proteção',
            'Validar política de refresh token',
            'Definir estratégia de logout'
        ],
        'measurement_tasks': [
            'Definir KPIs de segurança',
            'Estabelecer tempo de resposta com JWT',
            'Criar métricas de tentativas de acesso',
            'Definir cobertura de testes de segurança'
        ]
    },
    {
        'id': 'STORY-M1-CORE-002',
        'title': 'CRUD de Serviços',
        'epic_id': 'EPIC-M1-CORE-001',
        'sprint': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M1-CORE-006: Criar model Servico',
            'TASK-M1-CORE-007: Implementar serializers',
            'TASK-M1-CORE-008: Implementar endpoints CRUD',
            'TASK-M1-CORE-009: Adicionar filtros',
            'TASK-M1-CORE-010: Escrever testes unitários'
        ],
        'discovery_tasks': [
            'Validar campos do modelo Servico',
            'Definir status possíveis (enviado, produção, pronto, entregue, pago)',
            'Mapear regras de complexidade',
            'Validar cálculos de valor',
            'Definir filtros por status e costureira'
        ],
        'measurement_tasks': [
            'Definir KPIs de fluxo operacional',
            'Estabelecer tempo de resposta dos endpoints',
            'Criar métricas de acurácia dos filtros',
            'Definir cobertura de testes'
        ]
    },
    {
        'id': 'STORY-M1-UX-002',
        'title': 'Formulários e Integração API',
        'epic_id': 'EPIC-M1-UX-001',
        'sprint': 'MVP 1 - Sprint 2: Fluxo Operacional',
        'story_points': 5,
        'priority': 'P1',
        'tasks': [
            'TASK-M1-UX-006: Criar página de listagem de costureiras',
            'TASK-M1-UX-007: Implementar formulário de cadastro/edição',
            'TASK-M1-UX-008: Integrar com API',
            'TASK-M1-UX-009: Adicionar validações e feedback',
            'TASK-M1-UX-010: Implementar roteamento'
        ],
        'discovery_tasks': [
            'Validar fluxo de cadastro de costureiras',
            'Definir feedbacks visuais (toasts/alertas)',
            'Mapear validações do formulário',
            'Prototipar página de listagem',
            'Validar integração com API'
        ],
        'measurement_tasks': [
            'Definir KPIs de eficiência do formulário',
            'Estabelecer taxa de erro em cadastros',
            'Criar métricas de tempo de preenchimento',
            'Definir testes de integração'
        ]
    },
    # Sprint 3
    {
        'id': 'STORY-M1-CORE-003',
        'title': 'Cálculo de Capacidade',
        'epic_id': 'EPIC-M1-CORE-001',
        'sprint': 'MVP 1 - Sprint 3: Inteligência de Capacidade',
        'story_points': 5,
        'priority': 'P1',
        'tasks': [
            'TASK-M1-CORE-011: Implementar função de cálculo de carga',
            'TASK-M1-CORE-012: Integrar índice de complexidade',
            'TASK-M1-CORE-013: Criar endpoint de consulta de carga',
            'TASK-M1-CORE-014: Implementar lógica de sugestão de alocação',
            'TASK-M1-CORE-015: Escrever testes'
        ],
        'discovery_tasks': [
            'Validar fórmula de cálculo de carga',
            'Definir pesos para índices de complexidade (P/M/G/Esp)',
            'Mapear regras de distribuição',
            'Validar lógica de sugestão de alocação',
            'Definir formato do endpoint de carga'
        ],
        'measurement_tasks': [
            'Definir KPIs de capacidade',
            'Estabelecer precisão do cálculo',
            'Criar métricas de acurácia da alocação',
            'Definir testes de integração'
        ]
    },
    {
        'id': 'STORY-M1-UX-003',
        'title': 'Visualização de Carga',
        'epic_id': 'EPIC-M1-UX-001',
        'sprint': 'MVP 1 - Sprint 3: Inteligência de Capacidade',
        'story_points': 5,
        'priority': 'P1',
        'tasks': [
            'TASK-M1-UX-011: Criar página de visualização de capacidade',
            'TASK-M1-UX-012: Implementar cards de carga',
            'TASK-M1-UX-013: Criar gráfico comparativo',
            'TASK-M1-UX-014: Implementar filtros',
            'TASK-M1-UX-015: Integrar com API'
        ],
        'discovery_tasks': [
            'Validar tipos de gráficos necessários',
            'Definir estrutura de cards de carga',
            'Mapear filtros por período e tipo',
            'Prototipar página de visualização',
            'Validar integração com API de capacidade'
        ],
        'measurement_tasks': [
            'Definir KPIs de visualização de dados',
            'Estabelecer tempo de renderização dos gráficos',
            'Criar métricas de usabilidade',
            'Definir testes de performance'
        ]
    },
]

# ============================================================
# FUNÇÕES
# ============================================================

def get_milestone_number(title):
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for ms in r.json():
            if ms['title'] == title:
                return ms['number']
    return None

def get_epic_number(epic_id):
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if epic_id in issue['title']:
                return issue['number']
    return None

def issue_exists(title):
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if issue['title'] == title:
                return True
    return False

def create_issue(title, body, labels, milestone_number, assignee=None):
    url = f"{BASE_URL}/issues"
    data = {'title': title, 'body': body, 'labels': labels, 'milestone': milestone_number}
    if assignee:
        data['assignees'] = [assignee]
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def add_comment(issue_number, body):
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    data = {'body': body}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def build_story_body(story):
    """Constrói o corpo da story com todas as seções"""
    body = f"""## 📖 User Story
Como {story['title'].split(':')[0] if ':' in story['title'] else 'usuário'}, quero {story['title'].split(':')[1] if ':' in story['title'] else story['title']} para melhorar o processo de produção.

## ✅ Critérios de Aceite
- [ ] Todos os critérios de aceite definidos para esta história
- [ ] Testes automatizados passando
- [ ] Código revisado e aprovado
- [ ] Documentação atualizada

## 📋 Tarefas (Checklist)
"""
    # Adiciona as tasks como checklist
    for task in story['tasks']:
        body += f"- [ ] {task}\n"
    
    # Adiciona Discovery
    body += f"""
## 🔍 Tarefas de Discovery
"""
    for task in story['discovery_tasks']:
        body += f"- [ ] {task}\n"
    
    # Adiciona Measurement
    body += f"""
## 📊 Tarefas de Mensuração
"""
    for task in story['measurement_tasks']:
        body += f"- [ ] {task}\n"
    
    # Adiciona Metadados
    body += f"""
---
## 🏷️ Metadados
**ID:** {story['id']}
**Squad:** {MEMBERS.get(story['id'], {}).get('squad', 'N/A')}
**MVP:** MVP 1
**Tipo:** Story
**Estimativa:** {story['story_points']} Story Points
**Prioridade:** {story['priority']}
**Épico:** {story['epic_id']}
**Sprint:** {story['sprint']}
**Responsável:** @{MEMBERS.get(story['id'], {}).get('assignee', 'N/A')}
"""
    return body

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       SCRIPT 3: PLANEJAMENTO MVP 1
       Stories com Tasks como Checklist
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    created = 0
    errors = 0
    
    for story in STORIES:
        print(f"\n📌 Processando: {story['id']}")
        
        # Busca o épico
        epic_number = get_epic_number(story['epic_id'])
        if not epic_number:
            print(f"   ⚠️ Épico '{story['epic_id']}' não encontrado!")
            errors += 1
            continue
        
        # Busca o milestone
        milestone_number = get_milestone_number(story['sprint'])
        if not milestone_number:
            print(f"   ⚠️ Milestone '{story['sprint']}' não encontrado!")
            errors += 1
            continue
        
        # Prepara os dados
        assignee = MEMBERS.get(story['id'], {}).get('assignee')
        squad = MEMBERS.get(story['id'], {}).get('squad', '').lower().replace(' ', '-')
        labels = ['story', 'mvp1', squad] if squad else ['story', 'mvp1']
        title = f"[{story['id']}] Story: {story['title']}"
        body = build_story_body(story)
        
        # Verifica se já existe
        if issue_exists(title):
            print(f"   ℹ️ Story já existe: {title}")
            continue
        
        # Cria a story
        result = create_issue(title, body, labels, milestone_number, assignee)
        
        if result.status_code == 201:
            issue_number = result.json()['number']
            print(f"   ✅ Story criada: #{issue_number}")
            created += 1
            
            # Comentário vinculando ao épico
            comment = f"🔗 Esta Story faz parte do Épico #{epic_number} - {story['epic_id']}"
            add_comment(issue_number, comment)
            
            # Atribui o líder
            leader = LEADERS.get(MEMBERS.get(story['id'], {}).get('squad', ''))
            if leader:
                url = f"{BASE_URL}/issues/{issue_number}"
                data = {'assignees': [leader, assignee] if assignee else [leader]}
                requests.patch(url, headers=HEADERS, json=data)
                print(f"   ✅ Líder @{leader} atribuído")
            
            time.sleep(0.5)
        else:
            print(f"   ❌ Erro ao criar story: {result.status_code}")
            errors += 1
    
    print(f"""
    ==============================================
    ✅ PLANEJAMENTO MVP 1 CONCLUÍDO!
    ==============================================
    📊 Resumo:
       Stories criadas: {created}
       Erros: {errors}
       Tasks: 45 (embutidas como checklist nas stories)
    
    🔗 Acesse:
       Issues: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
       Milestones: https://github.com/{REPO_OWNER}/{REPO_NAME}/milestones
    """)

if __name__ == "__main__":
    main()