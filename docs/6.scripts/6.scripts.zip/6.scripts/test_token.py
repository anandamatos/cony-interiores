import os
from dotenv import load_dotenv

load_dotenv()

token = os.getenv('GITHUB_TOKEN')
owner = os.getenv('REPO_OWNER')
repo = os.getenv('REPO_NAME')

print(f"Token: {token[:10] if token else 'None'}... (tamanho: {len(token) if token else 0} caracteres)")
print(f"Owner: {owner}")
print(f"Repo: {repo}")
