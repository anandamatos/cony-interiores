#!/usr/bin/env python3
"""
Script para listar todos os campos personalizados do projeto
"""
import os
import requests
import json
from dotenv import load_dotenv

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS_GRAPHQL = {
    'Authorization': f'Bearer {GITHUB_TOKEN}',
    'Content-Type': 'application/json',
}

def execute_graphql(query):
    r = requests.post('https://api.github.com/graphql', headers=HEADERS_GRAPHQL, json={'query': query})
    return r

def get_project_id():
    query = """
    {
      user(login: "%s") {
        projectsV2(first: 10) {
          nodes {
            id
            title
            number
          }
        }
      }
    }
    """ % REPO_OWNER
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        projects = data.get('data', {}).get('user', {}).get('projectsV2', {}).get('nodes', [])
        for project in projects:
            if 'Cony Interiores' in project.get('title', ''):
                return project['id'], project['number']
    return None, None

def list_fields(project_id):
    query = """
    {
      node(id: "%s") {
        ... on ProjectV2 {
          fields(first: 20) {
            nodes {
              ... on ProjectV2Field {
                id
                name
                dataType
              }
              ... on ProjectV2SingleSelectField {
                id
                name
                dataType
                options {
                  id
                  name
                }
              }
            }
          }
        }
      }
    }
    """ % project_id
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        fields = data.get('data', {}).get('node', {}).get('fields', {}).get('nodes', [])
        return fields
    return []

def main():
    print("""
    🔍 ==============================================
       LISTAGEM DE CAMPOS DO PROJETO
    ==============================================
    """)
    
    project_id, project_number = get_project_id()
    if not project_id:
        print("❌ Projeto não encontrado!")
        return
    
    print(f"📊 Projeto: Nº {project_number} (ID: {project_id})\n")
    print("📋 CAMPOS ENCONTRADOS:\n")
    
    fields = list_fields(project_id)
    
    for field in fields:
        print(f"   📌 {field.get('name', 'N/A')}")
        print(f"      ID: {field.get('id', 'N/A')}")
        print(f"      Tipo: {field.get('dataType', 'N/A')}")
        
        if 'options' in field and field['options']:
            print(f"      Opções:")
            for option in field['options']:
                print(f"         - {option['name']} (ID: {option['id']})")
        print()

if __name__ == "__main__":
    main()
