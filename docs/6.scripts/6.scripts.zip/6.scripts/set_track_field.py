#!/usr/bin/env python3
"""
Script: Preencher o campo "Track" das issues no projeto
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS_GRAPHQL = {
    'Authorization': f'Bearer {GITHUB_TOKEN}',
    'Content-Type': 'application/json',
}

def execute_graphql(query):
    r = requests.post('https://api.github.com/graphql', headers=HEADERS_GRAPHQL, json={'query': query})
    return r

def get_project_id():
    query = """
    {
      user(login: "%s") {
        projectsV2(first: 10) {
          nodes {
            id
            title
            number
          }
        }
      }
    }
    """ % REPO_OWNER
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        projects = data.get('data', {}).get('user', {}).get('projectsV2', {}).get('nodes', [])
        for project in projects:
            if 'Cony Interiores' in project.get('title', ''):
                return project['id']
    return None

def get_field_id(project_id, field_name):
    """Busca o ID do campo pelo nome"""
    query = """
    {
      node(id: "%s") {
        ... on ProjectV2 {
          fields(first: 20) {
            nodes {
              ... on ProjectV2Field {
                id
                name
                dataType
              }
              ... on ProjectV2SingleSelectField {
                id
                name
                dataType
                options {
                  id
                  name
                }
              }
            }
          }
        }
      }
    }
    """ % project_id
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        fields = data.get('data', {}).get('node', {}).get('fields', {}).get('nodes', [])
        for field in fields:
            if field.get('name') == field_name:
                return field
    return None

def get_option_id(field_data, option_name):
    """Busca o ID de uma opção do campo"""
    if 'options' in field_data:
        for option in field_data['options']:
            if option['name'] == option_name:
                return option['id']
    return None

def get_project_items(project_id):
    """Busca todos os itens do projeto"""
    query = """
    {
      node(id: "%s") {
        ... on ProjectV2 {
          items(first: 100) {
            nodes {
              id
              content {
                ... on Issue {
                  id
                  number
                  title
                }
              }
            }
          }
        }
      }
    }
    """ % project_id
    
    r = execute_graphql(query)
    if r.status_code == 200:
        data = r.json()
        items = data.get('data', {}).get('node', {}).get('items', {}).get('nodes', [])
        return items
    return []

def update_project_item_field(project_id, item_id, field_id, value):
    mutation = """
    mutation {
      updateProjectV2ItemFieldValue(input: {
        projectId: "%s"
        itemId: "%s"
        fieldId: "%s"
        value: %s
      }) {
        projectV2Item {
          id
        }
      }
    }
    """ % (project_id, item_id, field_id, json.dumps(value))
    
    r = execute_graphql(mutation)
    if r.status_code == 200:
        data = r.json()
        if 'errors' not in data:
            return True
    return False

def main():
    print("""
    🚀 ==============================================
       SCRIPT: PREENCHER CAMPO "TRACK"
       Define Discovery, Delivery ou Measurement
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # 1. Busca o projeto
    project_id = get_project_id()
    if not project_id:
        print("❌ Projeto não encontrado!")
        return
    
    print(f"📊 Projeto encontrado (ID: {project_id})")
    
    # 2. Busca o campo "Track"
    field_data = get_field_id(project_id, 'Track')
    if not field_data:
        print("❌ Campo 'Track' não encontrado!")
        print("   Crie-o manualmente em:")
        print(f"   https://github.com/users/{REPO_OWNER}/projects/7/settings/fields")
        return
    
    field_id = field_data['id']
    print(f"   Campo 'Track' encontrado (ID: {field_id})")
    
    # 3. Busca as opções
    discovery_opt = get_option_id(field_data, 'Discovery')
    delivery_opt = get_option_id(field_data, 'Delivery')
    measurement_opt = get_option_id(field_data, 'Measurement')
    
    print(f"   Opções: Discovery={discovery_opt}, Delivery={delivery_opt}, Measurement={measurement_opt}")
    
    # 4. Busca os itens do projeto
    items = get_project_items(project_id)
    print(f"\n📊 Encontrados {len(items)} itens no projeto")
    
    # 5. Define o Track para cada item
    updated = 0
    for item in items:
        content = item.get('content', {})
        if not content:
            continue
        
        title = content.get('title', '')
        item_id = item.get('id')
        
        # Determina o Track baseado no título
        track = None
        
        if 'EPIC' in title or 'Epic' in title:
            track = 'Discovery'
        elif 'STORY' in title and 'Discovery' in title:
            track = 'Discovery'
        elif 'STORY' in title and 'Measurement' in title:
            track = 'Measurement'
        elif 'STORY' in title:
            track = 'Delivery'
        elif 'TASK' in title:
            track = 'Delivery'
        else:
            # Se não conseguiu identificar, pula
            continue
        
        # Mapeia o nome para o ID da opção
        option_id = None
        if track == 'Discovery':
            option_id = discovery_opt
        elif track == 'Delivery':
            option_id = delivery_opt
        elif track == 'Measurement':
            option_id = measurement_opt
        
        if not option_id:
            print(f"   ⚠️ Opção '{track}' não encontrada para issue '{title[:30]}...'")
            continue
        
        # Atualiza o campo
        success = update_project_item_field(project_id, item_id, field_id, {'singleSelectOptionId': option_id})
        if success:
            print(f"   ✅ #{content.get('number', '?')}: {title[:40]}... → {track}")
            updated += 1
        else:
            print(f"   ❌ Erro ao atualizar #{content.get('number', '?')}")
        
        time.sleep(0.3)
    
    print(f"""
    ==============================================
    ✅ ATUALIZAÇÃO CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Itens atualizados: {updated}
    
    🔗 Acesse o projeto:
    https://github.com/users/{REPO_OWNER}/projects/7
    """)

if __name__ == "__main__":
    main()