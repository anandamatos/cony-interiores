#!/usr/bin/env python3
"""
Script: Manter Apenas as Issues Mais Recentes
Fecha todas as issues duplicadas, mantendo apenas a mais recente de cada ID
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
from collections import defaultdict

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

def get_all_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def close_issue(issue_number):
    """Fecha uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'state': 'closed'}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r.status_code == 200

def extract_id(title):
    """Extrai o ID padronizado do título da issue"""
    import re
    patterns = [
        r'EPIC-M\d+-[A-Z]+-\d{3}',
        r'STORY-M\d+-[A-Z]+-\d{3}',
        r'TASK-M\d+-[A-Z]+-\d{3}',
    ]
    for pattern in patterns:
        match = re.search(pattern, title)
        if match:
            return match.group(0)
    return None

def main():
    print("""
    🧹 ==============================================
       MANTER APENAS ISSUES MAIS RECENTES
       Fecha duplicatas, mantém a mais nova de cada ID
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}")
    
    issues = get_all_issues()
    print(f"   Encontradas {len(issues)} issues abertas")
    
    if not issues:
        print("✅ Nenhuma issue aberta encontrada.")
        return
    
    # Agrupa issues por ID
    issues_by_id = defaultdict(list)
    for issue in issues:
        issue_id = extract_id(issue['title'])
        if issue_id:
            issues_by_id[issue_id].append({
                'number': issue['number'],
                'title': issue['title'],
                'created_at': issue['created_at']
            })
    
    print(f"\n📊 Encontrados {len(issues_by_id)} IDs únicos")
    
    to_close = []
    to_keep = []
    
    for issue_id, issue_list in issues_by_id.items():
        # Ordena por data de criação (mais recente primeiro)
        issue_list.sort(key=lambda x: x['created_at'], reverse=True)
        
        # Mantém a mais recente
        to_keep.append(issue_list[0])
        
        # Fecha as demais
        for issue in issue_list[1:]:
            to_close.append(issue)
    
    print(f"   📌 Issues a manter: {len(to_keep)}")
    print(f"   🗑️ Issues a fechar: {len(to_close)}")
    
    if not to_close:
        print("\n✅ Nenhuma duplicata encontrada!")
        return
    
    print("\n📋 Issues que serão FECHADAS (duplicatas):")
    for issue in to_close:
        print(f"   #{issue['number']}: {issue['title'][:60]}...")
    
    print("\n📋 Issues que serão MANTIDAS (mais recentes):")
    for issue in to_keep:
        print(f"   #{issue['number']}: {issue['title'][:60]}...")
    
    print("\n🚀 Iniciando limpeza...\n")
    
    closed = 0
    for issue in to_close:
        issue_number = issue['number']
        title = issue['title'][:50]
        print(f"   Fechando issue #{issue_number}: {title}...")
        
        if close_issue(issue_number):
            print(f"   ✅ Issue #{issue_number} fechada")
            closed += 1
        else:
            print(f"   ❌ Erro ao fechar issue #{issue_number}")
        
        time.sleep(0.3)
    
    print(f"""
    ==============================================
    ✅ LIMPEZA CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Issues fechadas: {closed}
       Issues mantidas: {len(to_keep)}
    
    🔗 Acesse:
       https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)

if __name__ == "__main__":
    main()