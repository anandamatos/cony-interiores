#!/usr/bin/env python3
"""
Script: Limpeza Total das Issues
Remove TODAS as issues do repositório (fecha e deleta)
"""
import os
import requests
import json
from dotenv import load_dotenv
import time

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# FUNÇÕES
# ============================================================

def get_all_issues():
    """Busca TODAS as issues (abertas e fechadas)"""
    url = f"{BASE_URL}/issues?state=all&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        # Verifica se há mais páginas
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def close_issue(issue_number):
    """Fecha uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'state': 'closed'}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r.status_code == 200

def delete_issue_permanently(issue_number):
    """
    Deleta uma issue permanentemente (usando a API de admin)
    Nota: Isso só funciona se você tiver permissões de admin no repositório
    """
    url = f"{BASE_URL}/issues/{issue_number}"
    r = requests.delete(url, headers=HEADERS)
    return r.status_code == 204

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🧹 ==============================================
       LIMPEZA TOTAL DAS ISSUES
       Remove TODAS as issues do repositório
    ==============================================
    """)
    
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}")
    print("\n⚠️ ATENÇÃO: Isso irá REMOVER TODAS as issues do repositório!")
    print("   Não será possível recuperar as issues após a remoção.")
    print("   Digite 'SIM' para confirmar: ", end="")
    
    confirm = input().strip().upper()
    if confirm != 'SIM':
        print("❌ Operação cancelada.")
        return
    
    print("\n🔍 Buscando issues...")
    all_issues = get_all_issues()
    print(f"   Encontradas {len(all_issues)} issues")
    
    if not all_issues:
        print("✅ Nenhuma issue encontrada. Repositório limpo!")
        return
    
    print("\n📋 Issues encontradas:")
    for issue in all_issues[:10]:  # Mostra as 10 primeiras
        print(f"   #{issue['number']}: {issue['title'][:50]}...")
    if len(all_issues) > 10:
        print(f"   ... e mais {len(all_issues) - 10} issues")
    
    print("\n🚀 Iniciando remoção...\n")
    
    removed = 0
    for issue in all_issues:
        issue_number = issue['number']
        title = issue['title'][:50]
        print(f"   Removendo issue #{issue_number}: {title}...")
        
        # Primeiro fecha a issue
        if close_issue(issue_number):
            print(f"   ✅ Issue #{issue_number} fechada")
            
            # Tenta deletar permanentemente
            if delete_issue_permanently(issue_number):
                print(f"   ✅ Issue #{issue_number} deletada permanentemente")
            else:
                print(f"   ℹ️ Issue #{issue_number} fechada (não foi possível deletar permanentemente)")
            removed += 1
        else:
            print(f"   ❌ Erro ao fechar issue #{issue_number}")
        
        time.sleep(0.3)
    
    print(f"""
    ==============================================
    ✅ LIMPEZA CONCLUÍDA!
    ==============================================
    
    📊 Resumo:
       Issues removidas/fechadas: {removed}
    
    🔗 Acesse:
       https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)
    
    print("\n📌 Agora execute os scripts na ordem correta APENAS UMA VEZ:")
    print("   1. python setup_github_project.py")
    print("   2. python setup_global_planning.py")
    print("   3. python setup_mvp1_planning.py")
    print("   4. python update_project_fields.py")

if __name__ == "__main__":
    main()