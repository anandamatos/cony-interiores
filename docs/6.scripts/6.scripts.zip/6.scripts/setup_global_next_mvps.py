#!/usr/bin/env python3
"""
Script: Planejamento Global - Épicos dos MVPs 2, 3, 4, 5 e Final
1. Fecha issues conflitantes existentes
2. Cria APENAS os Épicos (issues) para todos os MVPs seguintes
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# 1. FUNÇÕES PARA FECHAR ISSUES CONFLITANTES
# ============================================================

def get_all_open_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def close_issue(issue_number):
    """Fecha uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'state': 'closed'}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r.status_code == 200

def close_conflicting_epics():
    """Fecha épicos conflitantes (MVP 2+) que podem conflitar com o novo planejamento"""
    print("\n🧹 FECHANDO ÉPICOS CONFLITANTES...")
    
    # Padrões de IDs de épicos que podem conflitar
    conflict_patterns = [
        r'EPIC-M[2-5]-',   # Épicos MVP 2-5
        r'EPIC-FIN-',      # Épico Final
    ]
    
    issues = get_all_open_issues()
    closed = 0
    
    for issue in issues:
        title = issue['title']
        number = issue['number']
        
        # Verifica se é um épico conflitante
        is_conflict = False
        for pattern in conflict_patterns:
            if re.search(pattern, title) and 'Epic' in title:
                is_conflict = True
                break
        
        if is_conflict:
            print(f"   Fechando épico #{number}: {title[:50]}...")
            if close_issue(number):
                print(f"   ✅ Épico #{number} fechado")
                closed += 1
            else:
                print(f"   ❌ Erro ao fechar épico #{number}")
            time.sleep(0.3)
    
    print(f"   Total de épicos fechados: {closed}")
    return closed

# ============================================================
# 2. DEFINIÇÃO DOS ÉPICOS PARA MVPs 2-5 E FINAL
# ============================================================

EPICS = [
    # ===== MVP 2 =====
    {
        'id': 'EPIC-M2-CORE-001',
        'title': 'Controle Financeiro',
        'squad': 'Core Business',
        'mvp': 'MVP 2',
        'milestone': 'MVP 2 - Sprint 4: Previsão Financeira',
        'body': """## 🎯 Objetivo do Épico
Implementar controle financeiro e planejamento de pagamentos para costureiras.

## 👥 Squad Responsável
**Core Business**

## 📌 Definition of Done
- [ ] Modelo de dados financeiro implementado
- [ ] Soma automática de valores pendentes por costureira
- [ ] Planejamento de pagamentos semanais/mensais
- [ ] Interface de resumo financeiro
- [ ] Integração com status de serviços

## 📊 Stories Relacionadas
- [ ] STORY-M2-CORE-001: Modelo Financeiro
- [ ] STORY-M2-CORE-002: Cálculo de Pagamentos"""
    },
    {
        'id': 'EPIC-M2-UX-001',
        'title': 'Interface Financeira',
        'squad': 'UX & Experience',
        'mvp': 'MVP 2',
        'milestone': 'MVP 2 - Sprint 4: Previsão Financeira',
        'body': """## 🎯 Objetivo do Épico
Interface para visualização e gestão de pagamentos.

## 👥 Squad Responsável
**UX & Experience**

## 📌 Definition of Done
- [ ] Dashboard financeiro implementado
- [ ] Visualização de valores pendentes
- [ ] Resumo semanal/mensal por costureira
- [ ] Gráficos de evolução de pagamentos

## 📊 Stories Relacionadas
- [ ] STORY-M2-UX-001: Dashboard Financeiro"""
    },
    {
        'id': 'EPIC-M2-FND-001',
        'title': 'Infraestrutura Financeira',
        'squad': 'Foundation',
        'mvp': 'MVP 2',
        'milestone': 'MVP 2 - Sprint 4: Previsão Financeira',
        'body': """## 🎯 Objetivo do Épico
Garantir infraestrutura para suporte ao sistema financeiro.

## 👥 Squad Responsável
**Foundation**

## 📌 Definition of Done
- [ ] Otimização de queries financeiras implementada
- [ ] Cache para dashboards configurado
- [ ] Monitoramento de performance ativo
- [ ] Segurança de dados financeiros reforçada

## 📊 Stories Relacionadas
- [ ] STORY-M2-FND-001: Otimização e Segurança Financeira
- [ ] STORY-M2-FND-002: Monitoramento e Documentação"""
    },
    # ===== MVP 3 =====
    {
        'id': 'EPIC-M3-UX-001',
        'title': 'Gestão Visual e Dashboards',
        'squad': 'UX & Experience',
        'mvp': 'MVP 3',
        'milestone': 'MVP 3 - Sprint 5: Gestão Visual',
        'body': """## 🎯 Objetivo do Épico
Dashboards de produtividade e métricas de ROI.

## 👥 Squad Responsável
**UX & Experience**

## 📌 Definition of Done
- [ ] Dashboard com KPIs de produção
- [ ] Comparativo de produtividade entre costureiras
- [ ] Métricas de ROI e eficiência
- [ ] Gráficos interativos e filtros

## 📊 Stories Relacionadas
- [ ] STORY-M3-UX-001: Dashboard de Produção
- [ ] STORY-M3-UX-002: Métricas e ROI"""
    },
    {
        'id': 'EPIC-M3-CORE-001',
        'title': 'Métricas de Negócio',
        'squad': 'Core Business',
        'mvp': 'MVP 3',
        'milestone': 'MVP 3 - Sprint 5: Gestão Visual',
        'body': """## 🎯 Objetivo do Épico
Implementar métricas de negócio e indicadores de performance.

## 👥 Squad Responsável
**Core Business**

## 📌 Definition of Done
- [ ] Cálculo de ROI por costureira
- [ ] Métricas de eficiência produtiva
- [ ] Indicadores de qualidade
- [ ] Comparativos históricos

## 📊 Stories Relacionadas
- [ ] STORY-M3-CORE-001: Métricas de Performance"""
    },
    {
        'id': 'EPIC-M3-FND-001',
        'title': 'Infraestrutura de Dashboards',
        'squad': 'Foundation',
        'mvp': 'MVP 3',
        'milestone': 'MVP 3 - Sprint 5: Gestão Visual',
        'body': """## 🎯 Objetivo do Épico
Garantir infraestrutura para dashboards e visualizações.

## 👥 Squad Responsável
**Foundation**

## 📌 Definition of Done
- [ ] Otimização de assets e minificação
- [ ] Configuração de CDN para assets estáticos
- [ ] Implementação de logging estruturado
- [ ] Rate limiting para APIs de dashboard

## 📊 Stories Relacionadas
- [ ] STORY-M3-FND-001: Otimização de Assets
- [ ] STORY-M3-FND-002: Monitoramento de Dashboards"""
    },
    # ===== MVP 4 =====
    {
        'id': 'EPIC-M4-CORE-001',
        'title': 'Relatórios Avançados',
        'squad': 'Core Business',
        'mvp': 'MVP 4',
        'milestone': 'MVP 4 - Sprint 6: Relatórios Avançados',
        'body': """## 🎯 Objetivo do Épico
Gerar relatórios gerenciais detalhados e exportáveis.

## 👥 Squad Responsável
**Core Business**

## 📌 Definition of Done
- [ ] Relatórios mensais de produção
- [ ] Relatórios de serviços em atraso
- [ ] Exportação em PDF/CSV
- [ ] Filtros avançados

## 📊 Stories Relacionadas
- [ ] STORY-M4-CORE-001: Relatórios de Produção
- [ ] STORY-M4-CORE-002: Exportação de Dados"""
    },
    {
        'id': 'EPIC-M4-UX-001',
        'title': 'Visualização de Relatórios',
        'squad': 'UX & Experience',
        'mvp': 'MVP 4',
        'milestone': 'MVP 4 - Sprint 6: Relatórios Avançados',
        'body': """## 🎯 Objetivo do Épico
Interface para visualização e interação com relatórios.

## 👥 Squad Responsável
**UX & Experience**

## 📌 Definition of Done
- [ ] Páginas de visualização de relatórios
- [ ] Filtros interativos
- [ ] Exportação visual de dados
- [ ] Responsividade dos relatórios

## 📊 Stories Relacionadas
- [ ] STORY-M4-UX-001: Visualização de Relatórios"""
    },
    {
        'id': 'EPIC-M4-FND-001',
        'title': 'Infraestrutura de Relatórios',
        'squad': 'Foundation',
        'mvp': 'MVP 4',
        'milestone': 'MVP 4 - Sprint 6: Relatórios Avançados',
        'body': """## 🎯 Objetivo do Épico
Garantir infraestrutura para geração e exportação de relatórios.

## 👥 Squad Responsável
**Foundation**

## 📌 Definition of Done
- [ ] Otimização de exportação em lote
- [ ] Implementação de jobs assíncronos
- [ ] Compressão de dados para exportação
- [ ] Backup de relatórios gerados

## 📊 Stories Relacionadas
- [ ] STORY-M4-FND-001: Otimização de Exportação
- [ ] STORY-M4-FND-002: Jobs e Backup"""
    },
    # ===== MVP 5 =====
    {
        'id': 'EPIC-M5-ALL-001',
        'title': 'Otimização e Ajustes Finais',
        'squad': 'All Squads',
        'mvp': 'MVP 5',
        'milestone': 'MVP 5 - Sprint 7: Otimização',
        'body': """## 🎯 Objetivo do Épico
Refinar a experiência do usuário e otimizar performance.

## 👥 Squad Responsável
**Todos os Squads**

## 📌 Definition of Done
- [ ] Melhorias de usabilidade
- [ ] Otimização de performance
- [ ] Acessibilidade (WCAG 2.1 AA)
- [ ] Correção de bugs
- [ ] Documentação atualizada

## 📊 Stories Relacionadas
- [ ] STORY-M5-ALL-001: Otimização Geral
- [ ] STORY-M5-CORE-001: Ajustes de Negócio
- [ ] STORY-M5-UX-001: Refinamentos de UX"""
    },
    # ===== FINAL =====
    {
        'id': 'EPIC-FIN-ALL-001',
        'title': 'Deploy e Handover',
        'squad': 'All Squads',
        'mvp': 'Final',
        'milestone': 'Final - Sprint 8: Deploy e Handover',
        'body': """## 🎯 Objetivo do Épico
Entregar o sistema finalizado e documentado.

## 👥 Squad Responsável
**Todos os Squads**

## 📌 Definition of Done
- [ ] Deploy em produção
- [ ] Documentação técnica completa
- [ ] Manual do usuário
- [ ] Treinamento realizado
- [ ] Plano de suporte pós-entrega

## 📊 Stories Relacionadas
- [ ] STORY-FIN-ALL-001: Deploy e Documentação
- [ ] STORY-FIN-ALL-002: Treinamento e Handover"""
    }
]

# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def get_milestone_number(title):
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for ms in r.json():
            if ms['title'] == title:
                return ms['number']
    return None

def issue_exists(title):
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if issue['title'] == title:
                return True
    return False

def create_issue(title, body, labels, milestone_number):
    url = f"{BASE_URL}/issues"
    data = {'title': title, 'body': body, 'labels': labels, 'milestone': milestone_number}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def add_comment(issue_number, body):
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    data = {'body': body}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def build_epic_body(epic):
    body = epic['body']
    body += f"""
---
## 🏷️ Metadados
**ID:** {epic['id']}
**Squad:** {epic['squad']}
**MVP:** {epic['mvp']}
**Tipo:** Épico
"""
    return body

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       SCRIPT: ÉPICOS DOS PRÓXIMOS MVPs
       Apenas Épicos (issues) para MVPs 2, 3, 4, 5 e FINAL
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # ============================================================
    # PASSO 1: FECHAR ÉPICOS CONFLITANTES
    # ============================================================
    
    print("🔍 PASSO 1: FECHANDO ÉPICOS CONFLITANTES...")
    closed = close_conflicting_epics()
    print(f"\n   Total de épicos fechados: {closed}\n")
    
    # ============================================================
    # PASSO 2: CRIAR ÉPICOS
    # ============================================================
    
    print("📌 PASSO 2: CRIANDO ÉPICOS...")
    created = 0
    errors = 0
    
    for epic in EPICS:
        print(f"\n   Processando: {epic['id']}")
        
        milestone_number = get_milestone_number(epic['milestone'])
        if not milestone_number:
            print(f"      ⚠️ Milestone '{epic['milestone']}' não encontrado!")
            errors += 1
            continue
        
        labels = ['epic']
        mvp_map = {'MVP 2': 'mvp2', 'MVP 3': 'mvp3', 'MVP 4': 'mvp4', 'MVP 5': 'mvp5', 'Final': 'final'}
        if epic['mvp'] in mvp_map:
            labels.append(mvp_map[epic['mvp']])
        
        squad_map = {'Foundation': 'foundation', 'Core Business': 'core-business', 'UX & Experience': 'ux-experience'}
        if epic['squad'] in squad_map:
            labels.append(squad_map[epic['squad']])
        
        title = f"[{epic['id']}] [Epic] {epic['title']}"
        
        if issue_exists(title):
            print(f"      ℹ️ Épico já existe: {title}")
            continue
        
        body = build_epic_body(epic)
        result = create_issue(title, body, labels, milestone_number)
        
        if result.status_code == 201:
            issue_number = result.json()['number']
            print(f"      ✅ Épico criado: #{issue_number}")
            created += 1
            
            comment = f"""
## 🏷️ Metadados do Épico
**ID:** {epic['id']}
**Squad:** {epic['squad']}
**MVP:** {epic['mvp']}
**Tipo:** Épico
**Data de Criação:** {time.strftime('%d/%m/%Y')}
"""
            add_comment(issue_number, comment)
            time.sleep(0.5)
        else:
            print(f"      ❌ Erro ao criar épico: {result.status_code}")
            errors += 1
    
    # ============================================================
    # RESUMO FINAL
    # ============================================================
    
    print(f"""
    ==============================================
    ✅ ÉPICOS DOS PRÓXIMOS MVPs CRIADOS!
    ==============================================
    
    📊 Resumo da Limpeza:
       Épicos fechados: {closed}
    
    📊 Resumo da Criação:
       Épicos criados: {created} / {len(EPICS)}
       Erros: {errors}
    
    📋 Detalhamento por MVP:
       MVP 2: 3 épicos (Core, UX, Foundation)
       MVP 3: 3 épicos (UX, Core, Foundation)
       MVP 4: 3 épicos (Core, UX, Foundation)
       MVP 5: 1 épico (All)
       Final: 1 épico (All)
    
    🔗 Acesse:
       Issues: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)
    
    print("\n📌 PRÓXIMO PASSO: Execute o script do MVP 2 para criar as Stories:")
    print("   python setup_mvp2_planning.py")

if __name__ == "__main__":
    main()