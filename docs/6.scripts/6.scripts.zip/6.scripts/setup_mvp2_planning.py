#!/usr/bin/env python3
"""
Script: Planejamento MVP 2 - Previsão Financeira
Cria Stories com Tasks como checklist para o MVP 2
"""
import os
import requests
import json
from dotenv import load_dotenv
import time
import re

load_dotenv()

GITHUB_TOKEN = os.getenv('GITHUB_TOKEN')
REPO_OWNER = os.getenv('REPO_OWNER', 'anandamatos')
REPO_NAME = os.getenv('REPO_NAME', 'cony-interiores')

if not GITHUB_TOKEN:
    print("❌ ERRO: GITHUB_TOKEN não encontrado!")
    exit(1)

HEADERS = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
}

BASE_URL = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"

# ============================================================
# 1. FUNÇÕES PARA FECHAR STORIES CONFLITANTES
# ============================================================

def get_all_open_issues():
    """Busca todas as issues abertas"""
    url = f"{BASE_URL}/issues?state=open&per_page=100"
    all_issues = []
    page = 1
    
    while True:
        paginated_url = f"{url}&page={page}"
        r = requests.get(paginated_url, headers=HEADERS)
        if r.status_code != 200:
            break
        
        issues = r.json()
        if not issues:
            break
        
        all_issues.extend(issues)
        page += 1
        
        if 'Link' in r.headers and 'rel="next"' not in r.headers['Link']:
            break
    
    return all_issues

def close_issue(issue_number):
    """Fecha uma issue"""
    url = f"{BASE_URL}/issues/{issue_number}"
    data = {'state': 'closed'}
    r = requests.patch(url, headers=HEADERS, json=data)
    return r.status_code == 200

def close_conflicting_stories():
    """Fecha stories conflitantes do MVP 2"""
    print("\n🧹 FECHANDO STORIES CONFLITANTES DO MVP 2...")
    
    # Padrões de IDs de stories do MVP 2
    conflict_patterns = [
        r'STORY-M2-',  # Stories MVP 2
        r'TASK-M2-',   # Tasks MVP 2 (se houver como issues separadas)
    ]
    
    issues = get_all_open_issues()
    closed = 0
    
    for issue in issues:
        title = issue['title']
        number = issue['number']
        
        # Verifica se é uma story conflitante
        is_conflict = False
        for pattern in conflict_patterns:
            if re.search(pattern, title):
                is_conflict = True
                break
        
        if is_conflict:
            print(f"   Fechando story #{number}: {title[:50]}...")
            if close_issue(number):
                print(f"   ✅ Story #{number} fechada")
                closed += 1
            else:
                print(f"   ❌ Erro ao fechar story #{number}")
            time.sleep(0.3)
    
    print(f"   Total de stories fechadas: {closed}")
    return closed

# ============================================================
# 2. MAPEAMENTO DE MEMBROS
# ============================================================

MEMBERS = {
    'STORY-M2-CORE-001': {'assignee': 'Matheus-G-R', 'squad': 'Core Business'},
    'STORY-M2-CORE-002': {'assignee': 'Matheus-G-R', 'squad': 'Core Business'},
    'STORY-M2-UX-001': {'assignee': 'gabrielaugusto872', 'squad': 'UX & Experience'},
    'STORY-M2-FND-001': {'assignee': 'Marcus1423', 'squad': 'Foundation'},
    'STORY-M2-FND-002': {'assignee': 'mariagabrielle428-ship-it', 'squad': 'Foundation'},
}

LEADERS = {
    'Core Business': 'karinakaduda19-cyber',
    'UX & Experience': 'anandamatos',
    'Foundation': 'lobaque29'
}

# ============================================================
# 3. STORIES MVP 2 COM TASKS
# ============================================================

STORIES = [
    {
        'id': 'STORY-M2-CORE-001',
        'title': 'Modelo Financeiro',
        'epic_id': 'EPIC-M2-CORE-001',
        'sprint': 'MVP 2 - Sprint 4: Previsão Financeira',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M2-CORE-001: Criar model Pagamento (costureira, valor, data, status)',
            'TASK-M2-CORE-002: Implementar serializers do modelo financeiro',
            'TASK-M2-CORE-003: Criar endpoints para registrar pagamentos',
            'TASK-M2-CORE-004: Implementar validações de valores e datas',
            'TASK-M2-CORE-005: Escrever testes unitários do modelo financeiro'
        ],
        'discovery_tasks': [
            'Validar estrutura de dados financeiros necessários',
            'Definir status de pagamento (pendente, pago, atrasado)',
            'Mapear integração com modelo de Serviços',
            'Validar regras de cálculo de valores pendentes'
        ],
        'measurement_tasks': [
            'Definir KPIs de controle financeiro',
            'Estabelecer tempo de processamento de pagamentos',
            'Criar métricas de acurácia dos cálculos',
            'Definir cobertura de testes financeiros'
        ]
    },
    {
        'id': 'STORY-M2-CORE-002',
        'title': 'Cálculo de Pagamentos',
        'epic_id': 'EPIC-M2-CORE-001',
        'sprint': 'MVP 2 - Sprint 4: Previsão Financeira',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M2-CORE-006: Implementar cálculo automático de valores pendentes',
            'TASK-M2-CORE-007: Criar sumarização de pagamentos por costureira',
            'TASK-M2-CORE-008: Implementar planejamento semanal de pagamentos',
            'TASK-M2-CORE-009: Criar endpoint de resumo financeiro',
            'TASK-M2-CORE-010: Escrever testes de integração financeira'
        ],
        'discovery_tasks': [
            'Validar lógica de sumarização de valores',
            'Definir período de planejamento (semanal/mensal)',
            'Mapear regras de agrupamento por costureira',
            'Validar integração com status de serviços'
        ],
        'measurement_tasks': [
            'Definir KPIs de eficiência de pagamentos',
            'Estabelecer tempo de geração de resumo semanal',
            'Criar métricas de precisão do planejamento',
            'Estabelecer acurácia dos valores calculados'
        ]
    },
    {
        'id': 'STORY-M2-UX-001',
        'title': 'Dashboard Financeiro',
        'epic_id': 'EPIC-M2-UX-001',
        'sprint': 'MVP 2 - Sprint 4: Previsão Financeira',
        'story_points': 5,
        'priority': 'P0',
        'tasks': [
            'TASK-M2-UX-001: Criar página de dashboard financeiro',
            'TASK-M2-UX-002: Implementar cards de resumo financeiro',
            'TASK-M2-UX-003: Criar gráficos de valores pendentes',
            'TASK-M2-UX-004: Implementar filtros por período e costureira',
            'TASK-M2-UX-005: Integrar dashboard com API de resumo financeiro'
        ],
        'discovery_tasks': [
            'Validar requisitos de visualização financeira',
            'Definir hierarquia de informações no dashboard',
            'Prototipar cards de resumo financeiro',
            'Mapear tipos de gráficos necessários'
        ],
        'measurement_tasks': [
            'Definir KPIs de usabilidade do dashboard financeiro',
            'Estabelecer tempo de carregamento do dashboard',
            'Criar métricas de interpretação dos dados',
            'Definir testes de UX financeiro'
        ]
    },
    {
        'id': 'STORY-M2-FND-001',
        'title': 'Otimização e Segurança Financeira',
        'epic_id': 'EPIC-M2-FND-001',
        'sprint': 'MVP 2 - Sprint 4: Previsão Financeira',
        'story_points': 3,
        'priority': 'P1',
        'tasks': [
            'TASK-M2-FND-001: Otimizar queries de agregação financeira',
            'TASK-M2-FND-002: Implementar cache Redis para dashboards',
            'TASK-M2-FND-003: Reforçar permissões para dados financeiros',
            'TASK-M2-FND-004: Configurar monitoramento de performance',
            'TASK-M2-FND-005: Documentar endpoints financeiros'
        ],
        'discovery_tasks': [
            'Identificar queries mais lentas do sistema financeiro',
            'Validar requisitos de cache para dashboards',
            'Mapear dados sensíveis que precisam de proteção adicional',
            'Definir métricas de performance a serem monitoradas'
        ],
        'measurement_tasks': [
            'Definir KPIs de performance de queries financeiras',
            'Estabelecer tempo de resposta com cache vs sem cache',
            'Criar métricas de segurança de dados financeiros',
            'Definir cobertura de monitoramento'
        ]
    },
    {
        'id': 'STORY-M2-FND-002',
        'title': 'Monitoramento e Documentação',
        'epic_id': 'EPIC-M2-FND-001',
        'sprint': 'MVP 2 - Sprint 4: Previsão Financeira',
        'story_points': 2,
        'priority': 'P1',
        'tasks': [
            'TASK-M2-FND-006: Implementar logging estruturado para APIs financeiras',
            'TASK-M2-FND-007: Configurar alertas de performance',
            'TASK-M2-FND-008: Criar dashboard de monitoramento interno',
            'TASK-M2-FND-009: Documentar API financeira (OpenAPI/Swagger)',
            'TASK-M2-FND-010: Configurar testes de carga para endpoints financeiros'
        ],
        'discovery_tasks': [
            'Validar requisitos de logging estruturado',
            'Definir níveis de alerta para performance financeira',
            'Mapear endpoints críticos para monitoramento',
            'Validar formato de documentação de API'
        ],
        'measurement_tasks': [
            'Definir KPIs de monitoramento financeiro',
            'Estabelecer tempo de detecção de problemas',
            'Criar métricas de cobertura de documentação',
            'Definir cobertura de testes de carga'
        ]
    }
]

# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def get_milestone_number(title):
    url = f"{BASE_URL}/milestones"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for ms in r.json():
            if ms['title'] == title:
                return ms['number']
    return None

def get_epic_number(epic_id):
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if epic_id in issue['title']:
                return issue['number']
    return None

def issue_exists(title):
    url = f"{BASE_URL}/issues?state=open"
    r = requests.get(url, headers=HEADERS)
    if r.status_code == 200:
        for issue in r.json():
            if issue['title'] == title:
                return True
    return False

def create_issue(title, body, labels, milestone_number, assignee=None):
    url = f"{BASE_URL}/issues"
    data = {'title': title, 'body': body, 'labels': labels, 'milestone': milestone_number}
    if assignee:
        data['assignees'] = [assignee]
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def add_comment(issue_number, body):
    url = f"{BASE_URL}/issues/{issue_number}/comments"
    data = {'body': body}
    r = requests.post(url, headers=HEADERS, json=data)
    return r

def build_story_body(story):
    squad = MEMBERS.get(story['id'], {}).get('squad', 'N/A')
    assignee = MEMBERS.get(story['id'], {}).get('assignee', 'N/A')
    
    body = f"""## 📖 User Story
Como {story['title'].split(':')[0] if ':' in story['title'] else 'usuário'}, quero {story['title'].split(':')[1] if ':' in story['title'] else story['title']} para melhorar o planejamento financeiro.

## ✅ Critérios de Aceite
- [ ] Todos os critérios de aceite definidos para esta história
- [ ] Testes automatizados passando
- [ ] Código revisado e aprovado
- [ ] Documentação atualizada

## 📋 Tarefas (Checklist)
"""
    for task in story['tasks']:
        body += f"- [ ] {task}\n"
    
    body += f"""
## 🔍 Tarefas de Discovery
"""
    for task in story['discovery_tasks']:
        body += f"- [ ] {task}\n"
    
    body += f"""
## 📊 Tarefas de Mensuração
"""
    for task in story['measurement_tasks']:
        body += f"- [ ] {task}\n"
    
    body += f"""
---
## 🏷️ Metadados
**ID:** {story['id']}
**Squad:** {squad}
**MVP:** MVP 2
**Tipo:** Story
**Estimativa:** {story['story_points']} Story Points
**Prioridade:** {story['priority']}
**Épico:** {story['epic_id']}
**Sprint:** {story['sprint']}
**Responsável:** @{assignee}
"""
    return body

# ============================================================
# FUNÇÃO PRINCIPAL
# ============================================================

def main():
    print("""
    🚀 ==============================================
       SCRIPT: PLANEJAMENTO MVP 2
       Stories com Tasks como Checklist
    ==============================================
    """)
    print(f"📋 Repositório: {REPO_OWNER}/{REPO_NAME}\n")
    
    # ============================================================
    # PASSO 1: FECHAR STORIES CONFLITANTES
    # ============================================================
    
    print("🔍 PASSO 1: FECHANDO STORIES CONFLITANTES DO MVP 2...")
    closed = close_conflicting_stories()
    print(f"\n   Total de stories fechadas: {closed}\n")
    
    # ============================================================
    # PASSO 2: CRIAR STORIES
    # ============================================================
    
    print("📖 PASSO 2: CRIANDO STORIES MVP 2...")
    created = 0
    errors = 0
    
    for story in STORIES:
        print(f"\n   Processando: {story['id']}")
        
        # Busca o épico
        epic_number = get_epic_number(story['epic_id'])
        if not epic_number:
            print(f"      ⚠️ Épico '{story['epic_id']}' não encontrado!")
            errors += 1
            continue
        
        # Busca o milestone
        milestone_number = get_milestone_number(story['sprint'])
        if not milestone_number:
            print(f"      ⚠️ Milestone '{story['sprint']}' não encontrado!")
            errors += 1
            continue
        
        # Prepara os dados
        assignee = MEMBERS.get(story['id'], {}).get('assignee')
        squad = MEMBERS.get(story['id'], {}).get('squad', '').lower().replace(' ', '-')
        labels = ['story', 'mvp2', squad] if squad else ['story', 'mvp2']
        title = f"[{story['id']}] Story: {story['title']}"
        body = build_story_body(story)
        
        # Verifica se já existe
        if issue_exists(title):
            print(f"      ℹ️ Story já existe: {title}")
            continue
        
        # Cria a story
        result = create_issue(title, body, labels, milestone_number, assignee)
        
        if result.status_code == 201:
            issue_number = result.json()['number']
            print(f"      ✅ Story criada: #{issue_number}")
            created += 1
            
            # Comentário vinculando ao épico
            comment = f"🔗 Esta Story faz parte do Épico #{epic_number} - {story['epic_id']}"
            add_comment(issue_number, comment)
            
            # Atribui o líder
            squad_name = MEMBERS.get(story['id'], {}).get('squad', '')
            leader = LEADERS.get(squad_name)
            if leader and assignee:
                url = f"{BASE_URL}/issues/{issue_number}"
                data = {'assignees': [leader, assignee]}
                requests.patch(url, headers=HEADERS, json=data)
                print(f"      ✅ Líder @{leader} e @{assignee} atribuídos")
            elif leader:
                url = f"{BASE_URL}/issues/{issue_number}"
                data = {'assignees': [leader]}
                requests.patch(url, headers=HEADERS, json=data)
                print(f"      ✅ Líder @{leader} atribuído")
            
            time.sleep(0.5)
        else:
            print(f"      ❌ Erro ao criar story: {result.status_code}")
            errors += 1
    
    # ============================================================
    # RESUMO FINAL
    # ============================================================
    
    print(f"""
    ==============================================
    ✅ PLANEJAMENTO MVP 2 CONCLUÍDO!
    ==============================================
    
    📊 Resumo da Limpeza:
       Stories fechadas: {closed}
    
    📊 Resumo da Criação:
       Stories criadas: {created} / {len(STORIES)}
       Erros: {errors}
    
    📋 Detalhamento:
       Core Business: 2 stories (Modelo Financeiro, Cálculo de Pagamentos)
       UX & Experience: 1 story (Dashboard Financeiro)
       Foundation: 2 stories (Otimização e Segurança, Monitoramento e Documentação)
       Tasks: 25 (embutidas como checklist nas stories)
    
    🔗 Acesse:
       Issues: https://github.com/{REPO_OWNER}/{REPO_NAME}/issues
    """)

if __name__ == "__main__":
    main()